
-- Run this in the Supabase SQL Editor to add yourself as an admin
-- First, create the user_roles table if it doesn't exist (safety check)
CREATE TABLE IF NOT EXISTS public.user_roles (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES auth.users(id) NOT NULL,
  role TEXT NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(user_id, role)
);

-- Then insert your user as an admin
-- REPLACE 'YOUR_USER_ID' WITH YOUR ACTUAL USER ID
INSERT INTO public.user_roles (user_id, role)
VALUES ('YOUR_USER_ID', 'admin');
