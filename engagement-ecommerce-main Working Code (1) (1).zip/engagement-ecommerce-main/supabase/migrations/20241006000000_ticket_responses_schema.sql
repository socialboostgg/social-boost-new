
-- Add uuid-ossp extension if not already installed
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Create user_roles table first
CREATE TABLE IF NOT EXISTS public.user_roles (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES auth.users(id) NOT NULL,
  role TEXT NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(user_id, role)
);

-- Enable Row Level Security on user_roles
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;

-- Create policy to allow users to view their own roles
CREATE POLICY "Users can view their own roles" 
  ON public.user_roles 
  FOR SELECT 
  USING (auth.uid() = user_id);

-- Create policy to allow admins to manage roles
CREATE POLICY "Admins can manage roles" 
  ON public.user_roles 
  USING (
    auth.uid() IN (
      SELECT user_id FROM public.user_roles WHERE role = 'admin'
    )
  );

-- Now create ticket_responses table
CREATE TABLE IF NOT EXISTS public.ticket_responses (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  ticket_id UUID REFERENCES public.support_tickets(id) NOT NULL,
  admin_id UUID REFERENCES auth.users(id) NOT NULL,
  message TEXT NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Enable Row Level Security on ticket_responses
ALTER TABLE public.ticket_responses ENABLE ROW LEVEL SECURITY;

-- Create policy to allow users to view responses to their tickets
CREATE POLICY "Users can view responses to their tickets" 
  ON public.ticket_responses 
  FOR SELECT 
  USING (
    auth.uid() IN (
      SELECT user_id FROM public.support_tickets WHERE id = ticket_id
    )
    OR
    auth.uid() IN (
      SELECT user_id FROM public.user_roles WHERE role = 'admin'
    )
  );

-- Create policy to allow admins to create responses
CREATE POLICY "Admins can create responses" 
  ON public.ticket_responses 
  FOR INSERT 
  WITH CHECK (
    auth.uid() IN (
      SELECT user_id FROM public.user_roles WHERE role = 'admin'
    )
  );

-- Create indexes for faster lookups
CREATE INDEX ticket_responses_ticket_id_idx ON public.ticket_responses (ticket_id);
CREATE INDEX ticket_responses_admin_id_idx ON public.ticket_responses (admin_id);
CREATE INDEX user_roles_user_id_idx ON public.user_roles (user_id);
CREATE INDEX user_roles_role_idx ON public.user_roles (role);
