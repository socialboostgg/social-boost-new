
-- Create payment_intents table
CREATE TABLE public.payment_intents (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  payment_intent_id TEXT NOT NULL UNIQUE,
  amount DECIMAL(10, 2) NOT NULL,
  status TEXT NOT NULL,
  metadata JSONB,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Enable Row Level Security
ALTER TABLE public.payment_intents ENABLE ROW LEVEL SECURITY;

-- Create a policy that only allows users to view their own payment intents
CREATE POLICY "Users can view their own payment intents" 
  ON public.payment_intents 
  FOR SELECT 
  USING (auth.uid() = user_id);

-- Create a trigger to update the updated_at column
CREATE TRIGGER set_updated_at
  BEFORE UPDATE ON public.payment_intents
  FOR EACH ROW
  EXECUTE FUNCTION public.set_updated_at();

-- Create index for faster lookups
CREATE INDEX payment_intents_payment_intent_id_idx ON public.payment_intents (payment_intent_id);
