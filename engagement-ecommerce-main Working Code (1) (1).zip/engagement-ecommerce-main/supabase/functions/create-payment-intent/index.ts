import { serve } from 'https://deno.land/std@0.168.0/http/server.ts'
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'
import Stripe from 'https://esm.sh/stripe@12.13.0'

// Initialize Stripe with your secret key from Supabase Secrets
const stripe = new Stripe(Deno.env.get('Stripe_Secret_Key') || '', {
  apiVersion: '2023-10-16',
  httpClient: Stripe.createFetchHttpClient(),
})

// Initialize the Supabase client
const supabaseUrl = Deno.env.get('SUPABASE_URL') || ''
const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') || ''
const supabase = createClient(supabaseUrl, supabaseServiceKey)

console.log("Function loaded. Stripe initialized:", !!stripe);
console.log("Supabase URL configured:", !!supabaseUrl);
console.log("Stripe API key configured:", !!Deno.env.get('Stripe_Secret_Key'));

// Define allowed origins - ensure this matches all your frontend deployment URLs
const allowedOrigins = [
  'https://preview--engagement-ecommerce.lovable.app',
  'https://engagement-ecommerce.lovable.app',
  'https://www.engagement-ecommerce.lovable.app',
  'http://localhost:5173',
  'http://localhost:3000',
  'http://localhost:4173',
  'http://127.0.0.1:5173',
  'http://127.0.0.1:3000',
  'http://socialboost.gg',
  'https://socialboost.gg',
  'http://www.socialboost.gg',
  'https://www.socialboost.gg',
  'http://localhost:8080',
  'http://127.0.0.1:8080',
];

// Simplified CORS headers
const corsHeaders = {
  'Access-Control-Allow-Origin': '*', // Allow all origins for testing
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
  'Access-Control-Allow-Headers': '*', // Allow all headers for testing
};

serve(async (req) => {
  console.log("Request received:", {
    method: req.method,
    url: req.url,
    headers: Object.fromEntries(req.headers.entries()),
  });
  
  // Get the origin of the request
  const origin = req.headers.get('origin') || '';
  console.log("Request origin:", origin);
  
  // Find matching origin or use a default for development
  let allowedOrigin = '*';  // Default fallback
  
  if (allowedOrigins.includes(origin)) {
    allowedOrigin = origin;
  } else {
    console.log(`Origin not in allowed list: ${origin}, using fallback`);
    // For development, we'll accept requests from unknown origins
    if (process.env.NODE_ENV === 'development') {
      allowedOrigin = origin || '*';
    }
  }
  
  // Set CORS headers with the actual origin
  const corsHeaders = {
    'Access-Control-Allow-Origin': allowedOrigin,
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-Client-Info, Accept',
    'Access-Control-Allow-Credentials': 'true',
    'Access-Control-Max-Age': '86400',
    'Content-Type': 'application/json',
  };

  console.log("CORS headers set:", JSON.stringify(corsHeaders));

  // Handle preflight OPTIONS request - this is critical for CORS to work
  try {
    if (req.method === 'OPTIONS') {
      console.log("Handling OPTIONS preflight request");
      return new Response(null, {
        status: 200,
        headers: corsHeaders
      });
    }
  } catch (error) {
    console.error("Error handling OPTIONS request:", error);
    return new Response(JSON.stringify({ error: "Internal server error processing OPTIONS" }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });
  }

  try {
    // Only accept POST requests
    if (req.method !== 'POST') {
      console.log(`Method not allowed: ${req.method}`);
      return new Response(JSON.stringify({ error: 'Method not allowed' }), {
        status: 405,
        headers: corsHeaders,
      });
    }

    // Parse the request body
    let requestBody;
    try {
      requestBody = await req.json();
      console.log("Request body parsed successfully:", JSON.stringify(requestBody).substring(0, 200));
    } catch (parseError) {
      console.error("Error parsing request body:", parseError);
      return new Response(JSON.stringify({ 
        error: 'Invalid request body format',
        details: parseError instanceof Error ? parseError.message : 'Unknown parsing error'
      }), {
        status: 400,
        headers: corsHeaders,
      });
    }

    const { amount, items } = requestBody;

    console.log("Received request with amount:", amount);

    if (!amount || isNaN(amount) || amount <= 0) {
      return new Response(JSON.stringify({ 
        error: 'Invalid amount', 
        received: amount 
      }), {
        status: 400,
        headers: corsHeaders,
      });
    }

    // Create a payment intent with Stripe
    try {
      const paymentIntent = await stripe.paymentIntents.create({
        amount: amount, // amount is expected in cents
        currency: 'usd',
        automatic_payment_methods: {
          enabled: true,
        },
        metadata: {
          items: JSON.stringify(items?.map(item => ({ id: item.id, title: item.title })) || []),
        },
      });

      console.log("Payment intent created:", paymentIntent.id);

      // Store the payment intent in your database (optional)
      try {
        const { data, error } = await supabase
          .from('payment_intents')
          .insert([
            {
              payment_intent_id: paymentIntent.id,
              amount: amount / 100, // Store in dollars for readability
              status: paymentIntent.status,
              metadata: items,
            },
          ]);

        if (error) {
          console.error('Error storing payment intent:', error);
          // Continue anyway since the payment intent was created successfully
        }
      } catch (dbError) {
        console.error('Database error:', dbError);
        // Continue since this is not critical for the payment flow
      }

      // Return the client secret to the client
      return new Response(
        JSON.stringify({
          clientSecret: paymentIntent.client_secret,
          success: true,
        }),
        {
          status: 200,
          headers: corsHeaders,
        }
      );
    } catch (stripeError) {
      console.error('Stripe error:', stripeError);
      return new Response(
        JSON.stringify({
          error: stripeError instanceof Error ? stripeError.message : 'Stripe processing error',
          success: false,
        }),
        {
          status: 500,
          headers: corsHeaders,
        }
      );
    }
  } catch (error) {
    console.error('Unhandled error:', error);
    return new Response(
      JSON.stringify({
        error: error instanceof Error ? error.message : 'Unknown error',
        success: false,
      }),
      {
        status: 500,
        headers: corsHeaders,
      }
    );
  }
});
