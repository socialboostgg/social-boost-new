   import { serve } from 'https://deno.land/std@0.168.0/http/server.ts'
   import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

   // API constants - stored as environment variables
   const API_URL = "https://qcypykfhygfzijffxlej.supabase.co/functions/v1/smm-panel";
   const API_KEY = "13410cc5002ffb114baedc7b8e5bfdc8";

   // Initialize the Supabase client for logging (optional)
   const supabaseUrl = Deno.env.get('SUPABASE_URL') || ''
   const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') || ''
   const supabase = createClient(supabaseUrl, supabaseServiceKey)

   console.log("SMM Proxy function loaded");
   console.log("SMM Panel URL configured:", !!API_URL);
   console.log("SMM Panel API key configured:", !!API_KEY);

   // CORS headers
   const corsHeaders = {
     'Access-Control-Allow-Origin': '*',
     'Access-Control-Allow-Methods': 'POST, OPTIONS',
     'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-Client-Info, Accept',
     'Content-Type': 'application/json',
   };

   serve(async (req) => {
     console.log("Request received:", req.method);
     
     // Handle OPTIONS request for CORS preflight
     if (req.method === 'OPTIONS') {
       console.log("Handling OPTIONS preflight request");
       return new Response(null, {
         status: 200,
         headers: corsHeaders
       });
     }
     
     // Only accept POST requests
     if (req.method !== 'POST') {
       console.log(`Method not allowed: ${req.method}`);
       return new Response(JSON.stringify({ error: 'Method not allowed' }), {
         status: 405,
         headers: corsHeaders,
       });
     }
     
     // Check for authorization header
     const authHeader = req.headers.get('Authorization');
     if (!authHeader) {
       console.log("Missing authorization header");
       return new Response(JSON.stringify({ 
         code: 401,
         message: 'Missing authorization header' 
       }), {
         status: 401,
         headers: corsHeaders,
       });
     }
     
     try {
       // Parse the request body
       let requestData;
       try {
         requestData = await req.json();
         console.log("Request data received:", JSON.stringify(requestData).substring(0, 200));
       } catch (parseError) {
         console.error("Error parsing request body:", parseError);
         return new Response(JSON.stringify({ 
           error: 'Invalid request body format',
           details: parseError instanceof Error ? parseError.message : 'Unknown parsing error'
         }), {
           status: 400,
           headers: corsHeaders,
         });
       }
       
       // Add the API key to the request
       const apiRequestBody = {
         key: API_KEY,
         ...requestData
       };
       
       console.log("Forwarding request to SMM panel");
       
       // Forward the request to JustAnotherPanel
       const response = await fetch("https://justanotherpanel.com/api/v2", {
         method: "POST",
         headers: {
           "Content-Type": "application/json",
         },
         body: JSON.stringify({
           key: API_KEY,
           action: "services",
           ...requestData
         }),
       });
       
       console.log("SMM panel response status:", response.status);
       
       if (!response.ok) {
         console.error(`SMM panel API request failed with status: ${response.status}`);
         return new Response(JSON.stringify({ 
           error: `SMM panel API request failed with status: ${response.status}` 
         }), {
           status: response.status,
           headers: corsHeaders,
         });
       }
       
       // Get the response data
       const data = await response.json();
       console.log("SMM panel response:", JSON.stringify(data).substring(0, 200));
       
       // Return the response
       return new Response(JSON.stringify(data), {
         status: 200,
         headers: corsHeaders,
       });
     } catch (error) {
       console.error('Error proxying request:', error);
       
       return new Response(JSON.stringify({
         error: error instanceof Error ? error.message : 'Unknown error',
       }), {
         status: 500,
         headers: corsHeaders,
       });
     }
   });