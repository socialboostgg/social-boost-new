
import { useState, useEffect } from "react";
import { Helmet } from "react-helmet";
import { Navbar } from "@/components/layout/Navbar";
import { Footer } from "@/components/layout/Footer";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Gift, Instagram, Twitter, Check, AlertCircle, UserPlus, Loader2, Info } from "lucide-react";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { useAuth } from "@/context/AuthContext";
import { toast } from "sonner";
import { AuthDialog } from "@/components/auth/AuthDialog";
import { TikTok } from "@/components/icons/TikTok";
import { 
  processFreeFollowerOrder, 
  isMockModeEnabled, 
  resetMockMode,
  enableMockMode
} from "@/utils/freeOrdersService";

const FreeFollowers = () => {
  const { isLoggedIn, user } = useAuth();
  const [showAuthDialog, setShowAuthDialog] = useState(false);
  const [selectedPlatform, setSelectedPlatform] = useState<string>("instagram");
  const [profileUrl, setProfileUrl] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [orderId, setOrderId] = useState<number | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [isUsingMockApi, setIsUsingMockApi] = useState(false);
  const [apiAttemptFailed, setApiAttemptFailed] = useState(false);

  // Ensure we always start with mock mode disabled
  useEffect(() => {
    resetMockMode();
    setIsUsingMockApi(false);
  }, []);

  // Show auth dialog if user is not logged in
  useEffect(() => {
    if (!isLoggedIn) {
      setShowAuthDialog(true);
    }
  }, [isLoggedIn]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!isLoggedIn || !user) {
      setShowAuthDialog(true);
      return;
    }
    
    // Reset states
    setError(null);
    setApiAttemptFailed(false);
    
    if (!profileUrl.trim()) {
      setError("Please enter your profile URL");
      toast.error("Please enter your profile URL");
      return;
    }
    
    setIsSubmitting(true);
    
    try {
      // Get the platform name
      const platformName = getPlatformName();
      
      console.log(`Submitting order for ${platformName} followers to ${profileUrl}`);
      console.log(`Using mock API: ${isUsingMockApi}`);
      
      // Process the free follower order
      const result = await processFreeFollowerOrder(
        user.id,
        platformName,
        profileUrl,
        isUsingMockApi // Only use mock mode if explicitly enabled
      );
      
      console.log("Order result:", result);
      
      if (!result.success) {
        // Check if this is a network/connection error
        if (result.error?.includes("Failed to fetch") || 
            result.error?.includes("API error") || 
            result.error?.includes("connect to service provider")) {
          setApiAttemptFailed(true);
        }
        
        setError(result.error || "Order processing failed");
        toast.error(result.error || "Failed to place order");
        setIsSubmitting(false);
        return;
      }
      
      // Set the order ID if available
      if (result.orderId !== undefined) {
        setOrderId(result.orderId);
        console.log(`Order successful with ID: ${result.orderId}`);
      }
      
      setIsSubmitted(true);
      toast.success(`Your free ${selectedPlatform} followers have been ordered!`);
    } catch (error) {
      console.error("Error placing order:", error);
      toast.error(`Error: ${error instanceof Error ? error.message : "Unknown error"}`);
      setApiAttemptFailed(true);
    } finally {
      setIsSubmitting(false);
    }
  };
  
  // Helper function to get the platform name in proper format
  const getPlatformName = (): string => {
    switch (selectedPlatform) {
      case "instagram": return "Instagram";
      case "tiktok": return "TikTok";
      case "twitter": return "Twitter";
      default: return "Instagram";
    }
  };

  // Switch to mock mode for testing
  const handleEnableMockMode = () => {
    enableMockMode(true);
    setIsUsingMockApi(true);
    toast.info("Switched to demonstration mode for testing", {
      description: "No actual orders will be placed"
    });
    setError(null);
    setApiAttemptFailed(false);
  };

  // Switch back to real API mode
  const handleDisableMockMode = () => {
    enableMockMode(false);
    setIsUsingMockApi(false);
    toast.info("Using real API for orders");
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Helmet>
        <title>Free 50 Followers - Social Boost</title>
        <meta name="description" content="Get 50 free followers for TikTok, Instagram, or Twitter when you sign up" />
      </Helmet>
      
      <Navbar />
      
      <main className="flex-grow container mx-auto px-4 py-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="max-w-3xl mx-auto"
        >
          <div className="text-center mb-8">
            <span className="inline-block p-3 bg-primary/10 text-primary rounded-full mb-4">
              <Gift className="h-8 w-8" />
            </span>
            <h1 className="text-3xl font-bold mb-2">Claim Your 50 FREE Followers</h1>
            <p className="text-lg text-muted-foreground">
              New users get 50 free followers for TikTok, Instagram, or Twitter
            </p>
          </div>
          
          {!isLoggedIn ? (
            <Card>
              <CardContent className="pt-6 text-center">
                <div className="mx-auto w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mb-4">
                  <UserPlus className="h-8 w-8 text-primary" />
                </div>
                <h2 className="text-2xl font-semibold mb-2">Sign Up to Claim Your Free Followers</h2>
                <p className="text-muted-foreground mb-6">
                  Create an account or log in to claim your 50 free followers for any platform.
                </p>
                <div className="flex flex-col sm:flex-row gap-4 justify-center">
                  <Button 
                    onClick={() => setShowAuthDialog(true)}
                    className="flex-1"
                  >
                    Sign Up Now
                  </Button>
                  <Button 
                    variant="outline" 
                    onClick={() => setShowAuthDialog(true)}
                    className="flex-1"
                  >
                    Login
                  </Button>
                </div>
              </CardContent>
            </Card>
          ) : isSubmitted ? (
            <Card>
              <CardContent className="pt-6 text-center">
                <div className="mx-auto w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mb-4">
                  <Check className="h-8 w-8 text-green-600" />
                </div>
                <h2 className="text-2xl font-semibold mb-2">Order Received!</h2>
                <p className="text-muted-foreground mb-6">
                  Your free followers will be delivered to your {selectedPlatform} profile within 24 hours.
                  {orderId !== null && <span className="block mt-2 text-sm">Order ID: #{orderId}</span>}
                  {isUsingMockApi && (
                    <span className="block mt-2 text-xs text-amber-600 bg-amber-50 p-2 rounded">
                      <Info className="h-4 w-4 inline mr-1" />
                      Demo mode: No actual followers will be delivered in this preview.
                    </span>
                  )}
                </p>
                <div className="flex flex-col sm:flex-row gap-4 justify-center">
                  <Button asChild variant="outline">
                    <Link to="/">Back to Home</Link>
                  </Button>
                  <Button asChild>
                    <Link to={`/${selectedPlatform}-packages`}>
                      Get More {selectedPlatform.charAt(0).toUpperCase() + selectedPlatform.slice(1)} Followers
                    </Link>
                  </Button>
                </div>
              </CardContent>
            </Card>
          ) : (
            <Card>
              <CardHeader>
                <CardTitle>Choose Your Platform</CardTitle>
                <CardDescription>Select the social media platform where you want to receive 50 free followers</CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmit} className="space-y-6">
                  <RadioGroup 
                    value={selectedPlatform} 
                    onValueChange={setSelectedPlatform}
                    className="grid gap-4 grid-cols-1 sm:grid-cols-3"
                  >
                    <div>
                      <RadioGroupItem 
                        value="instagram" 
                        id="instagram" 
                        className="peer sr-only" 
                      />
                      <Label
                        htmlFor="instagram"
                        className="flex flex-col items-center justify-between rounded-md border-2 border-muted bg-transparent p-4 hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary [&:has([data-state=checked])]:border-primary"
                      >
                        <Instagram className="mb-3 h-6 w-6 text-pink-500" />
                        <span className="font-semibold">Instagram</span>
                      </Label>
                    </div>
                    
                    <div>
                      <RadioGroupItem 
                        value="tiktok" 
                        id="tiktok" 
                        className="peer sr-only" 
                      />
                      <Label
                        htmlFor="tiktok"
                        className="flex flex-col items-center justify-between rounded-md border-2 border-muted bg-transparent p-4 hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary [&:has([data-state=checked])]:border-primary"
                      >
                        <TikTok className="mb-3 h-6 w-6" />
                        <span className="font-semibold">TikTok</span>
                      </Label>
                    </div>
                    
                    <div>
                      <RadioGroupItem 
                        value="twitter" 
                        id="twitter" 
                        className="peer sr-only" 
                      />
                      <Label
                        htmlFor="twitter"
                        className="flex flex-col items-center justify-between rounded-md border-2 border-muted bg-transparent p-4 hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary [&:has([data-state=checked])]:border-primary"
                      >
                        <Twitter className="mb-3 h-6 w-6 text-blue-400" />
                        <span className="font-semibold">Twitter</span>
                      </Label>
                    </div>
                  </RadioGroup>
                  
                  <div className="space-y-2">
                    <Label htmlFor="profile-url">Your {selectedPlatform.charAt(0).toUpperCase() + selectedPlatform.slice(1)} Profile URL</Label>
                    <Input
                      id="profile-url"
                      placeholder={`https://www.${selectedPlatform}.com/yourusername`}
                      value={profileUrl}
                      onChange={(e) => setProfileUrl(e.target.value)}
                    />
                    {error && (
                      <div className="text-destructive text-sm mt-2 flex items-start">
                        <AlertCircle className="h-4 w-4 mr-2 flex-shrink-0 mt-0.5" />
                        <span>{error}</span>
                      </div>
                    )}
                  </div>
                  
                  <div className="bg-amber-50 border border-amber-200 rounded-md p-4 text-amber-800">
                    <div className="flex">
                      <AlertCircle className="h-5 w-5 mr-2 flex-shrink-0" />
                      <div>
                        <p className="text-sm">
                          <strong>Note:</strong> This offer is available only for new customers. 
                          Your account must be public to receive followers.
                        </p>
                      </div>
                    </div>
                  </div>
                  
                  {/* Show API unavailable message if connection failed */}
                  {apiAttemptFailed && !isUsingMockApi && (
                    <div className="bg-red-50 border border-red-200 rounded-md p-4 text-red-800">
                      <div className="flex justify-between items-start">
                        <div className="flex">
                          <AlertCircle className="h-5 w-5 mr-2 flex-shrink-0" />
                          <div>
                            <p className="text-sm">
                              <strong>API Connection Error:</strong> Unable to connect to the service provider.
                            </p>
                          </div>
                        </div>
                        <Button 
                          variant="outline" 
                          size="sm" 
                          className="text-xs border-red-300 hover:bg-red-100 text-red-800"
                          onClick={handleEnableMockMode}
                        >
                          Use Demo Mode
                        </Button>
                      </div>
                    </div>
                  )}
                  
                  {/* Demo mode controls */}
                  {isUsingMockApi ? (
                    <div className="bg-blue-50 border border-blue-200 rounded-md p-3 text-blue-800 text-xs flex justify-between items-center">
                      <div className="flex items-center">
                        <Info className="h-4 w-4 mr-2 flex-shrink-0" />
                        <p>
                          <strong>Demo mode active:</strong> Using simulated responses for demonstration purposes.
                        </p>
                      </div>
                      <Button 
                        variant="outline" 
                        size="sm" 
                        className="text-xs border-blue-300 hover:bg-blue-100"
                        onClick={handleDisableMockMode}
                      >
                        Use Real API
                      </Button>
                    </div>
                  ) : (
                    <div className="flex justify-end">
                      <Button 
                        type="button" 
                        variant="ghost" 
                        size="sm" 
                        className="text-xs text-muted-foreground"
                        onClick={handleEnableMockMode}
                      >
                        Switch to Demo Mode
                      </Button>
                    </div>
                  )}
                  
                  <Button 
                    type="submit" 
                    className="w-full" 
                    disabled={isSubmitting}
                  >
                    {isSubmitting ? (
                      <>
                        <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                        Processing...
                      </>
                    ) : (
                      "Claim 50 Free Followers"
                    )}
                  </Button>
                </form>
              </CardContent>
            </Card>
          )}
        </motion.div>
      </main>
      
      <Footer />
      
      <AuthDialog 
        isOpen={showAuthDialog}
        onClose={() => setShowAuthDialog(false)}
        defaultTab="signup"
      />
    </div>
  );
};

export default FreeFollowers;
