
import { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { toast } from "sonner";
import { checkIsAdmin, getAllTickets, Ticket, TicketResponse } from '@/utils/ticketService';
import { TicketDetails } from '@/components/admin/TicketDetails';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

const AdminTickets = () => {
  const navigate = useNavigate();
  const [tickets, setTickets] = useState<Ticket[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [selectedTicket, setSelectedTicket] = useState<Ticket | null>(null);
  const [activeTab, setActiveTab] = useState('list');
  
  const listTabRef = useRef<HTMLButtonElement>(null);
  const detailTabRef = useRef<HTMLButtonElement>(null);

  useEffect(() => {
    const verifyAdmin = async () => {
      const { isAdmin } = await checkIsAdmin();
      
      if (!isAdmin) {
        toast.error('You do not have admin privileges');
        navigate('/');
      } else {
        fetchTickets();
      }
    };

    verifyAdmin();
  }, [navigate]);

  const fetchTickets = async () => {
    setLoading(true);
    try {
      const result = await getAllTickets();
      
      if (result.success) {
        setTickets(result.data || []);
      } else {
        toast.error(`Failed to fetch tickets: ${result.error}`);
      }
    } catch (error) {
      console.error('Error fetching tickets:', error);
      toast.error('An unexpected error occurred');
    } finally {
      setLoading(false);
    }
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    }).format(date);
  };

  const getStatusColor = (status: string) => {
    switch (status.toLowerCase()) {
      case 'open': return 'bg-blue-500';
      case 'in progress': return 'bg-yellow-500';
      case 'closed': return 'bg-green-500';
      default: return 'bg-gray-500';
    }
  };

  // Filter tickets based on search term and status
  const filteredTickets = tickets.filter(ticket => {
    const matchesSearch = 
      ticket.subject.toLowerCase().includes(searchTerm.toLowerCase()) ||
      ticket.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      ticket.email.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesStatus = statusFilter === 'all' || ticket.status === statusFilter;
    
    return matchesSearch && matchesStatus;
  });

  const switchToDetailTab = () => {
    setActiveTab('detail');
  };

  const switchToListTab = () => {
    setActiveTab('list');
  };

  return (
    <div className="container mx-auto py-10 px-4">
      <h1 className="text-2xl font-bold mb-6">Support Ticket Administration</h1>
      
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="mb-4">
          <TabsTrigger 
            value="list" 
            ref={listTabRef}
          >
            Ticket List
          </TabsTrigger>
          {selectedTicket && (
            <TabsTrigger 
              value="detail"
              ref={detailTabRef}
            >
              Ticket Detail
            </TabsTrigger>
          )}
        </TabsList>
        
        <TabsContent value="list">
          <div className="flex flex-col md:flex-row gap-4 mb-6">
            <div className="flex-1">
              <Input
                placeholder="Search tickets..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="max-w-md"
              />
            </div>
            <Select
              value={statusFilter}
              onValueChange={setStatusFilter}
            >
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Filter by status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Statuses</SelectItem>
                <SelectItem value="open">Open</SelectItem>
                <SelectItem value="in progress">In Progress</SelectItem>
                <SelectItem value="closed">Closed</SelectItem>
              </SelectContent>
            </Select>
            <Button onClick={fetchTickets}>Refresh</Button>
          </div>
          
          {loading ? (
            <p>Loading tickets...</p>
          ) : filteredTickets.length === 0 ? (
            <div className="text-center py-8">
              <p className="text-muted-foreground">No tickets found</p>
            </div>
          ) : (
            <div className="rounded-md border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Date</TableHead>
                    <TableHead>Subject</TableHead>
                    <TableHead>From</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Responses</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredTickets.map((ticket) => (
                    <TableRow key={ticket.id}>
                      <TableCell className="whitespace-nowrap">
                        {formatDate(ticket.created_at)}
                      </TableCell>
                      <TableCell className="font-medium">
                        {ticket.subject}
                      </TableCell>
                      <TableCell>
                        {ticket.name} <br />
                        <span className="text-sm text-muted-foreground">{ticket.email}</span>
                      </TableCell>
                      <TableCell>
                        <Badge className={getStatusColor(ticket.status)}>
                          {ticket.status}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        {ticket.ticket_responses?.length || 0}
                      </TableCell>
                      <TableCell>
                        <Button 
                          variant="outline" 
                          size="sm"
                          onClick={() => {
                            setSelectedTicket(ticket);
                            switchToDetailTab();
                          }}
                        >
                          View
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </TabsContent>
        
        <TabsContent value="detail">
          {selectedTicket ? (
            <div>
              <Button 
                variant="outline" 
                className="mb-4"
                onClick={switchToListTab}
              >
                Back to List
              </Button>
              <TicketDetails 
                ticket={selectedTicket} 
                onUpdate={() => {
                  fetchTickets();
                  // Refresh the selected ticket
                  const updatedTicket = tickets.find(t => t.id === selectedTicket.id);
                  if (updatedTicket) {
                    setSelectedTicket(updatedTicket);
                  }
                }}
              />
            </div>
          ) : (
            <div className="text-center py-8">
              <p className="text-muted-foreground">No ticket selected</p>
              <Button 
                variant="outline" 
                className="mt-4"
                onClick={switchToListTab}
              >
                Back to List
              </Button>
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default AdminTickets;
