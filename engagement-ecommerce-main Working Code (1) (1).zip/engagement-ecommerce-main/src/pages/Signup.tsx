
import { useState } from "react";
import { Rocket } from "lucide-react";
import { useNavigate, Link } from "react-router-dom";
import { SignupForm } from "@/components/auth/SignupForm";

const Signup = () => {
  const navigate = useNavigate();
  
  const handleSignupSuccess = () => {
    navigate("/");
  };

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Simple header */}
      <header className="border-b border-border/30 p-4">
        <div className="container mx-auto">
          <a href="/" className="flex items-center gap-2">
            <Rocket className="h-6 w-6 text-primary" />
            <span className="font-semibold">Social Boost</span>
          </a>
        </div>
      </header>

      {/* Signup form */}
      <div className="flex-1 flex items-center justify-center p-4">
        <div className="w-full max-w-md">
          <div className="bg-card rounded-lg shadow-lg border border-border/30 p-8">
            <div className="text-center mb-8">
              <h1 className="text-2xl font-bold">Create an Account</h1>
              <p className="text-muted-foreground mt-2">Join us and grow your social media presence</p>
            </div>

            <SignupForm onSuccess={handleSignupSuccess} />

            <div className="mt-6 text-center text-sm">
              <p>
                Already have an account?{" "}
                <Link to="/login" className="text-primary hover:underline">
                  Log in
                </Link>
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Signup;
