import { useState, useEffect } from "react";
import { Helmet } from "react-helmet";
import { AudioWaveform } from "lucide-react";
import { PricingCard } from "@/components/PricingCard";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Navbar } from "@/components/layout/Navbar";
import { Footer } from "@/components/layout/Footer";
import { motion } from "framer-motion";

const SoundCloudPackages = () => {
  const [selectedTab, setSelectedTab] = useState("followers");
  const serviceName = "SoundCloud";

  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  const playsPackages = [
    { title: "1K Plays", price: "$0.39", features: ["High Quality", "Fast Delivery", "24/7 Support"] },
    { title: "10K Plays", price: "$3.49", features: ["High Quality", "Fast Delivery", "24/7 Support"] },
    { title: "25K Plays", price: "$5.99", features: ["High Quality", "Fast Delivery", "24/7 Support"] },
    { title: "50K Plays", price: "$9.99", features: ["High Quality", "Fast Delivery", "24/7 Support", "30-Day Refill"] },
    { title: "100K Plays", price: "$16.99", features: ["Premium Quality", "Fast Delivery", "24/7 Support", "30-Day Refill"] },
    { title: "250K Plays", price: "$28.99", features: ["Premium Quality", "Fast Delivery", "24/7 Support", "30-Day Refill"] },
    { title: "500K Plays", price: "$49.99", features: ["Premium Quality", "Gradual Delivery", "24/7 Support", "30-Day Refill"] },
    { title: "1M Plays", price: "$62.99", features: ["Premium Quality", "Gradual Delivery", "24/7 Support", "60-Day Refill"] },
    { title: "2.5M Plays", price: "$107.99", features: ["Premium Quality", "Gradual Delivery", "24/7 Support", "60-Day Refill"] },
    { title: "5M Plays", price: "$189.99", features: ["Premium Quality", "Gradual Delivery", "24/7 Support", "60-Day Refill"] },
  ];

  const likesPackages = [
    { title: "100 Likes", price: "$0.39", features: ["High Quality", "Fast Delivery", "24/7 Support"] },
    { title: "250 Likes", price: "$0.99", features: ["High Quality", "Fast Delivery", "24/7 Support"] },
    { title: "500 Likes", price: "$1.99", features: ["High Quality", "Fast Delivery", "24/7 Support"] },
    { title: "1K Likes", price: "$3.99", features: ["High Quality", "Fast Delivery", "24/7 Support", "30-Day Refill"] },
    { title: "2.5K Likes", price: "$9.19", features: ["High Quality", "Fast Delivery", "24/7 Support", "30-Day Refill"] },
    { title: "5K Likes", price: "$15.99", features: ["Premium Quality", "Fast Delivery", "24/7 Support", "30-Day Refill"] },
    { title: "10K Likes", price: "$27.99", features: ["Premium Quality", "Fast Delivery", "24/7 Support", "30-Day Refill"] },
    { title: "20K Likes", price: "$47.99", features: ["Premium Quality", "Fast Delivery", "24/7 Support", "30-Day Refill"] },
    { title: "50K Likes", price: "$99.99", features: ["Premium Quality", "Gradual Delivery", "24/7 Support", "30-Day Refill"] },
    { title: "100K Likes", price: "$171.99", features: ["Premium Quality", "Gradual Delivery", "24/7 Support", "30-Day Refill"] },
    { title: "200K Likes", price: "$299.99", features: ["Premium Quality", "Gradual Delivery", "24/7 Support", "60-Day Refill"] },
    { title: "500K Likes", price: "$649.99", features: ["Premium Quality", "Gradual Delivery", "24/7 Support", "60-Day Refill"] },
  ];

  const followersPackages = [
    { title: "100 Followers", price: "$0.45", features: ["High Quality", "Fast Delivery", "24/7 Support"] },
    { title: "250 Followers", price: "$1.12", features: ["High Quality", "Fast Delivery", "24/7 Support"] },
    { title: "500 Followers", price: "$2.24", features: ["High Quality", "Fast Delivery", "24/7 Support"] },
    { title: "1K Followers", price: "$4.49", features: ["High Quality", "Fast Delivery", "24/7 Support", "30-Day Refill"] },
    { title: "2.5K Followers", price: "$10.29", features: ["High Quality", "Fast Delivery", "24/7 Support", "30-Day Refill"] },
    { title: "5K Followers", price: "$17.99", features: ["Premium Quality", "Fast Delivery", "24/7 Support", "30-Day Refill"] },
    { title: "10K Followers", price: "$31.49", features: ["Premium Quality", "Fast Delivery", "24/7 Support", "30-Day Refill"] },
    { title: "20K Followers", price: "$53.99", features: ["Premium Quality", "Fast Delivery", "24/7 Support", "30-Day Refill"] },
    { title: "50K Followers", price: "$112.99", features: ["Premium Quality", "Gradual Delivery", "24/7 Support", "30-Day Refill"] },
    { title: "100K Followers", price: "$194.99", features: ["Premium Quality", "Gradual Delivery", "24/7 Support", "30-Day Refill"] },
    { title: "200K Followers", price: "$339.99", features: ["Premium Quality", "Gradual Delivery", "24/7 Support", "60-Day Refill"] },
    { title: "500K Followers", price: "$734.99", features: ["Premium Quality", "Gradual Delivery", "24/7 Support", "60-Day Refill"] },
  ];

  const repostsPackages = [
    { title: "100 Reposts", price: "$0.79", features: ["High Quality", "Fast Delivery", "24/7 Support"] },
    { title: "250 Reposts", price: "$1.99", features: ["High Quality", "Fast Delivery", "24/7 Support"] },
    { title: "500 Reposts", price: "$3.99", features: ["High Quality", "Fast Delivery", "24/7 Support"] },
    { title: "1K Reposts", price: "$7.99", features: ["High Quality", "Fast Delivery", "24/7 Support", "30-Day Refill"] },
    { title: "2.5K Reposts", price: "$18.49", features: ["High Quality", "Fast Delivery", "24/7 Support", "30-Day Refill"] },
    { title: "5K Reposts", price: "$31.99", features: ["Premium Quality", "Fast Delivery", "24/7 Support", "30-Day Refill"] },
    { title: "10K Reposts", price: "$55.99", features: ["Premium Quality", "Fast Delivery", "24/7 Support", "30-Day Refill"] },
    { title: "20K Reposts", price: "$94.99", features: ["Premium Quality", "Fast Delivery", "24/7 Support", "30-Day Refill"] },
    { title: "50K Reposts", price: "$199.99", features: ["Premium Quality", "Gradual Delivery", "24/7 Support", "30-Day Refill"] },
    { title: "100K Reposts", price: "$341.99", features: ["Premium Quality", "Gradual Delivery", "24/7 Support", "30-Day Refill"] },
    { title: "200K Reposts", price: "$586.99", features: ["Premium Quality", "Gradual Delivery", "24/7 Support", "60-Day Refill"] },
    { title: "500K Reposts", price: "$1,249.99", features: ["Premium Quality", "Gradual Delivery", "24/7 Support", "60-Day Refill"] },
  ];

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: { 
      opacity: 1,
      transition: { 
        staggerChildren: 0.05,
        duration: 0.5
      }
    }
  };

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: { y: 0, opacity: 1 }
  };

  return (
    <div className="min-h-screen w-full">
      <Helmet>
        <title>SoundCloud Packages - Social Boost</title>
        <meta name="description" content="Boost your SoundCloud presence with our premium packages" />
      </Helmet>

      <Navbar />
      
      <motion.main 
        className="container mx-auto px-4 py-8"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <motion.div 
          className="mb-8 text-center"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.1 }}
        >
          <div className="flex items-center justify-center mb-4">
            <AudioWaveform className="w-12 h-12 mr-2 text-primary" />
            <h1 className="text-4xl font-bold">SoundCloud Packages</h1>
          </div>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Choose from our range of high-quality SoundCloud services to enhance your music presence
          </p>
        </motion.div>

        <Tabs
          defaultValue="followers"
          value={selectedTab}
          onValueChange={setSelectedTab}
          className="w-full"
        >
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            <TabsList className="grid w-full grid-cols-4 mb-8">
              <TabsTrigger value="followers">Followers</TabsTrigger>
              <TabsTrigger value="likes">Likes</TabsTrigger>
              <TabsTrigger value="plays">Plays</TabsTrigger>
              <TabsTrigger value="reposts">Reposts</TabsTrigger>
            </TabsList>
          </motion.div>

          <TabsContent value="followers" className="mt-6">
            <motion.div 
              className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6"
              variants={containerVariants}
              initial="hidden"
              animate="visible"
            >
              {followersPackages.map((pkg, index) => (
                <motion.div key={index} variants={itemVariants}>
                  <PricingCard
                    title={pkg.title}
                    price={pkg.price}
                    features={pkg.features}
                    icon={<AudioWaveform />}
                    popular={index === 3}
                    service={serviceName}
                    category="Followers"
                  />
                </motion.div>
              ))}
            </motion.div>
          </TabsContent>
          
          <TabsContent value="likes" className="mt-6">
            <motion.div 
              className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6"
              variants={containerVariants}
              initial="hidden"
              animate="visible"
            >
              {likesPackages.map((pkg, index) => (
                <motion.div key={index} variants={itemVariants}>
                  <PricingCard
                    title={pkg.title}
                    price={pkg.price}
                    features={pkg.features}
                    icon={<AudioWaveform />}
                    popular={index === 3}
                    service={serviceName}
                    category="Likes"
                  />
                </motion.div>
              ))}
            </motion.div>
          </TabsContent>

          <TabsContent value="plays" className="mt-6">
            <motion.div 
              className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6"
              variants={containerVariants}
              initial="hidden"
              animate="visible"
            >
              {playsPackages.map((pkg, index) => (
                <motion.div key={index} variants={itemVariants}>
                  <PricingCard
                    title={pkg.title}
                    price={pkg.price}
                    features={pkg.features}
                    icon={<AudioWaveform />}
                    popular={index === 3}
                    service={serviceName}
                    category="Plays"
                  />
                </motion.div>
              ))}
            </motion.div>
          </TabsContent>
          
          <TabsContent value="reposts" className="mt-6">
            <motion.div 
              className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6"
              variants={containerVariants}
              initial="hidden"
              animate="visible"
            >
              {repostsPackages.map((pkg, index) => (
                <motion.div key={index} variants={itemVariants}>
                  <PricingCard
                    title={pkg.title}
                    price={pkg.price}
                    features={pkg.features}
                    icon={<AudioWaveform />}
                    popular={index === 3}
                    service={serviceName}
                    category="Reposts"
                  />
                </motion.div>
              ))}
            </motion.div>
          </TabsContent>
        </Tabs>
      </motion.main>
      
      <Footer />
    </div>
  );
};

export default SoundCloudPackages;
