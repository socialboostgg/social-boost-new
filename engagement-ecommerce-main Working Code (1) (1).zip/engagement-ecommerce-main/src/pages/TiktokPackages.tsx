import { useState, useEffect } from "react";
import { Helmet } from "react-helmet";
import { Navbar } from "@/components/layout/Navbar";
import { Footer } from "@/components/layout/Footer";
import { PricingCard } from "@/components/PricingCard";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { motion } from "framer-motion";

const TiktokPackages = () => {
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  const toggleLoginState = () => {
    setIsLoggedIn(!isLoggedIn);
  };

  const followerPackages = [
    {
      title: "100 Followers",
      price: "$0.99",
      features: ["Delivery within 0-24 hours", "30-day refill guarantee", "24/7 support"],
      popular: false,
    },
    {
      title: "250 Followers",
      price: "$1.99",
      features: ["Delivery within 0-24 hours", "30-day refill guarantee", "24/7 support"],
      popular: false,
    },
    {
      title: "500 Followers",
      price: "$3.99",
      features: ["Delivery within 0-24 hours", "30-day refill guarantee", "24/7 support"],
      popular: false,
    },
    {
      title: "1K Followers",
      price: "$9.99",
      features: ["Delivery within 0-24 hours", "30-day refill guarantee", "24/7 support"],
      popular: true,
    },
    {
      title: "2.5K Followers",
      price: "$14.99",
      features: ["Delivery within 0-24 hours", "30-day refill guarantee", "24/7 support"],
      popular: false,
    },
    {
      title: "5K Followers",
      price: "$24.99",
      features: ["Delivery within 0-24 hours", "30-day refill guarantee", "24/7 support"],
      popular: false,
    },
    {
      title: "10K Followers",
      price: "$39.99",
      features: ["Delivery within 0-24 hours", "30-day refill guarantee", "24/7 support"],
      popular: false,
    },
    {
      title: "20K Followers",
      price: "$69.99",
      features: ["Delivery within 0-24 hours", "30-day refill guarantee", "24/7 support"],
      popular: false,
    },
    {
      title: "50K Followers",
      price: "$124.99",
      features: ["Delivery within 0-24 hours", "30-day refill guarantee", "24/7 support"],
      popular: false,
    },
    {
      title: "100K Followers",
      price: "$229.99",
      features: ["Delivery within 0-24 hours", "30-day refill guarantee", "24/7 support"],
      popular: false,
    },
    {
      title: "200K Followers",
      price: "$439.99",
      features: ["Delivery within 0-24 hours", "30-day refill guarantee", "24/7 support"],
      popular: false,
    },
    {
      title: "500K Followers",
      price: "$799.99",
      features: ["Delivery within 0-24 hours", "30-day refill guarantee", "24/7 support"],
      popular: false,
    },
  ];

  const likePackages = [
    {
      title: "100 Likes",
      price: "$0.69",
      features: ["Delivery within 0-24 hours", "High-quality likes", "24/7 support"],
      popular: false,
    },
    {
      title: "250 Likes",
      price: "$1.49",
      features: ["Delivery within 0-24 hours", "High-quality likes", "24/7 support"],
      popular: false,
    },
    {
      title: "500 Likes",
      price: "$2.99",
      features: ["Delivery within 0-24 hours", "High-quality likes", "24/7 support"],
      popular: false,
    },
    {
      title: "1K Likes",
      price: "$6.99",
      features: ["Delivery within 0-24 hours", "High-quality likes", "24/7 support"],
      popular: true,
    },
    {
      title: "2.5K Likes",
      price: "$10.99",
      features: ["Delivery within 0-24 hours", "High-quality likes", "24/7 support"],
      popular: false,
    },
    {
      title: "5K Likes",
      price: "$17.99",
      features: ["Delivery within 0-24 hours", "High-quality likes", "24/7 support"],
      popular: false,
    },
    {
      title: "10K Likes",
      price: "$29.99",
      features: ["Delivery within 0-24 hours", "High-quality likes", "24/7 support"],
      popular: false,
    },
    {
      title: "20K Likes",
      price: "$49.99",
      features: ["Delivery within 0-24 hours", "High-quality likes", "24/7 support"],
      popular: false,
    },
    {
      title: "50K Likes",
      price: "$89.99",
      features: ["Delivery within 0-24 hours", "High-quality likes", "24/7 support"],
      popular: false,
    },
    {
      title: "100K Likes",
      price: "$169.99",
      features: ["Delivery within 0-24 hours", "High-quality likes", "24/7 support"],
      popular: false,
    },
    {
      title: "200K Likes",
      price: "$329.99",
      features: ["Delivery within 0-24 hours", "High-quality likes", "24/7 support"],
      popular: false,
    },
    {
      title: "500K Likes",
      price: "$599.99",
      features: ["Delivery within 0-24 hours", "High-quality likes", "24/7 support"],
      popular: false,
    },
  ];

  const viewPackages = [
    {
      title: "1K Views",
      price: "$0.69",
      features: ["Delivery within 0-24 hours", "Real views", "24/7 support"],
      popular: false,
    },
    {
      title: "2.5K Views",
      price: "$1.39",
      features: ["Delivery within 0-24 hours", "Real views", "24/7 support"],
      popular: false,
    },
    {
      title: "5K Views",
      price: "$2.79",
      features: ["Delivery within 0-24 hours", "Real views", "24/7 support"],
      popular: false,
    },
    {
      title: "10K Views",
      price: "$4.69",
      features: ["Delivery within 0-24 hours", "Real views", "24/7 support"],
      popular: true,
    },
    {
      title: "20K Views",
      price: "$7.49",
      features: ["Delivery within 0-24 hours", "Real views", "24/7 support"],
      popular: false,
    },
    {
      title: "50K Views",
      price: "$14.99",
      features: ["Delivery within 0-24 hours", "Real views", "24/7 support"],
      popular: false,
    },
    {
      title: "100K Views",
      price: "$24.99",
      features: ["Delivery within 0-24 hours", "Real views", "24/7 support"],
      popular: false,
    },
    {
      title: "250K Views",
      price: "$49.99",
      features: ["Delivery within 0-24 hours", "Real views", "24/7 support"],
      popular: false,
    },
    {
      title: "500K Views",
      price: "$89.99",
      features: ["Delivery within 0-24 hours", "Real views", "24/7 support"],
      popular: false,
    },
    {
      title: "1M Views",
      price: "$169.99",
      features: ["Delivery within 0-24 hours", "Real views", "24/7 support"],
      popular: false,
    },
    {
      title: "2.5M Views",
      price: "$299.99",
      features: ["Delivery within 0-24 hours", "Real views", "24/7 support"],
      popular: false,
    },
  ];

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: { 
      opacity: 1,
      transition: { 
        staggerChildren: 0.05,
        duration: 0.5
      }
    }
  };

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: { y: 0, opacity: 1 }
  };

  return (
    <div className="min-h-screen w-full">
      <Helmet>
        <title>TikTok Packages - Social Boost</title>
        <meta name="description" content="Boost your TikTok presence with our premium packages" />
      </Helmet>

      <Navbar />
      
      <motion.main 
        className="container mx-auto px-4 py-8"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <motion.div 
          className="mb-8 text-center"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.1 }}
        >
          <div className="flex items-center justify-center mb-4">
            <svg className="w-12 h-12 mr-2 text-primary" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M9 12a4 4 0 1 0 4 4V4a5 5 0 0 0 5 5" />
            </svg>
            <h1 className="text-4xl font-bold">TikTok Packages</h1>
          </div>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Choose from our variety of TikTok growth services. All packages come with a satisfaction guarantee and 24/7 support.
          </p>
        </motion.div>

        <Tabs defaultValue="followers" className="w-full">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            <TabsList className="grid w-full grid-cols-3 mb-8">
              <TabsTrigger value="followers">Followers</TabsTrigger>
              <TabsTrigger value="likes">Likes</TabsTrigger>
              <TabsTrigger value="views">Views</TabsTrigger>
            </TabsList>
          </motion.div>
          
          <TabsContent value="followers" className="mt-6">
            <motion.div 
              className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6"
              variants={containerVariants}
              initial="hidden"
              animate="visible"
            >
              {followerPackages.map((pkg, index) => (
                <motion.div key={index} variants={itemVariants}>
                  <PricingCard
                    key={index}
                    title={pkg.title}
                    price={pkg.price}
                    features={pkg.features}
                    icon={
                      <svg className="w-8 h-8" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                        <path d="M9 12a4 4 0 1 0 4 4V4a5 5 0 0 0 5 5" />
                      </svg>
                    }
                    popular={pkg.popular}
                    service="TikTok"
                    category="Followers"
                  />
                </motion.div>
              ))}
            </motion.div>
          </TabsContent>
          
          <TabsContent value="likes" className="mt-6">
            <motion.div 
              className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6"
              variants={containerVariants}
              initial="hidden"
              animate="visible"
            >
              {likePackages.map((pkg, index) => (
                <motion.div key={index} variants={itemVariants}>
                  <PricingCard
                    key={index}
                    title={pkg.title}
                    price={pkg.price}
                    features={pkg.features}
                    icon={
                      <svg className="w-8 h-8" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                        <path d="M9 12a4 4 0 1 0 4 4V4a5 5 0 0 0 5 5" />
                      </svg>
                    }
                    popular={pkg.popular}
                    service="TikTok"
                    category="Likes"
                  />
                </motion.div>
              ))}
            </motion.div>
          </TabsContent>
          
          <TabsContent value="views" className="mt-6">
            <motion.div 
              className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6"
              variants={containerVariants}
              initial="hidden"
              animate="visible"
            >
              {viewPackages.map((pkg, index) => (
                <motion.div key={index} variants={itemVariants}>
                  <PricingCard
                    key={index}
                    title={pkg.title}
                    price={pkg.price}
                    features={pkg.features}
                    icon={
                      <svg className="w-8 h-8" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                        <path d="M9 12a4 4 0 1 0 4 4V4a5 5 0 0 0 5 5" />
                      </svg>
                    }
                    popular={pkg.popular}
                    service="TikTok"
                    category="Views"
                  />
                </motion.div>
              ))}
            </motion.div>
          </TabsContent>
        </Tabs>
      </motion.main>
      
      <Footer />
    </div>
  );
};

export default TiktokPackages;
