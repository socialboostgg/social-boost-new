
import { useState } from "react";
import { Helmet } from "react-helmet";
import { Ticket, Loader2, Clock, MessageSquare, AlertCircle, HelpCircle, Plus } from "lucide-react";
import { Navbar } from "@/components/layout/Navbar";
import { Footer } from "@/components/layout/Footer";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/context/AuthContext";
import { getTickets } from "@/utils/ticketService";
import { useQuery } from "@tanstack/react-query";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";

const TicketStatusBadge = ({ status }: { status: string }) => {
  switch (status) {
    case 'open':
      return (
        <Badge variant="secondary" className="bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300 border-none">
          Open
        </Badge>
      );
    case 'in_progress':
      return (
        <Badge variant="secondary" className="bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300 border-none">
          In Progress
        </Badge>
      );
    case 'closed':
      return (
        <Badge variant="secondary" className="bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300 border-none">
          Closed
        </Badge>
      );
    default:
      return (
        <Badge variant="secondary">
          {status}
        </Badge>
      );
  }
};

const Tickets = () => {
  const { isLoggedIn, user } = useAuth();
  
  // Fetch tickets
  const { data: ticketsData, isLoading, error, refetch } = useQuery({
    queryKey: ['tickets', user?.id],
    queryFn: getTickets,
    enabled: isLoggedIn,
  });

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: { 
      opacity: 1,
      transition: { 
        staggerChildren: 0.05,
        duration: 0.5
      }
    }
  };

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: { y: 0, opacity: 1 }
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Helmet>
        <title>My Tickets - Social Boost</title>
        <meta name="description" content="View and manage your support tickets" />
      </Helmet>
      
      <Navbar />
      
      <motion.main 
        className="flex-grow container mx-auto px-4 py-8"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <div className="flex items-center justify-center mb-8">
          <Ticket className="w-10 h-10 mr-3 text-primary" />
          <h1 className="text-3xl font-bold">My Support Tickets</h1>
        </div>
        
        {/* New section for creating tickets */}
        <motion.div 
          className="max-w-4xl mx-auto mb-8"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2, duration: 0.5 }}
        >
          <Card>
            <CardContent className="p-6">
              <div className="flex flex-col md:flex-row items-center justify-between gap-4">
                <div className="flex items-center">
                  <HelpCircle className="w-6 h-6 mr-3 text-primary" />
                  <p className="text-lg">To open a new ticket, please visit the support page.</p>
                </div>
                <Link to="/support">
                  <Button className="whitespace-nowrap">
                    <Plus className="mr-2 h-4 w-4" />
                    Create Ticket
                  </Button>
                </Link>
              </div>
            </CardContent>
          </Card>
        </motion.div>
        
        <motion.div 
          className="max-w-4xl mx-auto"
          variants={containerVariants}
          initial="hidden"
          animate="visible"
        >
          {!isLoggedIn ? (
            <Card className="mb-8">
              <CardContent className="pt-6 text-center">
                <AlertCircle className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
                <h2 className="text-xl font-semibold mb-2">Please Log In</h2>
                <p className="text-muted-foreground mb-4">You need to be logged in to view your tickets</p>
                <Link to="/login">
                  <Button>Log In Now</Button>
                </Link>
              </CardContent>
            </Card>
          ) : isLoading ? (
            <div className="flex items-center justify-center py-12">
              <Loader2 className="w-8 h-8 animate-spin text-primary mr-2" />
              <span>Loading your tickets...</span>
            </div>
          ) : error || (ticketsData && 'error' in ticketsData) ? (
            <Card className="mb-8">
              <CardContent className="pt-6 text-center">
                <AlertCircle className="w-12 h-12 mx-auto mb-4 text-destructive" />
                <h2 className="text-xl font-semibold mb-2">Failed to Load Tickets</h2>
                <p className="text-muted-foreground mb-4">
                  {ticketsData && 'error' in ticketsData 
                    ? (ticketsData.error as string) 
                    : "An error occurred while loading your tickets."}
                </p>
                <Button onClick={() => refetch()}>Try Again</Button>
              </CardContent>
            </Card>
          ) : ticketsData && 'tickets' in ticketsData && ticketsData.tickets && ticketsData.tickets.length > 0 ? (
            <div className="space-y-4">
              {ticketsData.tickets.map((ticket) => (
                <motion.div key={ticket.id} variants={itemVariants}>
                  <Card className="overflow-hidden">
                    <CardHeader className="pb-3">
                      <div className="flex justify-between items-center">
                        <CardTitle className="text-xl">{ticket.subject}</CardTitle>
                        <TicketStatusBadge status={ticket.status} />
                      </div>
                    </CardHeader>
                    <CardContent>
                      <p className="text-muted-foreground mb-4">{ticket.message}</p>
                      <div className="flex flex-wrap gap-4 text-sm text-muted-foreground">
                        <div className="flex items-center">
                          <Clock className="h-4 w-4 mr-1" />
                          <span>Created: {new Date(ticket.created_at).toLocaleDateString()}</span>
                        </div>
                        <div className="flex items-center">
                          <MessageSquare className="h-4 w-4 mr-1" />
                          <span>
                            {ticket.ticket_responses?.length || 0} {ticket.ticket_responses?.length === 1 ? 'response' : 'responses'}
                          </span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          ) : (
            <Card className="mb-8">
              <CardContent className="pt-6 text-center">
                <Ticket className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
                <h2 className="text-xl font-semibold mb-2">No Tickets Found</h2>
                <p className="text-muted-foreground mb-4">You haven't submitted any support tickets yet.</p>
                <Link to="/support">
                  <Button>Create a Support Ticket</Button>
                </Link>
              </CardContent>
            </Card>
          )}
        </motion.div>
      </motion.main>
      
      <Footer />
    </div>
  );
};

export default Tickets;

