
import { useState } from "react";
import { Helmet } from "react-helmet";
import { HelpCircle, Mail, MessageSquare, Clock, Ticket as TicketIcon, Loader2 } from "lucide-react";
import { Navbar } from "@/components/layout/Navbar";
import { Footer } from "@/components/layout/Footer";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card } from "@/components/ui/card";
import { motion } from "framer-motion";
import { Label } from "@/components/ui/label";
import { createTicket, getTickets } from "@/utils/ticketService";
import { useAuth } from "@/context/AuthContext";
import { toast } from "sonner";
import { useQuery } from "@tanstack/react-query";
import { Link } from "react-router-dom";

const Support = () => {
  const { isLoggedIn, user } = useAuth();
  const [formData, setFormData] = useState({
    name: user?.fullName || "",
    email: user?.email || "",
    subject: "",
    message: ""
  });
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Fetch tickets if user is logged in
  const { data: ticketsData, isLoading: isLoadingTickets, refetch } = useQuery({
    queryKey: ['tickets', user?.id],
    queryFn: getTickets,
    enabled: isLoggedIn,
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { id, value } = e.target;
    setFormData(prev => ({ ...prev, [id]: value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Check if the user is logged in
    if (!isLoggedIn) {
      toast.error("Please log in to submit a ticket");
      return;
    }
    
    setIsSubmitting(true);

    try {
      // Validate form
      if (!formData.name || !formData.email || !formData.subject || !formData.message) {
        toast.error("Please fill in all fields");
        setIsSubmitting(false);
        return;
      }

      const result = await createTicket(formData);
      
      if (result.success) {
        toast.success("Support ticket submitted successfully!");
        // Reset form
        setFormData({
          name: user?.fullName || "",
          email: user?.email || "",
          subject: "",
          message: ""
        });
        
        // If user is logged in, refresh tickets list
        if (isLoggedIn) {
          refetch();
        }
      } else {
        toast.error(result.error || "Failed to submit ticket");
      }
    } catch (error) {
      console.error("Error submitting ticket:", error);
      toast.error("An unexpected error occurred");
    } finally {
      setIsSubmitting(false);
    }
  };

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: { 
      opacity: 1,
      transition: { 
        staggerChildren: 0.05,
        duration: 0.5
      }
    }
  };

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: { y: 0, opacity: 1 }
  };

  return (
    <div className="min-h-screen w-full">
      <Helmet>
        <title>Support - Social Boost</title>
        <meta name="description" content="Get help with your social media growth services" />
      </Helmet>
      
      <Navbar />
      
      <motion.main 
        className="container mx-auto px-4 py-8"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <motion.div 
          className="mb-8 text-center"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.1 }}
        >
          <div className="flex items-center justify-center mb-4">
            <HelpCircle className="w-12 h-12 mr-2 text-primary" />
            <h1 className="text-4xl font-bold">Support Center</h1>
          </div>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            We're here to help with any questions or issues you might have
          </p>
          
          <div className="flex items-center justify-center mt-4 space-x-6">
            <div className="flex items-center">
              <Mail className="w-5 h-5 mr-2 text-primary" />
              <a href="mailto:support@socialboost.com" className="text-muted-foreground hover:text-primary transition-colors">support@socialboost.com</a>
            </div>
            <div className="flex items-center">
              <Clock className="w-5 h-5 mr-2 text-primary" />
              <span className="text-muted-foreground">Response Time: 24-48 hours</span>
            </div>
          </div>
        </motion.div>
      
        <Tabs defaultValue="tickets" className="w-full">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            <TabsList className="grid w-full grid-cols-2 mb-8">
              <TabsTrigger value="tickets">Tickets</TabsTrigger>
              <TabsTrigger value="faq">FAQ</TabsTrigger>
            </TabsList>
          </motion.div>
          
          <TabsContent value="tickets" className="mt-6">
            <motion.div 
              className="grid grid-cols-1 md:grid-cols-2 gap-6"
              variants={containerVariants}
              initial="hidden"
              animate="visible"
            >
              <motion.div variants={itemVariants}>
                <Card className="p-6">
                  <h3 className="text-xl font-semibold mb-4">Submit a Ticket</h3>
                  {isLoggedIn ? (
                    <form onSubmit={handleSubmit} className="space-y-4">
                      <div>
                        <Label htmlFor="name">Name</Label>
                        <Input 
                          id="name" 
                          type="text" 
                          placeholder="Your Name" 
                          value={formData.name}
                          onChange={handleInputChange}
                          required
                        />
                      </div>
                      <div>
                        <Label htmlFor="email">Email</Label>
                        <Input 
                          id="email" 
                          type="email" 
                          placeholder="Your Email" 
                          value={formData.email}
                          onChange={handleInputChange}
                          required
                        />
                      </div>
                      <div>
                        <Label htmlFor="subject">Subject</Label>
                        <Input 
                          id="subject" 
                          type="text" 
                          placeholder="Ticket Subject" 
                          value={formData.subject}
                          onChange={handleInputChange}
                          required
                        />
                      </div>
                      <div>
                        <Label htmlFor="message">Message</Label>
                        <Textarea 
                          id="message" 
                          placeholder="Describe your issue in detail" 
                          value={formData.message}
                          onChange={handleInputChange}
                          required
                        />
                      </div>
                      <Button 
                        type="submit" 
                        className="w-full" 
                        disabled={isSubmitting}
                      >
                        {isSubmitting ? (
                          <>
                            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                            Submitting...
                          </>
                        ) : (
                          "Submit Ticket"
                        )}
                      </Button>
                    </form>
                  ) : (
                    <div className="space-y-4 text-center">
                      <p className="text-muted-foreground">You need to be logged in to submit a support ticket.</p>
                      <Link to="/login">
                        <Button className="w-full">Log In to Submit a Ticket</Button>
                      </Link>
                    </div>
                  )}
                </Card>
              </motion.div>
              
              <motion.div variants={itemVariants}>
                <Card className="p-6">
                  <h3 className="text-xl font-semibold mb-4">Ticket Information</h3>
                  <div className="space-y-4">
                    <p className="text-muted-foreground">Submit a support ticket for any technical issues, account problems, or other concerns. Our support team will get back to you as soon as possible.</p>
                    <div className="flex items-center">
                      <TicketIcon className="w-5 h-5 mr-2 text-muted-foreground" />
                      <span className="text-muted-foreground">Track your tickets in your account</span>
                    </div>
                    <div className="flex items-center">
                      <Clock className="w-5 h-5 mr-2 text-muted-foreground" />
                      <span className="text-muted-foreground">Average response time: 24 hours</span>
                    </div>
                    <div className="flex items-center">
                      <MessageSquare className="w-5 h-5 mr-2 text-muted-foreground" />
                      <span className="text-muted-foreground">Live Chat available 9am - 5pm EST</span>
                    </div>
                  </div>
                </Card>
              </motion.div>

              {isLoggedIn && (
                <motion.div variants={itemVariants} className="md:col-span-2">
                  <Card className="p-6">
                    <h3 className="text-xl font-semibold mb-4">Your Tickets</h3>
                    {isLoadingTickets ? (
                      <div className="flex items-center justify-center py-10">
                        <Loader2 className="w-8 h-8 animate-spin text-primary" />
                      </div>
                    ) : ticketsData && 'error' in ticketsData ? (
                      <div className="text-center py-6">
                        <p className="text-muted-foreground">{ticketsData.error as string}</p>
                      </div>
                    ) : ticketsData && 'tickets' in ticketsData && ticketsData.tickets && ticketsData.tickets.length > 0 ? (
                      <div className="space-y-4">
                        {ticketsData.tickets.map((ticket) => (
                          <div key={ticket.id} className="border rounded-md p-4">
                            <div className="flex justify-between items-start mb-2">
                              <h4 className="font-medium">{ticket.subject}</h4>
                              <span className={`px-2 py-1 text-xs rounded-full ${
                                ticket.status === 'open' 
                                  ? 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300' 
                                  : ticket.status === 'in_progress'
                                  ? 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300'
                                  : 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300'
                              }`}>
                                {ticket.status === 'open' ? 'Open' : ticket.status === 'in_progress' ? 'In Progress' : 'Closed'}
                              </span>
                            </div>
                            <p className="text-sm text-muted-foreground mb-2 line-clamp-2">{ticket.message}</p>
                            <div className="text-xs text-muted-foreground">
                              Created: {new Date(ticket.created_at).toLocaleDateString()}
                            </div>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <div className="text-center py-10">
                        <p className="text-muted-foreground">You haven't submitted any tickets yet.</p>
                      </div>
                    )}
                  </Card>
                </motion.div>
              )}
            </motion.div>
          </TabsContent>
          
          <TabsContent value="faq" className="mt-6">
            <motion.div 
              className="space-y-6"
              variants={containerVariants}
              initial="hidden"
              animate="visible"
            >
              <motion.div variants={itemVariants}>
                <h3 className="text-xl font-semibold mb-2">What is Social Boost?</h3>
                <p className="text-muted-foreground">Social Boost is a platform that provides social media growth services to help you increase your online presence.</p>
              </motion.div>
              
              <motion.div variants={itemVariants}>
                <h3 className="text-xl font-semibold mb-2">How do I get started?</h3>
                <p className="text-muted-foreground">Simply browse our services, choose a package, and complete your order. We'll take care of the rest!</p>
              </motion.div>
              
              <motion.div variants={itemVariants}>
                <h3 className="text-xl font-semibold mb-2">What payment methods do you accept?</h3>
                <p className="text-muted-foreground">We accept all major credit cards, PayPal, and cryptocurrency.</p>
              </motion.div>
            </motion.div>
          </TabsContent>
        </Tabs>
      </motion.main>
      
      <Footer />
    </div>
  );
};

export default Support;
