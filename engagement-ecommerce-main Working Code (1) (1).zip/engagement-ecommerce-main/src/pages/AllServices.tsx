
import { useEffect } from "react";
import { Helmet } from "react-helmet";
import { Navbar } from "@/components/layout/Navbar";
import { Footer } from "@/components/layout/Footer";
import { AllServicesList } from "@/components/services/AllServicesList";
import { motion } from "framer-motion";
import { useAuth } from "@/context/AuthContext";

const AllServices = () => {
  const { isLoggedIn } = useAuth();

  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  return (
    <div className="min-h-screen w-full">
      <Helmet>
        <title>All Services - Social Boost</title>
        <meta name="description" content="Complete list of our social media growth services" />
      </Helmet>
      
      <Navbar />
      
      <motion.main 
        className="container mx-auto px-4 py-8"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <motion.div 
          className="mb-12 text-center"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.1 }}
        >
          <span className="inline-block px-3 py-1 text-sm font-semibold bg-primary/10 text-primary rounded-full mb-4">
            All Services
          </span>
          <h1 className="text-3xl md:text-4xl font-bold mb-4">Grow Your Social Media Presence</h1>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Choose from our complete range of high-quality services to enhance your presence across all social media platforms
          </p>
        </motion.div>
        
        <AllServicesList />
      </motion.main>
      
      <Footer />
    </div>
  );
};

export default AllServices;
