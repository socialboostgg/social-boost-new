import { useState, useEffect } from "react";
import { Helmet } from "react-helmet";
import { Send } from "lucide-react";
import { PricingCard } from "@/components/PricingCard";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Navbar } from "@/components/layout/Navbar";
import { Footer } from "@/components/layout/Footer";
import { motion } from "framer-motion";

const TelegramPackages = () => {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  const [isLoggedIn, setIsLoggedIn] = useState(false);

  const toggleLoginState = () => {
    setIsLoggedIn(!isLoggedIn);
  };

  const membersPackages = [
    { title: "100 Members", price: "$0.69", features: ["Real members", "Fast delivery", "24/7 support"] },
    { title: "250 Members", price: "$1.74", features: ["Real members", "Fast delivery", "24/7 support"] },
    { title: "500 Members", price: "$3.49", features: ["Real members", "Fast delivery", "24/7 support"] },
    { title: "1K Members", price: "$6.99", features: ["Real members", "Fast delivery", "24/7 support"], popular: true },
    { title: "2.5K Members", price: "$16.29", features: ["Real members", "Fast delivery", "24/7 support"] },
    { title: "5K Members", price: "$28.99", features: ["Real members", "Fast delivery", "24/7 support"] },
    { title: "10K Members", price: "$50.99", features: ["Real members", "Fast delivery", "24/7 support"] },
    { title: "20K Members", price: "$86.99", features: ["Real members", "Fast delivery", "24/7 support"] },
    { title: "50K Members", price: "$184.99", features: ["Real members", "Fast delivery", "24/7 support"] },
    { title: "100K Members", price: "$316.99", features: ["Real members", "Fast delivery", "24/7 support"] },
    { title: "200K Members", price: "$539.99", features: ["Real members", "Fast delivery", "24/7 support"] },
    { title: "500K Members", price: "$1,149.99", features: ["Real members", "Fast delivery", "24/7 support"] },
  ];

  const viewsPackages = [
    { title: "1K Views", price: "$0.99", features: ["High quality", "Fast delivery", "24/7 support"] },
    { title: "2.5K Views", price: "$2.99", features: ["High quality", "Fast delivery", "24/7 support"] },
    { title: "5K Views", price: "$4.99", features: ["High quality", "Fast delivery", "24/7 support"] },
    { title: "10K Views", price: "$4.99", features: ["High quality", "Fast delivery", "24/7 support"], popular: true },
    { title: "15K Views", price: "$6.99", features: ["High quality", "Fast delivery", "24/7 support"] },
    { title: "25K Views", price: "$8.49", features: ["High quality", "Fast delivery", "24/7 support"] },
    { title: "50K Views", price: "$14.99", features: ["High quality", "Fast delivery", "24/7 support"] },
    { title: "75K Views", price: "$18.49", features: ["High quality", "Fast delivery", "24/7 support"] },
    { title: "100K Views", price: "$24.99", features: ["High quality", "Fast delivery", "24/7 support"] },
    { title: "150K Views", price: "$34.99", features: ["High quality", "Fast delivery", "24/7 support"] },
    { title: "250K Views", price: "$42.99", features: ["High quality", "Fast delivery", "24/7 support"] },
    { title: "500K Views", price: "$73.99", features: ["High quality", "Fast delivery", "24/7 support"] },
  ];

  const pastPostsViewsPackages = [
    { title: "1K Past 10 Posts Views", price: "$3.99", features: ["Last 10 posts", "Fast delivery", "24/7 support"] },
    { title: "2.5K Past 10 Posts Views", price: "$7.49", features: ["Last 10 posts", "Fast delivery", "24/7 support"] },
    { title: "5K Past 10 Posts Views", price: "$11.99", features: ["Last 10 posts", "Fast delivery", "24/7 support"] },
    { title: "10K Past 10 Posts Views", price: "$13.99", features: ["Last 10 posts", "Fast delivery", "24/7 support"], popular: true },
    { title: "15K Past 10 Posts Views", price: "$18.49", features: ["Last 10 posts", "Fast delivery", "24/7 support"] },
    { title: "25K Past 10 Posts Views", price: "$24.99", features: ["Last 10 posts", "Fast delivery", "24/7 support"] },
    { title: "50K Past 10 Posts Views", price: "$34.99", features: ["Last 10 posts", "Fast delivery", "24/7 support"] },
    { title: "75K Past 10 Posts Views", price: "$44.99", features: ["Last 10 posts", "Fast delivery", "24/7 support"] },
    { title: "100K Past 10 Posts Views", price: "$59.99", features: ["Last 10 posts", "Fast delivery", "24/7 support"] },
    { title: "150K Past 10 Posts Views", price: "$83.99", features: ["Last 10 posts", "Fast delivery", "24/7 support"] },
    { title: "250K Past 10 Posts Views", price: "$94.99", features: ["Last 10 posts", "Fast delivery", "24/7 support"] },
    { title: "500K Past 10 Posts Views", price: "$149.99", features: ["Last 10 posts", "Fast delivery", "24/7 support"] },
  ];

  const pollVotesPackages = [
    { title: "100 Poll Votes", price: "$0.75", features: ["Real votes", "Fast delivery", "24/7 support"] },
    { title: "250 Poll Votes", price: "$1.87", features: ["Real votes", "Fast delivery", "24/7 support"] },
    { title: "500 Poll Votes", price: "$3.74", features: ["Real votes", "Fast delivery", "24/7 support"] },
    { title: "1K Poll Votes", price: "$7.49", features: ["Real votes", "Fast delivery", "24/7 support"], popular: true },
    { title: "2.5K Poll Votes", price: "$17.29", features: ["Real votes", "Fast delivery", "24/7 support"] },
    { title: "5K Poll Votes", price: "$29.99", features: ["Real votes", "Fast delivery", "24/7 support"] },
    { title: "10K Poll Votes", price: "$52.49", features: ["Real votes", "Fast delivery", "24/7 support"] },
    { title: "20K Poll Votes", price: "$88.99", features: ["Real votes", "Fast delivery", "24/7 support"] },
    { title: "50K Poll Votes", price: "$186.99", features: ["Real votes", "Fast delivery", "24/7 support"] },
    { title: "100K Poll Votes", price: "$319.99", features: ["Real votes", "Fast delivery", "24/7 support"] },
    { title: "200K Poll Votes", price: "$549.99", features: ["Real votes", "Fast delivery", "24/7 support"] },
    { title: "500K Poll Votes", price: "$1,169.99", features: ["Real votes", "Fast delivery", "24/7 support"] },
  ];

  const reactionsPackages = [
    { title: "100 Reactions", price: "$0.35", features: ["Real reactions", "Fast delivery", "24/7 support"] },
    { title: "250 Reactions", price: "$0.87", features: ["Real reactions", "Fast delivery", "24/7 support"] },
    { title: "500 Reactions", price: "$1.74", features: ["Real reactions", "Fast delivery", "24/7 support"] },
    { title: "1K Reactions", price: "$3.49", features: ["Real reactions", "Fast delivery", "24/7 support"], popular: true },
    { title: "2.5K Reactions", price: "$8.09", features: ["Real reactions", "Fast delivery", "24/7 support"] },
    { title: "5K Reactions", price: "$14.99", features: ["Real reactions", "Fast delivery", "24/7 support"] },
    { title: "10K Reactions", price: "$26.99", features: ["Real reactions", "Fast delivery", "24/7 support"] },
    { title: "20K Reactions", price: "$46.99", features: ["Real reactions", "Fast delivery", "24/7 support"] },
    { title: "50K Reactions", price: "$99.99", features: ["Real reactions", "Fast delivery", "24/7 support"] },
    { title: "100K Reactions", price: "$171.99", features: ["Real reactions", "Fast delivery", "24/7 support"] },
    { title: "200K Reactions", price: "$299.99", features: ["Real reactions", "Fast delivery", "24/7 support"] },
    { title: "500K Reactions", price: "$649.99", features: ["Real reactions", "Fast delivery", "24/7 support"] },
  ];

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: { 
      opacity: 1,
      transition: { 
        staggerChildren: 0.05,
        duration: 0.5
      }
    }
  };

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: { y: 0, opacity: 1 }
  };

  return (
    <div className="min-h-screen w-full">
      <Helmet>
        <title>Telegram Packages - Social Boost</title>
        <meta name="description" content="Boost your Telegram channel with our premium packages" />
      </Helmet>
      
      <Navbar />
      
      <motion.main 
        className="container mx-auto px-4 py-8"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <motion.div 
          className="mb-8 text-center"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.1 }}
        >
          <div className="flex items-center justify-center mb-4">
            <Send className="w-12 h-12 mr-2 text-primary" />
            <h1 className="text-4xl font-bold">Telegram Packages</h1>
          </div>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Choose from our range of Telegram growth services to enhance your channel presence
          </p>
        </motion.div>

        <Tabs defaultValue="members" className="w-full">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            <TabsList className="grid w-full grid-cols-1 md:grid-cols-5 mb-8">
              <TabsTrigger value="members">Members</TabsTrigger>
              <TabsTrigger value="views">Views</TabsTrigger>
              <TabsTrigger value="pastposts">Past 10 Posts Views</TabsTrigger>
              <TabsTrigger value="pollvotes">Poll Votes</TabsTrigger>
              <TabsTrigger value="reactions">Reactions</TabsTrigger>
            </TabsList>
          </motion.div>
          
          <TabsContent value="members" className="mt-6">
            <motion.div 
              className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6"
              variants={containerVariants}
              initial="hidden"
              animate="visible"
            >
              {membersPackages.map((pkg, index) => (
                <motion.div key={index} variants={itemVariants}>
                  <PricingCard
                    title={pkg.title}
                    price={pkg.price}
                    features={pkg.features}
                    icon={<Send />}
                    popular={pkg.popular}
                    service="Telegram"
                    category="Members"
                  />
                </motion.div>
              ))}
            </motion.div>
          </TabsContent>
          
          <TabsContent value="views" className="mt-6">
            <motion.div 
              className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6"
              variants={containerVariants}
              initial="hidden"
              animate="visible"
            >
              {viewsPackages.map((pkg, index) => (
                <motion.div key={index} variants={itemVariants}>
                  <PricingCard
                    title={pkg.title}
                    price={pkg.price}
                    features={pkg.features}
                    icon={<Send />}
                    popular={pkg.popular}
                    service="Telegram"
                    category="Views"
                  />
                </motion.div>
              ))}
            </motion.div>
          </TabsContent>
          
          <TabsContent value="pastposts" className="mt-6">
            <motion.div 
              className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6"
              variants={containerVariants}
              initial="hidden"
              animate="visible"
            >
              {pastPostsViewsPackages.map((pkg, index) => (
                <motion.div key={index} variants={itemVariants}>
                  <PricingCard
                    title={pkg.title}
                    price={pkg.price}
                    features={pkg.features}
                    icon={<Send />}
                    popular={pkg.popular}
                    service="Telegram"
                    category="Past 10 Posts Views"
                  />
                </motion.div>
              ))}
            </motion.div>
          </TabsContent>
          
          <TabsContent value="pollvotes" className="mt-6">
            <motion.div 
              className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6"
              variants={containerVariants}
              initial="hidden"
              animate="visible"
            >
              {pollVotesPackages.map((pkg, index) => (
                <motion.div key={index} variants={itemVariants}>
                  <PricingCard
                    title={pkg.title}
                    price={pkg.price}
                    features={pkg.features}
                    icon={<Send />}
                    popular={pkg.popular}
                    service="Telegram"
                    category="Poll Votes"
                  />
                </motion.div>
              ))}
            </motion.div>
          </TabsContent>
          
          <TabsContent value="reactions" className="mt-6">
            <motion.div 
              className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6"
              variants={containerVariants}
              initial="hidden"
              animate="visible"
            >
              {reactionsPackages.map((pkg, index) => (
                <motion.div key={index} variants={itemVariants}>
                  <PricingCard
                    title={pkg.title}
                    price={pkg.price}
                    features={pkg.features}
                    icon={<Send />}
                    popular={pkg.popular}
                    service="Telegram"
                    category="Reactions"
                  />
                </motion.div>
              ))}
            </motion.div>
          </TabsContent>
        </Tabs>
      </motion.main>
      
      <Footer />
    </div>
  );
};

export default TelegramPackages;
