
import { useState, useEffect } from "react";
import { Helmet } from "react-helmet";
import { Twitch } from "lucide-react";
import { PricingCard } from "@/components/PricingCard";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Navbar } from "@/components/layout/Navbar";
import { Footer } from "@/components/layout/Footer";
import { motion } from "framer-motion";

const TwitchPackages = () => {
  const serviceName = "Twitch";

  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  const followerPackages = [
    { title: "100 Followers", price: "$0.79", features: ["High Quality", "Fast Delivery", "24/7 Support"] },
    { title: "250 Followers", price: "$1.99", features: ["High Quality", "Fast Delivery", "24/7 Support"] },
    { title: "500 Followers", price: "$3.99", features: ["High Quality", "Fast Delivery", "24/7 Support"] },
    { title: "1K Followers", price: "$7.99", features: ["High Quality", "Fast Delivery", "24/7 Support", "30-Day Refill"] },
    { title: "2.5K Followers", price: "$18.49", features: ["High Quality", "Fast Delivery", "24/7 Support", "30-Day Refill"] },
    { title: "5K Followers", price: "$31.99", features: ["Premium Quality", "Fast Delivery", "24/7 Support", "30-Day Refill"] },
    { title: "10K Followers", price: "$55.99", features: ["Premium Quality", "Fast Delivery", "24/7 Support", "30-Day Refill"] },
    { title: "20K Followers", price: "$94.99", features: ["Premium Quality", "Fast Delivery", "24/7 Support", "30-Day Refill"] },
    { title: "50K Followers", price: "$199.99", features: ["Premium Quality", "Gradual Delivery", "24/7 Support", "30-Day Refill"] },
    { title: "100K Followers", price: "$341.99", features: ["Premium Quality", "Gradual Delivery", "24/7 Support", "30-Day Refill"] },
    { title: "200K Followers", price: "$586.99", features: ["Premium Quality", "Gradual Delivery", "24/7 Support", "60-Day Refill"] },
    { title: "500K Followers", price: "$1,249.99", features: ["Premium Quality", "Gradual Delivery", "24/7 Support", "60-Day Refill"] },
  ];

  const viewPackages = [
    { title: "100 Live Viewers", price: "$1.99", features: ["High Quality", "Fast Delivery", "24/7 Support"] },
    { title: "250 Live Viewers", price: "$4.99", features: ["High Quality", "Fast Delivery", "24/7 Support"] },
    { title: "500 Live Viewers", price: "$9.99", features: ["High Quality", "Fast Delivery", "24/7 Support"] },
    { title: "1K Live Viewers", price: "$19.99", features: ["High Quality", "Fast Delivery", "24/7 Support", "30-Day Refill"] },
    { title: "2.5K Live Viewers", price: "$45.49", features: ["High Quality", "Fast Delivery", "24/7 Support", "30-Day Refill"] },
    { title: "5K Live Viewers", price: "$77.99", features: ["Premium Quality", "Fast Delivery", "24/7 Support", "30-Day Refill"] },
    { title: "10K Live Viewers", price: "$134.99", features: ["Premium Quality", "Fast Delivery", "24/7 Support", "30-Day Refill"] },
    { title: "20K Live Viewers", price: "$229.99", features: ["Premium Quality", "Fast Delivery", "24/7 Support", "30-Day Refill"] },
    { title: "50K Live Viewers", price: "$474.99", features: ["Premium Quality", "Gradual Delivery", "24/7 Support", "30-Day Refill"] },
    { title: "100K Live Viewers", price: "$809.99", features: ["Premium Quality", "Gradual Delivery", "24/7 Support", "30-Day Refill"] },
    { title: "200K Live Viewers", price: "$1,379.99", features: ["Premium Quality", "Gradual Delivery", "24/7 Support", "60-Day Refill"] },
    { title: "500K Live Viewers", price: "$2,849.99", features: ["Premium Quality", "Gradual Delivery", "24/7 Support", "60-Day Refill"] },
  ];

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: { 
      opacity: 1,
      transition: { 
        staggerChildren: 0.05,
        duration: 0.5
      }
    }
  };

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: { y: 0, opacity: 1 }
  };

  return (
    <div className="min-h-screen w-full">
      <Helmet>
        <title>Twitch Packages - Social Boost</title>
        <meta name="description" content="Boost your Twitch presence with our premium packages" />
      </Helmet>

      <Navbar />
      
      <motion.main 
        className="container mx-auto px-4 py-8"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <motion.div 
          className="mb-8 text-center"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.1 }}
        >
          <div className="flex items-center justify-center mb-4">
            <Twitch className="w-12 h-12 mr-2 text-primary" />
            <h1 className="text-4xl font-bold">Twitch Packages</h1>
          </div>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Choose from our range of high-quality Twitch services to enhance your streaming presence
          </p>
        </motion.div>

        <Tabs defaultValue="followers" className="w-full">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            <TabsList className="grid w-full grid-cols-2 mb-8">
              <TabsTrigger value="followers">Followers</TabsTrigger>
              <TabsTrigger value="views">Live Viewers</TabsTrigger>
            </TabsList>
          </motion.div>

          <TabsContent value="followers" className="mt-6">
            <motion.div 
              className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6"
              variants={containerVariants}
              initial="hidden"
              animate="visible"
            >
              {followerPackages.map((pkg, index) => (
                <motion.div key={index} variants={itemVariants}>
                  <PricingCard
                    title={pkg.title}
                    price={pkg.price}
                    features={pkg.features}
                    icon={<Twitch />}
                    popular={index === 3}
                    service="Twitch"
                    category="Followers"
                  />
                </motion.div>
              ))}
            </motion.div>
          </TabsContent>
          
          <TabsContent value="views" className="mt-6">
            <motion.div 
              className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6"
              variants={containerVariants}
              initial="hidden"
              animate="visible"
            >
              {viewPackages.map((pkg, index) => (
                <motion.div key={index} variants={itemVariants}>
                  <PricingCard
                    title={pkg.title}
                    price={pkg.price}
                    features={pkg.features}
                    icon={<Twitch />}
                    popular={index === 3}
                    service="Twitch"
                    category="Live Viewers"
                  />
                </motion.div>
              ))}
            </motion.div>
          </TabsContent>
        </Tabs>
      </motion.main>
      
      <Footer />
    </div>
  );
};

export default TwitchPackages;
