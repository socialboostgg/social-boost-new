import { useState, useEffect } from "react";
import { Helmet } from "react-helmet";
import { Facebook } from "lucide-react";
import { PricingCard } from "@/components/PricingCard";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Navbar } from "@/components/layout/Navbar";
import { Footer } from "@/components/layout/Footer";
import { motion } from "framer-motion";

const FacebookPackages = () => {
  const [selectedTab, setSelectedTab] = useState("followers");
  const serviceName = "Facebook";

  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  const pageLikePackages = [
    {
      title: "100 Page Likes",
      price: "$1.49",
      features: ["High-Quality Likes", "Fast Delivery", "24/7 Support"],
      popular: false,
    },
    {
      title: "250 Page Likes",
      price: "$3.29",
      features: ["High-Quality Likes", "Fast Delivery", "24/7 Support"],
      popular: false,
    },
    {
      title: "500 Page Likes",
      price: "$5.99",
      features: ["High-Quality Likes", "Fast Delivery", "24/7 Support"],
      popular: false,
    },
    {
      title: "1K Page Likes",
      price: "$14.99",
      features: ["High-Quality Likes", "Fast Delivery", "24/7 Support"],
      popular: true,
    },
    {
      title: "2.5K Page Likes",
      price: "$32.99",
      features: ["High-Quality Likes", "Fast Delivery", "24/7 Support"],
      popular: false,
    },
    {
      title: "5K Page Likes",
      price: "$57.99",
      features: ["High-Quality Likes", "Fast Delivery", "24/7 Support"],
      popular: false,
    },
    {
      title: "10K Page Likes",
      price: "$99.99",
      features: ["High-Quality Likes", "Fast Delivery", "24/7 Support"],
      popular: false,
    },
    {
      title: "20K Page Likes",
      price: "$169.99",
      features: ["High-Quality Likes", "Fast Delivery", "24/7 Support"],
      popular: false,
    },
    {
      title: "50K Page Likes",
      price: "$359.99",
      features: ["High-Quality Likes", "Fast Delivery", "24/7 Support"],
      popular: false,
    },
    {
      title: "100K Page Likes",
      price: "$629.99",
      features: ["High-Quality Likes", "Fast Delivery", "24/7 Support"],
      popular: false,
    },
    {
      title: "200K Page Likes",
      price: "$1,099.99",
      features: ["High-Quality Likes", "Fast Delivery", "24/7 Support"],
      popular: false,
    },
    {
      title: "500K Page Likes",
      price: "$2,319.99",
      features: ["High-Quality Likes", "Fast Delivery", "24/7 Support"],
      popular: false,
    },
  ];

  const followersPackages = [
    {
      title: "100 Followers",
      price: "$0.99",
      features: ["Real Followers", "Fast Delivery", "24/7 Support"],
      popular: false,
    },
    {
      title: "250 Followers",
      price: "$2.00",
      features: ["Real Followers", "Fast Delivery", "24/7 Support"],
      popular: false,
    },
    {
      title: "500 Followers",
      price: "$3.50",
      features: ["Real Followers", "Fast Delivery", "24/7 Support"],
      popular: false,
    },
    {
      title: "1K Followers",
      price: "$8.99",
      features: ["Real Followers", "Fast Delivery", "24/7 Support"],
      popular: true,
    },
    {
      title: "2.5K Followers",
      price: "$18.99",
      features: ["Real Followers", "Fast Delivery", "24/7 Support"],
      popular: false,
    },
    {
      title: "5K Followers",
      price: "$34.99",
      features: ["Real Followers", "Fast Delivery", "24/7 Support"],
      popular: false,
    },
    {
      title: "10K Followers",
      price: "$59.99",
      features: ["Real Followers", "Fast Delivery", "24/7 Support"],
      popular: false,
    },
    {
      title: "20K Followers",
      price: "$99.99",
      features: ["Real Followers", "Fast Delivery", "24/7 Support"],
      popular: false,
    },
    {
      title: "50K Followers",
      price: "$209.99",
      features: ["Real Followers", "Fast Delivery", "24/7 Support"],
      popular: false,
    },
    {
      title: "100K Followers",
      price: "$374.99",
      features: ["Real Followers", "Fast Delivery", "24/7 Support"],
      popular: false,
    },
    {
      title: "200K Followers",
      price: "$649.99",
      features: ["Real Followers", "Fast Delivery", "24/7 Support"],
      popular: false,
    },
    {
      title: "500K Followers",
      price: "$1,349.99",
      features: ["Real Followers", "Fast Delivery", "24/7 Support"],
      popular: false,
    },
  ];

  const profileFollowersPackages = [
    {
      title: "100 Profile Followers",
      price: "$0.79",
      features: ["Real Profile Followers", "Fast Delivery", "24/7 Support"],
      popular: false,
    },
    {
      title: "250 Profile Followers",
      price: "$1.89",
      features: ["Real Profile Followers", "Fast Delivery", "24/7 Support"],
      popular: false,
    },
    {
      title: "500 Profile Followers",
      price: "$3.79",
      features: ["Real Profile Followers", "Fast Delivery", "24/7 Support"],
      popular: false,
    },
    {
      title: "1K Profile Followers",
      price: "$7.99",
      features: ["Real Profile Followers", "Fast Delivery", "24/7 Support"],
      popular: true,
    },
    {
      title: "2.5K Profile Followers",
      price: "$17.99",
      features: ["Real Profile Followers", "Fast Delivery", "24/7 Support"],
      popular: false,
    },
    {
      title: "5K Profile Followers",
      price: "$30.99",
      features: ["Real Profile Followers", "Fast Delivery", "24/7 Support"],
      popular: false,
    },
    {
      title: "10K Profile Followers",
      price: "$52.99",
      features: ["Real Profile Followers", "Fast Delivery", "24/7 Support"],
      popular: false,
    },
    {
      title: "20K Profile Followers",
      price: "$89.99",
      features: ["Real Profile Followers", "Fast Delivery", "24/7 Support"],
      popular: false,
    },
    {
      title: "50K Profile Followers",
      price: "$184.99",
      features: ["Real Profile Followers", "Fast Delivery", "24/7 Support"],
      popular: false,
    },
    {
      title: "100K Profile Followers",
      price: "$324.99",
      features: ["Real Profile Followers", "Fast Delivery", "24/7 Support"],
      popular: false,
    },
    {
      title: "200K Profile Followers",
      price: "$564.99",
      features: ["Real Profile Followers", "Fast Delivery", "24/7 Support"],
      popular: false,
    },
    {
      title: "500K Profile Followers",
      price: "$1,249.99",
      features: ["Real Profile Followers", "Fast Delivery", "24/7 Support"],
      popular: false,
    },
  ];

  const viewsPackages = [
    {
      title: "100 Views",
      price: "$0.19",
      features: ["High-Quality Views", "Fast Delivery", "24/7 Support"],
      popular: false,
    },
    {
      title: "250 Views",
      price: "$0.49",
      features: ["High-Quality Views", "Fast Delivery", "24/7 Support"],
      popular: false,
    },
    {
      title: "500 Views",
      price: "$0.99",
      features: ["High-Quality Views", "Fast Delivery", "24/7 Support"],
      popular: false,
    },
    {
      title: "1K Views",
      price: "$1.99",
      features: ["High-Quality Views", "Fast Delivery", "24/7 Support"],
      popular: false,
    },
    {
      title: "2.5K Views",
      price: "$4.49",
      features: ["High-Quality Views", "Fast Delivery", "24/7 Support"],
      popular: false,
    },
    {
      title: "5K Views",
      price: "$7.99",
      features: ["High-Quality Views", "Fast Delivery", "24/7 Support"],
      popular: false,
    },
    {
      title: "10K Views",
      price: "$13.99",
      features: ["High-Quality Views", "Fast Delivery", "24/7 Support"],
      popular: true,
    },
    {
      title: "20K Views",
      price: "$23.99",
      features: ["High-Quality Views", "Fast Delivery", "24/7 Support"],
      popular: false,
    },
    {
      title: "50K Views",
      price: "$49.99",
      features: ["High-Quality Views", "Fast Delivery", "24/7 Support"],
      popular: false,
    },
    {
      title: "100K Views",
      price: "$87.99",
      features: ["High-Quality Views", "Fast Delivery", "24/7 Support"],
      popular: false,
    },
    {
      title: "200K Views",
      price: "$152.99",
      features: ["High-Quality Views", "Fast Delivery", "24/7 Support"],
      popular: false,
    },
    {
      title: "500K Views",
      price: "$337.99",
      features: ["High-Quality Views", "Fast Delivery", "24/7 Support"],
      popular: false,
    },
  ];

  const sharesPackages = [
    {
      title: "100 Shares",
      price: "$0.99",
      features: ["Real Shares", "Fast Delivery", "24/7 Support"],
      popular: false,
    },
    {
      title: "250 Shares",
      price: "$2.49",
      features: ["Real Shares", "Fast Delivery", "24/7 Support"],
      popular: false,
    },
    {
      title: "500 Shares",
      price: "$4.99",
      features: ["Real Shares", "Fast Delivery", "24/7 Support"],
      popular: false,
    },
    {
      title: "1K Shares",
      price: "$9.99",
      features: ["Real Shares", "Fast Delivery", "24/7 Support"],
      popular: true,
    },
    {
      title: "2.5K Shares",
      price: "$22.49",
      features: ["Real Shares", "Fast Delivery", "24/7 Support"],
      popular: false,
    },
    {
      title: "5K Shares",
      price: "$39.99",
      features: ["Real Shares", "Fast Delivery", "24/7 Support"],
      popular: false,
    },
    {
      title: "10K Shares",
      price: "$69.99",
      features: ["Real Shares", "Fast Delivery", "24/7 Support"],
      popular: false,
    },
    {
      title: "20K Shares",
      price: "$119.99",
      features: ["Real Shares", "Fast Delivery", "24/7 Support"],
      popular: false,
    },
    {
      title: "50K Shares",
      price: "$249.99",
      features: ["Real Shares", "Fast Delivery", "24/7 Support"],
      popular: false,
    },
    {
      title: "100K Shares",
      price: "$439.99",
      features: ["Real Shares", "Fast Delivery", "24/7 Support"],
      popular: false,
    },
    {
      title: "200K Shares",
      price: "$759.99",
      features: ["Real Shares", "Fast Delivery", "24/7 Support"],
      popular: false,
    },
    {
      title: "500K Shares",
      price: "$1,649.99",
      features: ["Real Shares", "Fast Delivery", "24/7 Support"],
      popular: false,
    },
  ];

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: { 
      opacity: 1,
      transition: { 
        staggerChildren: 0.05,
        duration: 0.5
      }
    }
  };

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: { y: 0, opacity: 1 }
  };

  return (
    <div className="min-h-screen w-full">
      <Helmet>
        <title>Facebook Packages - Social Boost</title>
        <meta name="description" content="Boost your Facebook presence with our premium packages" />
      </Helmet>
      
      <Navbar />
      
      <motion.main 
        className="container mx-auto px-4 py-8"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <motion.div 
          className="mb-8 text-center"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.1 }}
        >
          <div className="flex items-center justify-center mb-4">
            <Facebook className="w-12 h-12 mr-2 text-primary" />
            <h1 className="text-4xl font-bold">Facebook Packages</h1>
          </div>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Choose from our range of Facebook growth services to enhance your social media presence
          </p>
        </motion.div>

        <Tabs defaultValue="followers" className="w-full">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            <TabsList className="grid w-full grid-cols-3 md:grid-cols-5 mb-8">
              <TabsTrigger value="page-likes">Page Likes</TabsTrigger>
              <TabsTrigger value="followers">Followers</TabsTrigger>
              <TabsTrigger value="profile-followers">Profile Followers</TabsTrigger>
              <TabsTrigger value="views">Views</TabsTrigger>
              <TabsTrigger value="shares">Shares</TabsTrigger>
            </TabsList>
          </motion.div>
        
          <TabsContent value="page-likes" className="mt-6">
            <motion.div 
              className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6"
              variants={containerVariants}
              initial="hidden"
              animate="visible"
            >
              {pageLikePackages.map((pkg, index) => (
                <motion.div key={index} variants={itemVariants}>
                  <PricingCard
                    title={pkg.title}
                    price={pkg.price}
                    features={pkg.features}
                    icon={<Facebook />}
                    popular={pkg.popular}
                    service={serviceName}
                    category="Page Likes"
                  />
                </motion.div>
              ))}
            </motion.div>
          </TabsContent>
          
          <TabsContent value="followers" className="mt-6">
            <motion.div 
              className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6"
              variants={containerVariants}
              initial="hidden"
              animate="visible"
            >
              {followersPackages.map((pkg, index) => (
                <motion.div key={index} variants={itemVariants}>
                  <PricingCard
                    title={pkg.title}
                    price={pkg.price}
                    features={pkg.features}
                    icon={<Facebook />}
                    popular={pkg.popular}
                    service={serviceName}
                    category="Followers"
                  />
                </motion.div>
              ))}
            </motion.div>
          </TabsContent>

          <TabsContent value="profile-followers" className="mt-6">
            <motion.div 
              className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6"
              variants={containerVariants}
              initial="hidden"
              animate="visible"
            >
              {profileFollowersPackages.map((pkg, index) => (
                <motion.div key={index} variants={itemVariants}>
                  <PricingCard
                    title={pkg.title}
                    price={pkg.price}
                    features={pkg.features}
                    icon={<Facebook />}
                    popular={pkg.popular}
                    service={serviceName}
                    category="Profile Followers"
                  />
                </motion.div>
              ))}
            </motion.div>
          </TabsContent>

          <TabsContent value="views" className="mt-6">
            <motion.div 
              className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6"
              variants={containerVariants}
              initial="hidden"
              animate="visible"
            >
              {viewsPackages.map((pkg, index) => (
                <motion.div key={index} variants={itemVariants}>
                  <PricingCard
                    title={pkg.title}
                    price={pkg.price}
                    features={pkg.features}
                    icon={<Facebook />}
                    popular={pkg.popular}
                    service={serviceName}
                    category="Views"
                  />
                </motion.div>
              ))}
            </motion.div>
          </TabsContent>

          <TabsContent value="shares" className="mt-6">
            <motion.div 
              className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6"
              variants={containerVariants}
              initial="hidden"
              animate="visible"
            >
              {sharesPackages.map((pkg, index) => (
                <motion.div key={index} variants={itemVariants}>
                  <PricingCard
                    title={pkg.title}
                    price={pkg.price}
                    features={pkg.features}
                    icon={<Facebook />}
                    popular={pkg.popular}
                    service={serviceName}
                    category="Shares"
                  />
                </motion.div>
              ))}
            </motion.div>
          </TabsContent>
        </Tabs>
      </motion.main>
      
      <Footer />
    </div>
  );
};

export default FacebookPackages;
