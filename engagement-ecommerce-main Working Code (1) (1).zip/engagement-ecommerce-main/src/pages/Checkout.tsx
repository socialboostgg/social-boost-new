import { useState } from "react";
import { Navbar } from "@/components/layout/Navbar";
import { Footer } from "@/components/layout/Footer";
import { useCart } from "@/context/CartContext";
import { Button } from "@/components/ui/button";
import { CreditCard, ArrowLeft, CheckCircle } from "lucide-react";
import { Link, useNavigate } from "react-router-dom";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { toast } from "sonner";
import { Elements } from "@stripe/react-stripe-js";
import { useStripe, useElements } from "@stripe/react-stripe-js";
import { stripePromise } from "@/utils/stripeConfig";
import { StripeCardElement } from "@/components/payments/StripeCardElement";
import { processStripePayment } from "@/utils/stripePaymentProcessor";
import { OrderSummary } from "@/components/checkout/OrderSummary";
import { BillingForm } from "@/components/checkout/BillingForm";
import { EmptyCart } from "@/components/checkout/EmptyCart";

const CheckoutForm = () => {
  const { items, total, placeOrders } = useCart();
  const navigate = useNavigate();
  const [isProcessing, setIsProcessing] = useState(false);
  const [socialLink, setSocialLink] = useState("");
  const [formErrors, setFormErrors] = useState<Record<string, string>>({});
  const [paymentError, setPaymentError] = useState<string | null>(null);
  
  const stripe = useStripe();
  const elements = useElements();

  const validateForm = (formData: FormData): boolean => {
    const errors: Record<string, string> = {};
    
    const link = formData.get("socialLink") as string;
    if (!link) {
      errors.socialLink = "Social media link is required";
    } else if (!link.startsWith("http://") && !link.startsWith("https://")) {
      errors.socialLink = "Please enter a valid URL starting with http:// or https://";
    }
    
    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleCheckout = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (items.length === 0) {
      toast.error("Your cart is empty", {
        description: "Add some items to your cart before checking out."
      });
      return;
    }
    
    const form = e.target as HTMLFormElement;
    const formData = new FormData(form);
    
    if (!validateForm(formData)) {
      toast.error("Please fix the errors in the form");
      return;
    }
    
    const link = formData.get("socialLink") as string;
    setSocialLink(link);
    
    setIsProcessing(true);
    setPaymentError(null);
    
    try {
      const { success, error } = await processStripePayment(items, total, stripe, elements);
      
      if (!success) {
        setPaymentError(error || "Payment failed. Please try again.");
        setIsProcessing(false);
        return;
      }
      
      const ordersSuccess = await placeOrders(link);
      
      if (ordersSuccess) {
        toast.success("Orders completed successfully!", {
          description: "Thank you for your purchase."
        });
        navigate("/", { replace: true });
      } else {
        toast.error("Some orders could not be completed", {
          description: "Please review your cart and try again."
        });
      }
    } catch (error) {
      console.error("Error processing checkout:", error);
      toast.error("There was an error processing your order", {
        description: "Please try again later."
      });
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <form onSubmit={handleCheckout} className="space-y-6">
      <BillingForm 
        socialLink={socialLink} 
        setSocialLink={setSocialLink}
        formErrors={formErrors}
      />
      
      <Separator />
      
      <StripeCardElement onChange={() => setPaymentError(null)} />
      
      {paymentError && (
        <div className="text-red-500 text-sm p-2 border border-red-200 bg-red-50 rounded">
          {paymentError}
        </div>
      )}
      
      <div className="flex items-center space-x-2">
        <Checkbox id="terms" name="terms" required />
        <Label htmlFor="terms" className="text-sm">
          I agree to the terms and conditions
        </Label>
      </div>
      
      <div className="flex gap-4">
        <Button type="submit" className="flex-1" disabled={isProcessing || !stripe}>
          {isProcessing ? (
            <>Processing...</>
          ) : (
            <>
              <CheckCircle className="mr-2 h-4 w-4" />
              Complete Order
            </>
          )}
        </Button>
        <Button variant="outline" asChild>
          <Link to="/cart">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Cart
          </Link>
        </Button>
      </div>
    </form>
  );
};

const Checkout = () => {
  const { items } = useCart();

  return (
    <div className="min-h-screen w-full flex flex-col">
      <Navbar />
      
      <main className="container mx-auto px-4 py-8 flex-grow">
        <div className="mb-8">
          <div className="flex items-center mb-4">
            <CreditCard className="w-8 h-8 mr-2 text-primary" />
            <h1 className="text-3xl font-bold">Checkout</h1>
          </div>
          
          {items.length === 0 ? (
            <EmptyCart />
          ) : (
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              <div className="lg:col-span-2">
                <Card>
                  <CardHeader>
                    <CardTitle>Order Information</CardTitle>
                    <CardDescription>Enter your details to complete your purchase</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Elements stripe={stripePromise}>
                      <CheckoutForm />
                    </Elements>
                  </CardContent>
                </Card>
              </div>
              
              <div>
                <OrderSummary />
              </div>
            </div>
          )}
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

export default Checkout;
