import { useEffect } from "react";
import { Helmet } from "react-helmet";
import { Bookmark } from "lucide-react";
import { PricingCard } from "@/components/PricingCard";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Navbar } from "@/components/layout/Navbar";
import { Footer } from "@/components/layout/Footer";
import { motion } from "framer-motion";

const PinterestPackages = () => {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  const followerPackages = [
    {
      title: "100 Followers",
      price: "$1.89",
      features: ["High-Quality Followers", "Fast Delivery", "24/7 Support"],
      popular: false,
    },
    {
      title: "250 Followers",
      price: "$4.74",
      features: ["High-Quality Followers", "Fast Delivery", "24/7 Support"],
      popular: false,
    },
    {
      title: "500 Followers",
      price: "$9.49",
      features: ["High-Quality Followers", "Fast Delivery", "24/7 Support"],
      popular: false,
    },
    {
      title: "1K Followers",
      price: "$18.99",
      features: ["High-Quality Followers", "Fast Delivery", "24/7 Support"],
      popular: true,
    },
    {
      title: "2.5K Followers",
      price: "$43.99",
      features: ["High-Quality Followers", "Fast Delivery", "24/7 Support"],
      popular: false,
    },
    {
      title: "5K Followers",
      price: "$75.99",
      features: ["High-Quality Followers", "Fast Delivery", "24/7 Support"],
      popular: false,
    },
    {
      title: "10K Followers",
      price: "$132.99",
      features: ["High-Quality Followers", "Fast Delivery", "24/7 Support"],
      popular: false,
    },
    {
      title: "20K Followers",
      price: "$225.99",
      features: ["High-Quality Followers", "Fast Delivery", "24/7 Support"],
      popular: false,
    },
    {
      title: "50K Followers",
      price: "$474.99",
      features: ["High-Quality Followers", "Fast Delivery", "24/7 Support"],
      popular: false,
    },
    {
      title: "100K Followers",
      price: "$812.99",
      features: ["High-Quality Followers", "Fast Delivery", "24/7 Support"],
      popular: false,
    },
    {
      title: "200K Followers",
      price: "$1,398.99",
      features: ["High-Quality Followers", "Fast Delivery", "24/7 Support"],
      popular: false,
    },
    {
      title: "500K Followers",
      price: "$2,974.99",
      features: ["High-Quality Followers", "Fast Delivery", "24/7 Support"],
      popular: false,
    },
  ];

  const boardFollowerPackages = [
    {
      title: "100 Board Followers",
      price: "$0.75",
      features: ["High-Quality Followers", "Fast Delivery", "24/7 Support"],
      popular: false,
    },
    {
      title: "250 Board Followers",
      price: "$1.87",
      features: ["High-Quality Followers", "Fast Delivery", "24/7 Support"],
      popular: false,
    },
    {
      title: "500 Board Followers",
      price: "$3.74",
      features: ["High-Quality Followers", "Fast Delivery", "24/7 Support"],
      popular: false,
    },
    {
      title: "1K Board Followers",
      price: "$7.49",
      features: ["High-Quality Followers", "Fast Delivery", "24/7 Support"],
      popular: true,
    },
    {
      title: "2.5K Board Followers",
      price: "$17.29",
      features: ["High-Quality Followers", "Fast Delivery", "24/7 Support"],
      popular: false,
    },
    {
      title: "5K Board Followers",
      price: "$29.99",
      features: ["High-Quality Followers", "Fast Delivery", "24/7 Support"],
      popular: false,
    },
    {
      title: "10K Board Followers",
      price: "$52.49",
      features: ["High-Quality Followers", "Fast Delivery", "24/7 Support"],
      popular: false,
    },
    {
      title: "20K Board Followers",
      price: "$88.99",
      features: ["High-Quality Followers", "Fast Delivery", "24/7 Support"],
      popular: false,
    },
    {
      title: "50K Board Followers",
      price: "$186.99",
      features: ["High-Quality Followers", "Fast Delivery", "24/7 Support"],
      popular: false,
    },
    {
      title: "100K Board Followers",
      price: "$319.99",
      features: ["High-Quality Followers", "Fast Delivery", "24/7 Support"],
      popular: false,
    },
    {
      title: "200K Board Followers",
      price: "$549.99",
      features: ["High-Quality Followers", "Fast Delivery", "24/7 Support"],
      popular: false,
    },
    {
      title: "500K Board Followers",
      price: "$1,169.99",
      features: ["High-Quality Followers", "Fast Delivery", "24/7 Support"],
      popular: false,
    },
  ];

  const likePackages = [
    {
      title: "100 Likes",
      price: "$0.39",
      features: ["High-Quality Likes", "Fast Delivery", "24/7 Support"],
      popular: false,
    },
    {
      title: "250 Likes",
      price: "$0.99",
      features: ["High-Quality Likes", "Fast Delivery", "24/7 Support"],
      popular: false,
    },
    {
      title: "500 Likes",
      price: "$1.99",
      features: ["High-Quality Likes", "Fast Delivery", "24/7 Support"],
      popular: false,
    },
    {
      title: "1K Likes",
      price: "$3.99",
      features: ["High-Quality Likes", "Fast Delivery", "24/7 Support"],
      popular: true,
    },
    {
      title: "2.5K Likes",
      price: "$9.19",
      features: ["High-Quality Likes", "Fast Delivery", "24/7 Support"],
      popular: false,
    },
    {
      title: "5K Likes",
      price: "$15.99",
      features: ["High-Quality Likes", "Fast Delivery", "24/7 Support"],
      popular: false,
    },
    {
      title: "10K Likes",
      price: "$27.99",
      features: ["High-Quality Likes", "Fast Delivery", "24/7 Support"],
      popular: false,
    },
    {
      title: "20K Likes",
      price: "$47.99",
      features: ["High-Quality Likes", "Fast Delivery", "24/7 Support"],
      popular: false,
    },
    {
      title: "50K Likes",
      price: "$99.99",
      features: ["High-Quality Likes", "Fast Delivery", "24/7 Support"],
      popular: false,
    },
    {
      title: "100K Likes",
      price: "$171.99",
      features: ["High-Quality Likes", "Fast Delivery", "24/7 Support"],
      popular: false,
    },
    {
      title: "200K Likes",
      price: "$299.99",
      features: ["High-Quality Likes", "Fast Delivery", "24/7 Support"],
      popular: false,
    },
    {
      title: "500K Likes",
      price: "$649.99",
      features: ["High-Quality Likes", "Fast Delivery", "24/7 Support"],
      popular: false,
    },
  ];

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: { 
      opacity: 1,
      transition: { 
        staggerChildren: 0.05,
        duration: 0.5
      }
    }
  };

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: { y: 0, opacity: 1 }
  };

  return (
    <div className="min-h-screen w-full">
      <Helmet>
        <title>Pinterest Packages - Social Boost</title>
        <meta name="description" content="Boost your Pinterest presence with our premium packages" />
      </Helmet>
      
      <Navbar />
      
      <motion.main 
        className="container mx-auto px-4 py-8"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <motion.div 
          className="mb-8 text-center"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.1 }}
        >
          <div className="flex items-center justify-center mb-4">
            <Bookmark className="w-12 h-12 mr-2 text-primary" />
            <h1 className="text-4xl font-bold">Pinterest Packages</h1>
          </div>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Choose from our range of Pinterest growth services to enhance your social media presence
          </p>
        </motion.div>

        <Tabs defaultValue="followers" className="w-full">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            <TabsList className="grid w-full grid-cols-3 mb-8">
              <TabsTrigger value="followers">Followers</TabsTrigger>
              <TabsTrigger value="boardFollowers">Board Followers</TabsTrigger>
              <TabsTrigger value="likes">Likes</TabsTrigger>
            </TabsList>
          </motion.div>
        
          <TabsContent value="followers" className="mt-6">
            <motion.div 
              className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6"
              variants={containerVariants}
              initial="hidden"
              animate="visible"
            >
              {followerPackages.map((pkg, index) => (
                <motion.div key={index} variants={itemVariants}>
                  <PricingCard
                    title={pkg.title}
                    price={pkg.price}
                    features={pkg.features}
                    icon={<Bookmark />}
                    popular={pkg.popular}
                    service="Pinterest"
                    category="Followers"
                  />
                </motion.div>
              ))}
            </motion.div>
          </TabsContent>
          
          <TabsContent value="boardFollowers" className="mt-6">
            <motion.div 
              className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6"
              variants={containerVariants}
              initial="hidden"
              animate="visible"
            >
              {boardFollowerPackages.map((pkg, index) => (
                <motion.div key={index} variants={itemVariants}>
                  <PricingCard
                    title={pkg.title}
                    price={pkg.price}
                    features={pkg.features}
                    icon={<Bookmark />}
                    popular={pkg.popular}
                    service="Pinterest"
                    category="Board Followers"
                  />
                </motion.div>
              ))}
            </motion.div>
          </TabsContent>
          
          <TabsContent value="likes" className="mt-6">
            <motion.div 
              className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6"
              variants={containerVariants}
              initial="hidden"
              animate="visible"
            >
              {likePackages.map((pkg, index) => (
                <motion.div key={index} variants={itemVariants}>
                  <PricingCard
                    title={pkg.title}
                    price={pkg.price}
                    features={pkg.features}
                    icon={<Bookmark />}
                    popular={pkg.popular}
                    service="Pinterest"
                    category="Likes"
                  />
                </motion.div>
              ))}
            </motion.div>
          </TabsContent>
        </Tabs>
      </motion.main>
      
      <Footer />
    </div>
  );
};

export default PinterestPackages;
