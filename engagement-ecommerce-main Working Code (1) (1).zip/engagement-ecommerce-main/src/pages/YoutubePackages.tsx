import { useEffect } from "react";
import { Helmet } from "react-helmet";
import { Youtube } from "lucide-react";
import { PricingCard } from "@/components/PricingCard";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Navbar } from "@/components/layout/Navbar";
import { Footer } from "@/components/layout/Footer";
import { motion } from "framer-motion";

const YoutubePackages = () => {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  const subscriberPackages = [
    {
      title: "100 Subscribers",
      price: "$1.99",
      features: ["Delivery within 0-24 hours", "30-day refill guarantee", "24/7 support"],
      popular: false,
    },
    {
      title: "250 Subscribers",
      price: "$4.49",
      features: ["Delivery within 0-24 hours", "30-day refill guarantee", "24/7 support"],
      popular: false,
    },
    {
      title: "500 Subscribers",
      price: "$9.49",
      features: ["Delivery within 0-24 hours", "30-day refill guarantee", "24/7 support"],
      popular: false,
    },
    {
      title: "1K Subscribers",
      price: "$19.99",
      features: ["Delivery within 0-24 hours", "30-day refill guarantee", "24/7 support"],
      popular: true,
    },
    {
      title: "2.5K Subscribers",
      price: "$29.99",
      features: ["Delivery within 0-24 hours", "30-day refill guarantee", "24/7 support"],
      popular: false,
    },
    {
      title: "5K Subscribers",
      price: "$49.99",
      features: ["Delivery within 0-24 hours", "30-day refill guarantee", "24/7 support"],
      popular: false,
    },
    {
      title: "10K Subscribers",
      price: "$79.99",
      features: ["Delivery within 0-24 hours", "30-day refill guarantee", "24/7 support"],
      popular: false,
    },
    {
      title: "20K Subscribers",
      price: "$139.99",
      features: ["Delivery within 0-24 hours", "30-day refill guarantee", "24/7 support"],
      popular: false,
    },
    {
      title: "50K Subscribers",
      price: "$249.99",
      features: ["Delivery within 0-24 hours", "30-day refill guarantee", "24/7 support"],
      popular: false,
    },
    {
      title: "100K Subscribers",
      price: "$449.99",
      features: ["Delivery within 0-24 hours", "30-day refill guarantee", "24/7 support"],
      popular: false,
    },
    {
      title: "200K Subscribers",
      price: "$849.99",
      features: ["Delivery within 0-24 hours", "30-day refill guarantee", "24/7 support"],
      popular: false,
    },
    {
      title: "300K Subscribers",
      price: "$1,249.99",
      features: ["Delivery within 0-24 hours", "30-day refill guarantee", "24/7 support"],
      popular: false,
    },
  ];

  const likePackages = [
    {
      title: "100 Likes",
      price: "$0.89",
      features: ["Delivery within 0-24 hours", "High-quality likes", "24/7 support"],
      popular: false,
    },
    {
      title: "250 Likes",
      price: "$2.19",
      features: ["Delivery within 0-24 hours", "High-quality likes", "24/7 support"],
      popular: false,
    },
    {
      title: "500 Likes",
      price: "$4.39",
      features: ["Delivery within 0-24 hours", "High-quality likes", "24/7 support"],
      popular: false,
    },
    {
      title: "1K Likes",
      price: "$8.99",
      features: ["Delivery within 0-24 hours", "High-quality likes", "24/7 support"],
      popular: true,
    },
    {
      title: "2.5K Likes",
      price: "$13.99",
      features: ["Delivery within 0-24 hours", "High-quality likes", "24/7 support"],
      popular: false,
    },
    {
      title: "5K Likes",
      price: "$22.99",
      features: ["Delivery within 0-24 hours", "High-quality likes", "24/7 support"],
      popular: false,
    },
    {
      title: "10K Likes",
      price: "$37.99",
      features: ["Delivery within 0-24 hours", "High-quality likes", "24/7 support"],
      popular: false,
    },
    {
      title: "20K Likes",
      price: "$64.99",
      features: ["Delivery within 0-24 hours", "High-quality likes", "24/7 support"],
      popular: false,
    },
    {
      title: "50K Likes",
      price: "$119.99",
      features: ["Delivery within 0-24 hours", "High-quality likes", "24/7 support"],
      popular: false,
    },
    {
      title: "100K Likes",
      price: "$219.99",
      features: ["Delivery within 0-24 hours", "High-quality likes", "24/7 support"],
      popular: false,
    },
    {
      title: "200K Likes",
      price: "$439.99",
      features: ["Delivery within 0-24 hours", "High-quality likes", "24/7 support"],
      popular: false,
    },
    {
      title: "300K Likes",
      price: "$659.99",
      features: ["Delivery within 0-24 hours", "High-quality likes", "24/7 support"],
      popular: false,
    },
  ];

  const viewPackages = [
    {
      title: "1K Views",
      price: "$3.49",
      features: ["Delivery within 0-24 hours", "Real views", "24/7 support"],
      popular: false,
    },
    {
      title: "2.5K Views",
      price: "$7.49",
      features: ["Delivery within 0-24 hours", "Real views", "24/7 support"],
      popular: false,
    },
    {
      title: "5K Views",
      price: "$14.99",
      features: ["Delivery within 0-24 hours", "Real views", "24/7 support"],
      popular: false,
    },
    {
      title: "10K Views",
      price: "$29.99",
      features: ["Delivery within 0-24 hours", "Real views", "24/7 support"],
      popular: true,
    },
    {
      title: "20K Views",
      price: "$49.99",
      features: ["Delivery within 0-24 hours", "Real views", "24/7 support"],
      popular: false,
    },
    {
      title: "50K Views",
      price: "$89.99",
      features: ["Delivery within 0-24 hours", "Real views", "24/7 support"],
      popular: false,
    },
    {
      title: "100K Views",
      price: "$149.99",
      features: ["Delivery within 0-24 hours", "Real views", "24/7 support"],
      popular: false,
    },
    {
      title: "250K Views",
      price: "$299.99",
      features: ["Delivery within 0-24 hours", "Real views", "24/7 support"],
      popular: false,
    },
    {
      title: "500K Views",
      price: "$499.99",
      features: ["Delivery within 0-24 hours", "Real views", "24/7 support"],
      popular: false,
    },
    {
      title: "1M Views",
      price: "$899.99",
      features: ["Delivery within 0-24 hours", "Real views", "24/7 support"],
      popular: false,
    },
    {
      title: "2.5M Views",
      price: "$1499.99",
      features: ["Delivery within 0-24 hours", "Real views", "24/7 support"],
      popular: false,
    },
  ];

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: { 
      opacity: 1,
      transition: { 
        staggerChildren: 0.05,
        duration: 0.5
      }
    }
  };

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: { y: 0, opacity: 1 }
  };

  return (
    <div className="min-h-screen w-full">
      <Helmet>
        <title>YouTube Packages - Social Boost</title>
        <meta name="description" content="Boost your YouTube presence with our premium packages" />
      </Helmet>

      <Navbar />
      
      <motion.main 
        className="container mx-auto px-4 py-8"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <motion.div 
          className="mb-8 text-center"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.1 }}
        >
          <div className="flex items-center justify-center mb-4">
            <Youtube className="w-12 h-12 mr-2 text-primary" />
            <h1 className="text-4xl font-bold">YouTube Packages</h1>
          </div>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Choose from our variety of YouTube growth services. All packages come with a satisfaction guarantee and 24/7 support.
          </p>
        </motion.div>

        <Tabs defaultValue="subscribers" className="w-full">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            <TabsList className="grid w-full grid-cols-3 mb-8">
              <TabsTrigger value="subscribers">Subscribers</TabsTrigger>
              <TabsTrigger value="likes">Likes</TabsTrigger>
              <TabsTrigger value="views">Views</TabsTrigger>
            </TabsList>
          </motion.div>
          
          <TabsContent value="subscribers" className="mt-6">
            <motion.div 
              className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6"
              variants={containerVariants}
              initial="hidden"
              animate="visible"
            >
              {subscriberPackages.map((pkg, index) => (
                <motion.div key={index} variants={itemVariants}>
                  <PricingCard
                    key={index}
                    title={pkg.title}
                    price={pkg.price}
                    features={pkg.features}
                    icon={<Youtube />}
                    popular={pkg.popular}
                    service="YouTube"
                    category="Subscribers"
                  />
                </motion.div>
              ))}
            </motion.div>
          </TabsContent>
          
          <TabsContent value="likes" className="mt-6">
            <motion.div 
              className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6"
              variants={containerVariants}
              initial="hidden"
              animate="visible"
            >
              {likePackages.map((pkg, index) => (
                <motion.div key={index} variants={itemVariants}>
                  <PricingCard
                    key={index}
                    title={pkg.title}
                    price={pkg.price}
                    features={pkg.features}
                    icon={<Youtube />}
                    popular={pkg.popular}
                    service="YouTube"
                    category="Likes"
                  />
                </motion.div>
              ))}
            </motion.div>
          </TabsContent>
          
          <TabsContent value="views" className="mt-6">
            <motion.div 
              className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6"
              variants={containerVariants}
              initial="hidden"
              animate="visible"
            >
              {viewPackages.map((pkg, index) => (
                <motion.div key={index} variants={itemVariants}>
                  <PricingCard
                    key={index}
                    title={pkg.title}
                    price={pkg.price}
                    features={pkg.features}
                    icon={<Youtube />}
                    popular={pkg.popular}
                    service="YouTube"
                    category="Views"
                  />
                </motion.div>
              ))}
            </motion.div>
          </TabsContent>
        </Tabs>
      </motion.main>
      
      <Footer />
    </div>
  );
};

export default YoutubePackages;
