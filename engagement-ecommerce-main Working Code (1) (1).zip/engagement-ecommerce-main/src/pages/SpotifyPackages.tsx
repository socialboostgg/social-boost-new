import { useState, useEffect } from "react";
import { Helmet } from "react-helmet";
import { Music } from "lucide-react";
import { PricingCard } from "@/components/PricingCard";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Navbar } from "@/components/layout/Navbar";
import { Footer } from "@/components/layout/Footer";
import { motion } from "framer-motion";

const SpotifyPackages = () => {
  const [selectedTab, setSelectedTab] = useState("followers");
  const serviceName = "Spotify";

  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  const followersPackages = [
    { title: "100 Followers", price: "$0.34", features: ["High Quality", "Fast Delivery", "24/7 Support"] },
    { title: "250 Followers", price: "$0.89", features: ["High Quality", "Fast Delivery", "24/7 Support"] },
    { title: "500 Followers", price: "$1.79", features: ["High Quality", "Fast Delivery", "24/7 Support"] },
    { title: "1K Followers", price: "$3.49", features: ["High Quality", "Fast Delivery", "24/7 Support", "30-Day Refill"] },
    { title: "2.5K Followers", price: "$7.99", features: ["High Quality", "Fast Delivery", "24/7 Support", "30-Day Refill"] },
    { title: "5K Followers", price: "$13.99", features: ["Premium Quality", "Fast Delivery", "24/7 Support", "30-Day Refill"] },
    { title: "10K Followers", price: "$24.99", features: ["Premium Quality", "Fast Delivery", "24/7 Support", "30-Day Refill"] },
    { title: "20K Followers", price: "$42.99", features: ["Premium Quality", "Fast Delivery", "24/7 Support", "30-Day Refill"] },
    { title: "50K Followers", price: "$89.99", features: ["Premium Quality", "Gradual Delivery", "24/7 Support", "30-Day Refill"] },
    { title: "100K Followers", price: "$152.99", features: ["Premium Quality", "Gradual Delivery", "24/7 Support", "30-Day Refill"] },
    { title: "200K Followers", price: "$263.99", features: ["Premium Quality", "Gradual Delivery", "24/7 Support", "60-Day Refill"] },
    { title: "500K Followers", price: "$569.99", features: ["Premium Quality", "Gradual Delivery", "24/7 Support", "60-Day Refill"] },
  ];

  const playsPackages = [
    { title: "100 Plays", price: "$0.19", features: ["High Quality", "Fast Delivery", "24/7 Support"] },
    { title: "250 Plays", price: "$0.49", features: ["High Quality", "Fast Delivery", "24/7 Support"] },
    { title: "500 Plays", price: "$0.99", features: ["High Quality", "Fast Delivery", "24/7 Support"] },
    { title: "1K Plays", price: "$1.89", features: ["High Quality", "Fast Delivery", "24/7 Support", "30-Day Refill"] },
    { title: "2.5K Plays", price: "$4.39", features: ["High Quality", "Fast Delivery", "24/7 Support", "30-Day Refill"] },
    { title: "5K Plays", price: "$7.69", features: ["Premium Quality", "Fast Delivery", "24/7 Support", "30-Day Refill"] },
    { title: "10K Plays", price: "$13.69", features: ["Premium Quality", "Fast Delivery", "24/7 Support", "30-Day Refill"] },
    { title: "20K Plays", price: "$23.69", features: ["Premium Quality", "Fast Delivery", "24/7 Support", "30-Day Refill"] },
    { title: "50K Plays", price: "$49.69", features: ["Premium Quality", "Gradual Delivery", "24/7 Support", "30-Day Refill"] },
    { title: "100K Plays", price: "$85.69", features: ["Premium Quality", "Gradual Delivery", "24/7 Support", "30-Day Refill"] },
    { title: "200K Plays", price: "$146.69", features: ["Premium Quality", "Gradual Delivery", "24/7 Support", "60-Day Refill"] },
    { title: "500K Plays", price: "$314.69", features: ["Premium Quality", "Gradual Delivery", "24/7 Support", "60-Day Refill"] },
  ];

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: { 
      opacity: 1,
      transition: { 
        staggerChildren: 0.05,
        duration: 0.5
      }
    }
  };

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: { y: 0, opacity: 1 }
  };

  return (
    <div className="min-h-screen w-full">
      <Helmet>
        <title>Spotify Packages - Social Boost</title>
        <meta name="description" content="Boost your Spotify presence with our premium packages" />
      </Helmet>

      <Navbar />
      
      <motion.main 
        className="container mx-auto px-4 py-8"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <motion.div 
          className="mb-8 text-center"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.1 }}
        >
          <div className="flex items-center justify-center mb-4">
            <Music className="w-12 h-12 mr-2 text-primary" />
            <h1 className="text-4xl font-bold">Spotify Packages</h1>
          </div>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Choose from our range of high-quality Spotify services to enhance your music presence
          </p>
        </motion.div>

        <Tabs
          defaultValue="followers"
          value={selectedTab}
          onValueChange={setSelectedTab}
          className="w-full"
        >
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            <TabsList className="grid w-full grid-cols-2 mb-8">
              <TabsTrigger value="followers">Followers</TabsTrigger>
              <TabsTrigger value="plays">Plays</TabsTrigger>
            </TabsList>
          </motion.div>

          <TabsContent value="followers" className="mt-6">
            <motion.div 
              className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6"
              variants={containerVariants}
              initial="hidden"
              animate="visible"
            >
              {followersPackages.map((pkg, index) => (
                <motion.div key={index} variants={itemVariants}>
                  <PricingCard
                    title={pkg.title}
                    price={pkg.price}
                    features={pkg.features}
                    icon={<Music />}
                    popular={index === 3}
                    service={serviceName}
                    category="Followers"
                  />
                </motion.div>
              ))}
            </motion.div>
          </TabsContent>
          
          <TabsContent value="plays" className="mt-6">
            <motion.div 
              className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6"
              variants={containerVariants}
              initial="hidden"
              animate="visible"
            >
              {playsPackages.map((pkg, index) => (
                <motion.div key={index} variants={itemVariants}>
                  <PricingCard
                    title={pkg.title}
                    price={pkg.price}
                    features={pkg.features}
                    icon={<Music />}
                    popular={index === 3}
                    service={serviceName}
                    category="Plays"
                  />
                </motion.div>
              ))}
            </motion.div>
          </TabsContent>
        </Tabs>
      </motion.main>
      
      <Footer />
    </div>
  );
};

export default SpotifyPackages;
