import { useEffect } from "react";
import { Helmet } from "react-helmet";
import { Instagram } from "lucide-react";
import { PricingCard } from "@/components/PricingCard";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Navbar } from "@/components/layout/Navbar";
import { Footer } from "@/components/layout/Footer";
import { motion } from "framer-motion";
import { INSTAGRAM_LIKES_PRICES } from "@/utils/serviceController";

const InstagramPackages = () => {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  const followerPackages = [
    {
      title: "100 Followers",
      price: "$1.99",
      features: ["Delivery within 0-24 hours", "30-day refill guarantee", "24/7 support"],
      popular: false,
    },
    {
      title: "250 Followers",
      price: "$3.49",
      features: ["Delivery within 0-24 hours", "30-day refill guarantee", "24/7 support"],
      popular: false,
    },
    {
      title: "500 Followers",
      price: "$4.99",
      features: ["Delivery within 0-24 hours", "30-day refill guarantee", "24/7 support"],
      popular: false,
    },
    {
      title: "1K Followers",
      price: "$7.99",
      features: ["Delivery within 0-24 hours", "30-day refill guarantee", "24/7 support"],
      popular: true,
    },
    {
      title: "2.5K Followers",
      price: "$19.99",
      features: ["Delivery within 0-24 hours", "30-day refill guarantee", "24/7 support"],
      popular: false,
    },
    {
      title: "5K Followers",
      price: "$24.99",
      features: ["Delivery within 0-24 hours", "30-day refill guarantee", "24/7 support"],
      popular: false,
    },
    {
      title: "10K Followers",
      price: "$39.99",
      features: ["Delivery within 0-24 hours", "30-day refill guarantee", "24/7 support"],
      popular: false,
    },
    {
      title: "20K Followers",
      price: "$69.99",
      features: ["Delivery within 0-24 hours", "30-day refill guarantee", "24/7 support"],
      popular: false,
    },
    {
      title: "50K Followers",
      price: "$149.99",
      features: ["Delivery within 0-24 hours", "30-day refill guarantee", "24/7 support"],
      popular: false,
    },
    {
      title: "100K Followers",
      price: "$249.99",
      features: ["Delivery within 0-24 hours", "30-day refill guarantee", "24/7 support"],
      popular: false,
    },
    {
      title: "200K Followers",
      price: "$449.99",
      features: ["Delivery within 0-24 hours", "30-day refill guarantee", "24/7 support"],
      popular: false,
    },
    {
      title: "500K Followers",
      price: "$799.99",
      features: ["Delivery within 0-24 hours", "30-day refill guarantee", "24/7 support"],
      popular: false,
    },
  ];

  const likePackages = [
    {
      title: "100 Likes",
      price: INSTAGRAM_LIKES_PRICES["100"],
      features: ["Delivery within 0-24 hours", "High-quality likes", "24/7 support"],
      popular: false,
    },
    {
      title: "250 Likes",
      price: INSTAGRAM_LIKES_PRICES["250"],
      features: ["Delivery within 0-24 hours", "High-quality likes", "24/7 support"],
      popular: false,
    },
    {
      title: "500 Likes",
      price: INSTAGRAM_LIKES_PRICES["500"],
      features: ["Delivery within 0-24 hours", "High-quality likes", "24/7 support"],
      popular: false,
    },
    {
      title: "1K Likes",
      price: INSTAGRAM_LIKES_PRICES["1,000"],
      features: ["Delivery within 0-24 hours", "High-quality likes", "24/7 support"],
      popular: true,
    },
    {
      title: "2.5K Likes",
      price: INSTAGRAM_LIKES_PRICES["2,500"],
      features: ["Delivery within 0-24 hours", "High-quality likes", "24/7 support"],
      popular: false,
    },
    {
      title: "5K Likes",
      price: INSTAGRAM_LIKES_PRICES["5,000"],
      features: ["Delivery within 0-24 hours", "High-quality likes", "24/7 support"],
      popular: false,
    },
    {
      title: "10K Likes",
      price: INSTAGRAM_LIKES_PRICES["10,000"],
      features: ["Delivery within 0-24 hours", "High-quality likes", "24/7 support"],
      popular: false,
    },
    {
      title: "20K Likes",
      price: INSTAGRAM_LIKES_PRICES["20,000"],
      features: ["Delivery within 0-24 hours", "High-quality likes", "24/7 support"],
      popular: false,
    },
    {
      title: "50K Likes",
      price: INSTAGRAM_LIKES_PRICES["50,000"],
      features: ["Delivery within 0-24 hours", "High-quality likes", "24/7 support"],
      popular: false,
    },
    {
      title: "100K Likes",
      price: INSTAGRAM_LIKES_PRICES["100,000"],
      features: ["Delivery within 0-24 hours", "High-quality likes", "24/7 support"],
      popular: false,
    },
    {
      title: "200K Likes",
      price: INSTAGRAM_LIKES_PRICES["200,000"],
      features: ["Delivery within 0-24 hours", "High-quality likes", "24/7 support"],
      popular: false,
    },
    {
      title: "500K Likes",
      price: INSTAGRAM_LIKES_PRICES["500,000"],
      features: ["Delivery within 0-24 hours", "High-quality likes", "24/7 support"],
      popular: false,
    },
  ];

  const viewPackages = [
    {
      title: "100 Views",
      price: "$0.10",
      features: ["Delivery within 0-24 hours", "Real views", "24/7 support"],
      popular: false,
    },
    {
      title: "250 Views",
      price: "$0.25",
      features: ["Delivery within 0-24 hours", "Real views", "24/7 support"],
      popular: false,
    },
    {
      title: "500 Views",
      price: "$0.50",
      features: ["Delivery within 0-24 hours", "Real views", "24/7 support"],
      popular: false,
    },
    {
      title: "1K Views",
      price: "$0.99",
      features: ["Delivery within 0-24 hours", "Real views", "24/7 support"],
      popular: true,
    },
    {
      title: "2.5K Views",
      price: "$2.00",
      features: ["Delivery within 0-24 hours", "Real views", "24/7 support"],
      popular: false,
    },
    {
      title: "5K Views",
      price: "$3.75",
      features: ["Delivery within 0-24 hours", "Real views", "24/7 support"],
      popular: false,
    },
    {
      title: "10K Views",
      price: "$6.99",
      features: ["Delivery within 0-24 hours", "Real views", "24/7 support"],
      popular: false,
    },
    {
      title: "20K Views",
      price: "$12.99",
      features: ["Delivery within 0-24 hours", "Real views", "24/7 support"],
      popular: false,
    },
    {
      title: "50K Views",
      price: "$22.99",
      features: ["Delivery within 0-24 hours", "Real views", "24/7 support"],
      popular: false,
    },
    {
      title: "100K Views",
      price: "$39.99",
      features: ["Delivery within 0-24 hours", "Real views", "24/7 support"],
      popular: false,
    },
    {
      title: "200K Views",
      price: "$74.99",
      features: ["Delivery within 0-24 hours", "Real views", "24/7 support"],
      popular: false,
    },
    {
      title: "500K Views",
      price: "$149.99",
      features: ["Delivery within 0-24 hours", "Real views", "24/7 support"],
      popular: false,
    },
  ];

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: { 
      opacity: 1,
      transition: { 
        staggerChildren: 0.05,
        duration: 0.5
      }
    }
  };

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: { y: 0, opacity: 1 }
  };

  return (
    <div className="min-h-screen w-full">
      <Helmet>
        <title>Instagram Packages - Social Boost</title>
        <meta name="description" content="Boost your Instagram presence with our premium packages" />
      </Helmet>

      <Navbar />
      
      <motion.main 
        className="container mx-auto px-4 py-8"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <motion.div 
          className="mb-8 text-center"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.1 }}
        >
          <div className="flex items-center justify-center mb-4">
            <Instagram className="w-12 h-12 mr-2 text-primary" />
            <h1 className="text-4xl font-bold">Instagram Packages</h1>
          </div>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Choose from our range of high-quality Instagram services to enhance your social media presence
          </p>
        </motion.div>

        <Tabs defaultValue="followers" className="w-full">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            <TabsList className="grid w-full grid-cols-3 mb-8">
              <TabsTrigger value="followers">Followers</TabsTrigger>
              <TabsTrigger value="likes">Likes</TabsTrigger>
              <TabsTrigger value="views">Views</TabsTrigger>
            </TabsList>
          </motion.div>
          
          <TabsContent value="followers" className="mt-6">
            <motion.div 
              className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6"
              variants={containerVariants}
              initial="hidden"
              animate="visible"
            >
              {followerPackages.map((pkg, index) => (
                <motion.div key={index} variants={itemVariants}>
                  <PricingCard
                    title={pkg.title}
                    price={pkg.price}
                    features={pkg.features}
                    icon={<Instagram />}
                    popular={pkg.popular}
                    service="Instagram"
                    category="Followers"
                  />
                </motion.div>
              ))}
            </motion.div>
          </TabsContent>
          
          <TabsContent value="likes" className="mt-6">
            <motion.div 
              className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6"
              variants={containerVariants}
              initial="hidden"
              animate="visible"
            >
              {likePackages.map((pkg, index) => (
                <motion.div key={index} variants={itemVariants}>
                  <PricingCard
                    title={pkg.title}
                    price={pkg.price}
                    features={pkg.features}
                    icon={<Instagram />}
                    popular={pkg.popular}
                    service="Instagram"
                    category="Likes"
                  />
                </motion.div>
              ))}
            </motion.div>
          </TabsContent>
          
          <TabsContent value="views" className="mt-6">
            <motion.div 
              className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6"
              variants={containerVariants}
              initial="hidden"
              animate="visible"
            >
              {viewPackages.map((pkg, index) => (
                <motion.div key={index} variants={itemVariants}>
                  <PricingCard
                    title={pkg.title}
                    price={pkg.price}
                    features={pkg.features}
                    icon={<Instagram />}
                    popular={pkg.popular}
                    service="Instagram"
                    category="Views"
                  />
                </motion.div>
              ))}
            </motion.div>
          </TabsContent>
        </Tabs>
      </motion.main>
      
      <Footer />
    </div>
  );
};

export default InstagramPackages;
