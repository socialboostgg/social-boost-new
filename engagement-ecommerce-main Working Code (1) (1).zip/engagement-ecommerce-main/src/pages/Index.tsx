
import { useState, useRef } from "react";
import { FollowersPackagesDialog } from "@/components/FollowersPackagesDialog";
import { Navbar } from "@/components/layout/Navbar";
import { HeroSection } from "@/components/home/HeroSection";
import { ServicesSection } from "@/components/home/ServicesSection";
import { FeaturesSection } from "@/components/home/FeaturesSection";
import { TestimonialsSection } from "@/components/home/TestimonialsSection";
import { FAQSection } from "@/components/home/FAQSection";
import { Footer } from "@/components/layout/Footer";
import { FreeFollowersPromo } from "@/components/home/FreeFollowersPromo";

const Index = () => {
  const [showPackages, setShowPackages] = useState(false);
  const servicesRef = useRef<HTMLElement>(null);
  const faqRef = useRef<HTMLElement>(null);

  const scrollToServices = () => {
    servicesRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const scrollToFAQ = () => {
    faqRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen w-full overflow-hidden">
      <Navbar />
      <FreeFollowersPromo />
      <HeroSection scrollToServices={scrollToServices} scrollToFAQ={scrollToFAQ} />
      <ServicesSection ref={servicesRef} />
      <FeaturesSection />
      <TestimonialsSection />
      <FAQSection ref={faqRef} />
      <Footer />

      <FollowersPackagesDialog
        open={showPackages}
        onOpenChange={setShowPackages}
      />
    </div>
  );
};

export default Index;
