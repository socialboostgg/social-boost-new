
import React, { createContext, useContext, useState, useEffect } from "react";
import { toast } from "sonner";
import { orderSocialMediaService, extractQuantityFromTitle } from "@/utils/serviceController";
import { supabase } from "@/lib/supabase";
import { useAuth } from "@/context/AuthContext";

export type CartItem = {
  id: string;
  title: string;
  price: string;
  service: string;
  category: string;
  priceNumeric: number;
};

type OrderStatus = {
  itemId: string;
  orderId: string;
  orderNumber: string;
  status: "pending" | "processing" | "completed" | "failed";
};

type CartContextType = {
  items: CartItem[];
  addItem: (item: CartItem) => void;
  removeItem: (id: string) => void;
  clearCart: () => void;
  itemCount: number;
  total: number;
  placeOrders: (socialLink: string) => Promise<boolean>;
  orderHistory: OrderStatus[];
  fetchOrderHistory: () => Promise<void>;
};

const CartContext = createContext<CartContextType | undefined>(undefined);

export const CartProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user, isLoggedIn } = useAuth();
  const [items, setItems] = useState<CartItem[]>(() => {
    const savedItems = localStorage.getItem("cart-items");
    return savedItems ? JSON.parse(savedItems) : [];
  });
  
  const [orderHistory, setOrderHistory] = useState<OrderStatus[]>([]);

  useEffect(() => {
    localStorage.setItem("cart-items", JSON.stringify(items));
  }, [items]);

  // Fetch order history when user logs in
  useEffect(() => {
    if (isLoggedIn && user) {
      fetchOrderHistory();
    } else {
      setOrderHistory([]);
    }
  }, [isLoggedIn, user]);

  const addItem = (item: CartItem) => {
    const exists = items.some((i) => i.id === item.id);
    
    if (exists) {
      toast(`"${item.title}" is already in your cart`);
      return;
    }
    
    setItems((prev) => [...prev, item]);
    toast.success(`Added "${item.title}" to cart`);
  };

  const removeItem = (id: string) => {
    const item = items.find((i) => i.id === id);
    setItems((prev) => prev.filter((item) => item.id !== id));
    if (item) {
      toast.info(`Removed "${item.title}" from cart`);
    }
  };

  const clearCart = () => {
    setItems([]);
    toast.info("Cart cleared");
  };

  const fetchOrderHistory = async () => {
    if (!isLoggedIn || !user) {
      return;
    }
    
    try {
      const { data, error } = await supabase
        .from('orders')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });
      
      if (error) {
        console.error("Error fetching order history:", error);
        return;
      }
      
      if (data) {
        const formattedOrders: OrderStatus[] = data.map(order => ({
          itemId: order.id,
          orderId: order.provider_order_id || order.id,
          orderNumber: order.order_number,
          status: order.status as "pending" | "processing" | "completed" | "failed",
        }));
        
        setOrderHistory(formattedOrders);
      }
    } catch (error) {
      console.error("Unexpected error fetching orders:", error);
    }
  };

  const placeOrders = async (socialLink: string): Promise<boolean> => {
    if (items.length === 0) {
      toast.error("Your cart is empty");
      return false;
    }

    if (!isLoggedIn || !user) {
      toast.error("You must be logged in to place orders");
      return false;
    }

    try {
      const orderPromises = items.map(async (item) => {
        const quantity = extractQuantityFromTitle(item.title);
        
        if (!quantity) {
          toast.error(`Could not determine quantity for ${item.title}`);
          return { success: false, itemId: item.id };
        }
        
        try {
          // Call the external service API
          const orderResponse = await orderSocialMediaService(
            item.service,
            item.category,
            quantity,
            socialLink
          );
          
          // Store the order in our database regardless of external API success
          const { data: orderData, error: orderError } = await supabase
            .from('orders')
            .insert([
              {
                user_id: user.id,
                service_type: item.service,
                category: item.category,
                social_link: socialLink,
                quantity: quantity,
                price: item.priceNumeric,
                status: orderResponse.order ? 'processing' : 'failed',
                provider_order_id: orderResponse.order?.toString(),
              }
            ])
            .select()
            .single();
          
          if (orderError) {
            console.error(`Error storing order in database:`, orderError);
            return { success: false, itemId: item.id };
          }
          
          if (orderResponse.order) {
            return { 
              success: true, 
              itemId: item.id, 
              orderId: orderResponse.order,
              orderNumber: orderData.order_number
            };
          }
          
          return { success: false, itemId: item.id };
        } catch (error) {
          console.error(`Error placing order for ${item.title}:`, error);
          return { success: false, itemId: item.id };
        }
      });

      const results = await Promise.all(orderPromises);
      
      const allSuccessful = results.every(result => result.success);
      
      // Refresh order history
      await fetchOrderHistory();
      
      if (allSuccessful) {
        clearCart();
        toast.success("All orders have been successfully placed!");
        return true;
      } else {
        const failedItemIds = results
          .filter(result => !result.success)
          .map(result => result.itemId);
        
        setItems(prev => prev.filter(item => failedItemIds.includes(item.id)));
        
        toast.error("Some orders failed to process. Failed items remain in your cart.");
        return false;
      }
    } catch (error) {
      console.error("Error processing orders:", error);
      toast.error("Error processing your orders. Please try again.");
      return false;
    }
  };

  const itemCount = items.length;
  
  const total = items.reduce((acc, item) => {
    return acc + item.priceNumeric;
  }, 0);

  return (
    <CartContext.Provider
      value={{ 
        items, 
        addItem, 
        removeItem, 
        clearCart, 
        itemCount, 
        total, 
        placeOrders,
        orderHistory,
        fetchOrderHistory
      }}
    >
      {children}
    </CartContext.Provider>
  );
};

export const useCart = () => {
  const context = useContext(CartContext);
  if (context === undefined) {
    throw new Error("useCart must be used within a CartProvider");
  }
  return context;
};
