
import { createContext, useContext, useEffect, useState, ReactNode } from "react";
import { User } from "@supabase/supabase-js";
import { supabase, signUpWithoutEmailConfirmation } from "@/lib/supabase";
import { toast } from "sonner";

type UserProfile = {
  id: string;
  email: string;
  fullName: string;
};

type AuthContextType = {
  user: UserProfile | null;
  isLoggedIn: boolean;
  login: (email: string, password: string) => Promise<{ success: boolean; error?: string }>;
  signup: (email: string, password: string, fullName: string) => Promise<{ success: boolean; error?: string }>;
  logout: () => Promise<void>;
  loading: boolean;
};

// Create the context with a default undefined value
const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider = ({ children }: { children: ReactNode }) => {
  const [user, setUser] = useState<UserProfile | null>(null);
  const [isLoggedIn, setIsLoggedIn] = useState<boolean>(false);
  const [loading, setLoading] = useState<boolean>(true);

  useEffect(() => {
    const getInitialSession = async () => {
      setLoading(true);
      
      const { data: { session }, error } = await supabase.auth.getSession();
      
      if (error) {
        console.error("Error fetching session:", error);
        setLoading(false);
        return;
      }
      
      if (session?.user) {
        const { data: profile, error: profileError } = await supabase
          .from('profiles')
          .select('*')
          .eq('id', session.user.id)
          .single();
        
        if (profileError && profileError.code !== 'PGRST116') {
          console.error("Error fetching user profile:", profileError);
        }
        
        const userProfile: UserProfile = {
          id: session.user.id,
          email: session.user.email || '',
          fullName: profile?.full_name || session.user.email?.split('@')[0] || '',
        };
        
        setUser(userProfile);
        setIsLoggedIn(true);
      } else {
        // Explicitly set logged out state
        setUser(null);
        setIsLoggedIn(false);
      }
      
      setLoading(false);
    };
    
    const { data: { subscription } } = supabase.auth.onAuthStateChange(async (event, session) => {
      console.log("Auth state changed:", event);
      
      if (event === 'SIGNED_IN' && session?.user) {
        const { data: profile, error: profileError } = await supabase
          .from('profiles')
          .select('*')
          .eq('id', session.user.id)
          .single();
          
        if (profileError && profileError.code !== 'PGRST116') {
          console.error("Error fetching user profile:", profileError);
        }
        
        const userProfile: UserProfile = {
          id: session.user.id,
          email: session.user.email || '',
          fullName: profile?.full_name || session.user.email?.split('@')[0] || '',
        };
        
        setUser(userProfile);
        setIsLoggedIn(true);
      } else if (event === 'SIGNED_OUT') {
        // Immediately update the state when signed out
        setUser(null);
        setIsLoggedIn(false);
      }
    });
    
    getInitialSession();
    
    return () => {
      subscription.unsubscribe();
    };
  }, []);

  const login = async (email: string, password: string) => {
    try {
      setLoading(true);
      
      console.log("Attempting login for:", email);
      
      const { data, error } = await supabase.auth.signInWithPassword({ email, password });
      
      if (error) {
        console.error("Login error:", error);
        
        if (error.message.includes('Email not confirmed')) {
          return { success: false, error: error.message };
        }
        
        return { success: false, error: error.message };
      }
      
      // Successfully logged in
      if (data.user) {
        const { data: profile, error: profileError } = await supabase
          .from('profiles')
          .select('*')
          .eq('id', data.user.id)
          .single();
          
        const userProfile: UserProfile = {
          id: data.user.id,
          email: data.user.email || '',
          fullName: profile?.full_name || data.user.email?.split('@')[0] || '',
        };
        
        setUser(userProfile);
        setIsLoggedIn(true);
      }
      
      return { success: true };
    } catch (error) {
      console.error("Unexpected login error:", error);
      return { 
        success: false, 
        error: error instanceof Error ? error.message : "An unexpected error occurred" 
      };
    } finally {
      setLoading(false);
    }
  };

  const signup = async (email: string, password: string, fullName: string) => {
    try {
      setLoading(true);
      const { data, error } = await signUpWithoutEmailConfirmation(
        email, 
        password,
        { full_name: fullName }
      );
      
      if (error) {
        console.error("Signup error:", error);
        return { success: false, error: error.message };
      }
      
      // Check if user was created and signed in
      if (data?.user) {
        const userProfile: UserProfile = {
          id: data.user.id,
          email: data.user.email || '',
          fullName: fullName,
        };
        
        setUser(userProfile);
        setIsLoggedIn(true);
      }
      
      return { success: true };
    } catch (error) {
      console.error("Unexpected signup error:", error);
      return { 
        success: false, 
        error: error instanceof Error ? error.message : "An unexpected error occurred" 
      };
    } finally {
      setLoading(false);
    }
  };

  const logout = async () => {
    try {
      setLoading(true);
      
      const { error } = await supabase.auth.signOut();
      
      if (error) {
        console.error("Logout error:", error);
        throw new Error(error.message);
      }
      
      // Immediately update state
      setUser(null);
      setIsLoggedIn(false);
    } catch (error) {
      console.error("Unexpected logout error:", error);
      throw error;
    } finally {
      setLoading(false);
    }
  };

  const contextValue: AuthContextType = {
    user,
    isLoggedIn,
    login,
    signup,
    logout,
    loading
  };

  return (
    <AuthContext.Provider value={contextValue}>
      {children}
    </AuthContext.Provider>
  );
};

// Create a custom hook to use the auth context
export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
};
