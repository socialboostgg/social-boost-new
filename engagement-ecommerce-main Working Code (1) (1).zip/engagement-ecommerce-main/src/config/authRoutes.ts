
/**
 * Configuration file for authentication routes
 * Defines which routes are public and which require authentication
 */

// Routes that don't require authentication
export const publicRoutes = [
  // Stripe webhook endpoints
  "/api/webhook",
  "/api/webhooks",
  "/functions/v1/stripe-webhooks",
  "/functions/v1/create-payment-intent",
  "/functions/v1/confirm-payment",
  
  // Public pages
  "/",
  "/instagram-packages",
  "/tiktok-packages",
  "/youtube-packages",
  "/twitter-packages",
  "/facebook-packages",
  "/spotify-packages",
  "/twitch-packages",
  "/soundcloud-packages",
  "/pinterest-packages",
  "/telegram-packages",
  "/all-services",
  "/support",
  "/login",
  "/signup",
];

// Routes that always redirect to signin if the user is not authenticated
export const authRoutes = [
  "/account",
  "/orders",
  "/checkout",
];

// Where to redirect after signin if no previous destination was saved
export const DEFAULT_SIGNIN_REDIRECT = "/";
