
import { HashRouter as Router, Routes, Route, Navigate } from "react-router-dom";
import Index from "@/pages/Index";
import NotFound from "@/pages/NotFound";
import Login from "@/pages/Login";
import Signup from "@/pages/Signup";
import InstagramPackages from "@/pages/InstagramPackages";
import TiktokPackages from "@/pages/TiktokPackages";
import YoutubePackages from "@/pages/YoutubePackages";
import TwitterPackages from "@/pages/TwitterPackages";
import FacebookPackages from "@/pages/FacebookPackages";
import SpotifyPackages from "@/pages/SpotifyPackages";
import TwitchPackages from "@/pages/TwitchPackages";
import SoundCloudPackages from "@/pages/SoundCloudPackages";
import PinterestPackages from "@/pages/PinterestPackages";
import TelegramPackages from "@/pages/TelegramPackages";
import Support from "@/pages/Support";
import Account from "@/pages/Account";
import Orders from "@/pages/Orders";
import Tickets from "@/pages/Tickets";
import AllServices from "@/pages/AllServices";
import Cart from "@/pages/Cart";
import Checkout from "@/pages/Checkout";
import AdminTickets from "@/pages/AdminTickets";
import FreeFollowers from "@/pages/FreeFollowers";
import "./App.css";
import { CartProvider } from "./context/CartContext";
import { AuthProvider, useAuth } from "./context/AuthContext";
import { Toaster } from "@/components/ui/sonner";
import ScrollToTop from "@/components/ScrollToTop";
import { publicRoutes, authRoutes } from "./config/authRoutes";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";

// Create a new QueryClient instance
const queryClient = new QueryClient();

// Create a separate component for protected routes to avoid using useAuth at the top level
function ProtectedRoute({ children }: { children: React.ReactNode }) {
  const { isLoggedIn } = useAuth();
  
  if (!isLoggedIn) {
    return <Navigate to="/" replace />;
  }
  
  return <>{children}</>;
}

// Separate the routes into their own component to avoid circular dependencies
const AppRoutes = () => {
  return (
    <Routes>
      <Route path="/" element={<Index />} />
      <Route path="/instagram-packages" element={<InstagramPackages />} />
      <Route path="/tiktok-packages" element={<TiktokPackages />} />
      <Route path="/youtube-packages" element={<YoutubePackages />} />
      <Route path="/twitter-packages" element={<TwitterPackages />} />
      <Route path="/facebook-packages" element={<FacebookPackages />} />
      <Route path="/spotify-packages" element={<SpotifyPackages />} />
      <Route path="/twitch-packages" element={<TwitchPackages />} />
      <Route path="/soundcloud-packages" element={<SoundCloudPackages />} />
      <Route path="/pinterest-packages" element={<PinterestPackages />} />
      <Route path="/telegram-packages" element={<TelegramPackages />} />
      <Route path="/all-services" element={<AllServices />} />
      <Route path="/support" element={<Support />} />
      <Route path="/free-followers" element={<FreeFollowers />} />
      {/* These routes now redirect to home since we use dialog instead */}
      <Route path="/login" element={<Login />} />
      <Route path="/signup" element={<Signup />} />
      <Route path="/cart" element={<Cart />} />
      <Route path="/checkout" element={<Checkout />} />
      
      {/* Protected routes */}
      <Route path="/account" element={<ProtectedRoute><Account /></ProtectedRoute>} />
      <Route path="/tickets" element={<ProtectedRoute><Tickets /></ProtectedRoute>} />
      <Route path="/orders" element={<ProtectedRoute><Orders /></ProtectedRoute>} />
      <Route path="/admin/tickets" element={<ProtectedRoute><AdminTickets /></ProtectedRoute>} />
      
      {/* 404 route */}
      <Route path="*" element={<NotFound />} />
    </Routes>
  );
};

const App = () => {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <CartProvider>
          <Router>
            <ScrollToTop />
            <AppRoutes />
            <Toaster />
          </Router>
        </CartProvider>
      </AuthProvider>
    </QueryClientProvider>
  );
};

export default App;
