
import { createClient } from '@supabase/supabase-js';

const supabaseUrl = 'https://qcypykfhygfzijffxlej.supabase.co';
const supabaseAnonKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InFjeXB5a2ZoeWdmemlqZmZ4bGVqIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDEwNTUxNDgsImV4cCI6MjA1NjYzMTE0OH0.cK2snkWB6y742slC4WbFcK7DgaaLOW80zpd6bR5cRzM';

export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: {
    autoRefreshToken: true,
    persistSession: true,
    detectSessionInUrl: true
  }
});

// Direct signup function that skips email verification
export const signUpWithoutVerification = async (email: string, password: string, metadata?: any) => {
  try {
    // First check if user already exists and attempt to sign in directly
    const { data: signInData, error: signInError } = await supabase.auth.signInWithPassword({
      email,
      password
    });
    
    // If user exists and can sign in, return success
    if (signInData?.user) {
      console.log("User already exists, signed in successfully");
      return { data: signInData, error: null };
    }
    
    // If login error is not "invalid_credentials", it might be "email_not_confirmed"
    // We'll proceed with signup regardless
    console.log("Creating new user account...");
    
    // Create a new user
    const { data: signUpData, error: signUpError } = await supabase.auth.signUp({
      email,
      password,
      options: {
        data: metadata,
        emailRedirectTo: window.location.origin,
      }
    });
    
    if (signUpError) {
      // If we get an error that isn't about email confirmation
      if (signUpError.message !== "Email not confirmed" && 
          !signUpError.message.includes("confirmation")) {
        console.error("Signup error:", signUpError);
        return { data: null, error: signUpError };
      }
      
      // If error is about email confirmation, try signing in directly anyway
      console.log("User created but email confirmation required. Attempting direct login...");
    }
    
    // Always attempt to sign in directly after signup, regardless of whether email confirmation is required
    // This might work if email confirmation is disabled in Supabase project settings
    console.log("Attempting immediate sign in after signup");
    
    const { data: finalSignInData, error: finalSignInError } = await supabase.auth.signInWithPassword({
      email,
      password
    });
    
    if (finalSignInError) {
      // If we still can't sign in, return an appropriate error
      if (finalSignInError.message === "Email not confirmed") {
        console.error("Email confirmation is required by your Supabase project settings");
        return { 
          data: null, 
          error: {
            ...finalSignInError,
            message: "Account created, but email verification is required. Please check your email."
          }
        };
      }
      
      console.error("Sign in error after signup:", finalSignInError);
      return { data: null, error: finalSignInError };
    }
    
    return { data: finalSignInData, error: null };
  } catch (error) {
    console.error("Unexpected error during signup/signin process:", error);
    return { 
      data: null, 
      error: {
        message: error instanceof Error ? error.message : "An unexpected error occurred"
      }
    };
  }
};

// Helper function to manually verify an email (keeping for reference)
export const manuallyVerifyEmail = async (email: string) => {
  try {
    // This requires admin privileges and won't work with anon key
    // This is just a placeholder to indicate what would need to be done server-side
    console.log(`Would verify email: ${email} (requires server-side implementation)`);
    return true;
  } catch (error) {
    console.error("Error verifying email:", error);
    return false;
  }
};

// Legacy function (keeping for backwards compatibility)
export const signUpWithoutEmailConfirmation = async (email: string, password: string, metadata?: any) => {
  return signUpWithoutVerification(email, password, metadata);
};
