import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Mail, Lock, Eye, EyeOff } from "lucide-react";
import { toast } from "sonner";
import { useAuth } from "@/context/AuthContext";
import { supabase } from "@/lib/supabase";
import { Checkbox } from "@/components/ui/checkbox";

type LoginFormProps = {
  onSuccess: () => void;
};

export function LoginForm({ onSuccess }: LoginFormProps) {
  const { login } = useAuth();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [authError, setAuthError] = useState<string | null>(null);
  const [rememberMe, setRememberMe] = useState(false);
  const [forgotPasswordMode, setForgotPasswordMode] = useState(false);
  const [resetEmailSent, setResetEmailSent] = useState(false);

  const resetState = () => {
    setIsSubmitting(false);
    setAuthError(null);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError(null);

    // Validate form
    if (!email || !password) {
      toast.error("Please fill in all required fields");
      return;
    }

    setIsSubmitting(true);
    
    try {
      console.log("Attempting login with:", email);
      // Use the login method from AuthContext instead of direct Supabase call
      const { success, error } = await login(email, password);
      
      if (success) {
        console.log("Login successful");
        // Reset form state
        resetState();
        
        // Show success toast and call the onSuccess callback
        toast.success("Logged in successfully!");
        onSuccess();
        return;
      }
      
      if (error) {
        console.log("Login error:", error);
        
        if (error.includes("Email not confirmed")) {
          // Clear the existing error and show a more specific message
          setAuthError("Your email is not confirmed. Please check your inbox for a verification email or try signing up again.");
        } else if (error.includes("Invalid login credentials")) {
          setAuthError("Invalid email or password. Please check your credentials.");
        } else {
          setAuthError(error);
        }
      }
    } catch (err) {
      console.error("Unexpected login error:", err);
      setAuthError("An unexpected error occurred. Please try again.");
    } finally {
      setIsSubmitting(false);
    }
  };

  const resetForm = () => {
    setIsSubmitting(false);
    setAuthError(null);
    setForgotPasswordMode(false);
    setResetEmailSent(false);
  };

  const handleForgotPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError(null);

    // Validate email
    if (!email) {
      toast.error("Please enter your email address");
      return;
    }

    setIsSubmitting(true);
    
    try {
      const { error } = await supabase.auth.resetPasswordForEmail(email, {
        redirectTo: `${window.location.origin}/reset-password`,
      });
      
      if (error) {
        console.log("Password reset error:", error.message);
        setAuthError(error.message);
      } else {
        setResetEmailSent(true);
        toast.success("Password reset email sent! Please check your inbox.");
      }
    } catch (err) {
      console.error("Unexpected error during password reset:", err);
      setAuthError("An unexpected error occurred. Please try again.");
    } finally {
      setIsSubmitting(false);
    }
  };

  // Switch to login mode and reset states
  const switchToLoginMode = () => {
    resetForm();
  };

  // Switch to forgot password mode and reset states
  const switchToForgotPasswordMode = () => {
    resetForm();
    setForgotPasswordMode(true);
  };

  return (
    <form onSubmit={forgotPasswordMode ? handleForgotPassword : handleSubmit} className="space-y-4">
      {forgotPasswordMode ? (
        <>
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <Mail className="h-4 w-4 text-muted-foreground" />
              <label htmlFor="email" className="text-sm font-medium">
                Email Address
              </label>
            </div>
            <Input
              id="email"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="your.email@example.com"
            />
          </div>

          {resetEmailSent ? (
            <div className="text-sm text-green-600 mt-2 p-2 bg-green-50 rounded border border-green-200">
              Password reset email sent! Please check your inbox for instructions.
            </div>
          ) : (
            <p className="text-sm text-muted-foreground">
              Enter your email address and we'll send you a link to reset your password.
            </p>
          )}

          {authError && (
            <div className="text-sm text-red-500 mt-2 p-2 bg-red-50 rounded border border-red-200">
              {authError}
            </div>
          )}

          <div className="flex flex-col gap-2">
            <Button type="submit" className="w-full" disabled={isSubmitting || resetEmailSent}>
              {isSubmitting ? "Sending..." : "Send Reset Link"}
            </Button>
            <Button 
              type="button" 
              variant="ghost" 
              className="w-full" 
              onClick={switchToLoginMode}
            >
              Back to Login
            </Button>
          </div>
        </>
      ) : (
        <>
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <Mail className="h-4 w-4 text-muted-foreground" />
              <label htmlFor="email" className="text-sm font-medium">
                Email Address
              </label>
            </div>
            <Input
              id="email"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="your.email@example.com"
            />
          </div>

          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <Lock className="h-4 w-4 text-muted-foreground" />
              <label htmlFor="password" className="text-sm font-medium">
                Password
              </label>
            </div>
            <div className="relative">
              <Input
                id="password"
                type={showPassword ? "text" : "password"}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
              />
              <Button
                type="button"
                variant="ghost"
                size="sm"
                className="absolute right-0 top-0 h-10 px-3"
                onClick={() => setShowPassword(!showPassword)}
              >
                {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                <span className="sr-only">{showPassword ? "Hide" : "Show"} password</span>
              </Button>
            </div>
          </div>

          {authError && (
            <div className="text-sm text-red-500 mt-2 p-2 bg-red-50 rounded border border-red-200">
              {authError}
            </div>
          )}

          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Checkbox
                id="remember"
                checked={rememberMe}
                onCheckedChange={(checked) => setRememberMe(checked === true)}
              />
              <label htmlFor="remember" className="text-sm text-muted-foreground">
                Remember me
              </label>
            </div>
            <Button
              type="button"
              variant="link"
              className="text-sm font-medium p-0 h-auto text-primary"
              onClick={switchToForgotPasswordMode}
            >
              Forgot password?
            </Button>
          </div>

          <Button type="submit" className="w-full" disabled={isSubmitting}>
            {isSubmitting ? "Logging in..." : "Log In"}
          </Button>
        </>
      )}
    </form>
  );
}
