
import { Link } from "react-router-dom";

export const Footer = () => {
  return (
    <>
      <div className="gradient-bottom-to-footer h-32 w-full"></div>

      <footer className="py-12 px-4 bg-accent w-full">
        <div className="container mx-auto">
          <div className="grid md:grid-cols-3 gap-8">
            <div>
              <h3 className="font-semibold mb-4">Company</h3>
              <ul className="space-y-2">
                <li><Link to="/about" className="text-muted-foreground hover:text-primary">About</Link></li>
                <li><Link to="/contact" className="text-muted-foreground hover:text-primary">Contact</Link></li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold mb-4">Services</h3>
              <ul className="space-y-2">
                <li><Link to="/instagram-packages" className="text-muted-foreground hover:text-primary">Instagram</Link></li>
                <li><Link to="/tiktok-packages" className="text-muted-foreground hover:text-primary">TikTok</Link></li>
                <li><Link to="/youtube-packages" className="text-muted-foreground hover:text-primary">YouTube</Link></li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold mb-4">Support</h3>
              <ul className="space-y-2">
                <li><Link to="/faq" className="text-muted-foreground hover:text-primary">FAQ</Link></li>
                <li><Link to="/help" className="text-muted-foreground hover:text-primary">Help Center</Link></li>
              </ul>
            </div>
          </div>
          <div className="mt-12 pt-8 border-t text-center text-muted-foreground">
            <p>&copy; 2025 Social Boost. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </>
  );
};
