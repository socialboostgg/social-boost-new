
import React from 'react';
import { Card } from '@/components/ui/card';
import { Loader2, TicketIcon, AlertCircle } from 'lucide-react';
import { type Ticket } from '@/utils/ticketService';

interface TicketsListProps {
  tickets?: Ticket[];
  isLoading: boolean;
  error?: string | null;
}

const TicketsList = ({ tickets, isLoading, error }: TicketsListProps) => {
  if (isLoading) {
    return (
      <div className="flex justify-center items-center py-10">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="text-center py-8">
        <AlertCircle className="h-8 w-8 text-destructive mx-auto mb-2" />
        <p className="text-muted-foreground">{error}</p>
      </div>
    );
  }

  if (!tickets || tickets.length === 0) {
    return (
      <div className="text-center py-10">
        <TicketIcon className="h-8 w-8 text-muted-foreground mx-auto mb-2" />
        <p className="text-muted-foreground">You have no support tickets yet.</p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {tickets.map((ticket) => (
        <Card key={ticket.id} className="p-4">
          <div className="flex justify-between items-start mb-2">
            <h4 className="font-medium">{ticket.subject}</h4>
            <span className={`px-2 py-1 text-xs rounded-full ${
              ticket.status === 'open' 
                ? 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300' 
                : ticket.status === 'in_progress'
                ? 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300'
                : 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300'
            }`}>
              {ticket.status === 'open' ? 'Open' : ticket.status === 'in_progress' ? 'In Progress' : 'Closed'}
            </span>
          </div>
          <p className="text-sm text-muted-foreground mb-2 line-clamp-2">{ticket.message}</p>
          <div className="text-xs text-muted-foreground">
            Created: {new Date(ticket.created_at).toLocaleDateString()}
          </div>
        </Card>
      ))}
    </div>
  );
};

export default TicketsList;
