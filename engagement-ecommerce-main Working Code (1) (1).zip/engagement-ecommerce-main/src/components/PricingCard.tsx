
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useState } from "react";
import { ShoppingCart, CreditCard } from "lucide-react";
import { useCart } from "@/context/CartContext";
import { Link } from "react-router-dom";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

interface PricingCardProps {
  title: string;
  price: string;
  features: string[];
  icon: React.ReactNode;
  popular?: boolean;
  service: string;
  category: string;
}

export function PricingCard({ title, price, features, icon, popular, service, category }: PricingCardProps) {
  const [showDialog, setShowDialog] = useState(false);
  const { addItem } = useCart();
  
  const handleBuyClick = () => {
    setShowDialog(true);
  };
  
  const handleAddToCart = () => {
    // Convert price string to number for calculations
    const priceNumeric = parseFloat(price.replace(/[^0-9.]/g, ''));
    
    addItem({
      id: `${service}-${category}-${title}`,
      title: `${title} ${category} (${service})`,
      price: price,
      service: service,
      category: category,
      priceNumeric: priceNumeric
    });
    
    setShowDialog(false);
  };

  return (
    <>
      <Card className={`relative p-6 transition-all duration-300 hover:shadow-lg ${
        popular ? 'border-2 border-primary' : 'border border-border/30'
      }`}>
        {popular && (
          <div className="absolute -top-3 left-1/2 -translate-x-1/2 px-3 py-1 bg-primary rounded-full text-white text-sm font-medium">
            Most Popular
          </div>
        )}
        <div className="flex items-center justify-center mb-4 text-4xl text-primary">
          {icon}
        </div>
        <h3 className="text-xl font-semibold text-center mb-2">{title}</h3>
        <div className="text-center mb-6">
          <span className="text-3xl font-bold">{price}</span>
          <span className="text-muted-foreground"> one-time</span>
        </div>
        <ul className="space-y-3 mb-6">
          {features.map((feature, index) => (
            <li key={index} className="flex items-center text-sm text-muted-foreground">
              <svg
                className="w-4 h-4 mr-2 text-primary"
                fill="none"
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth="2"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path d="M5 13l4 4L19 7" />
              </svg>
              {feature}
            </li>
          ))}
        </ul>
        <Button className="w-full" variant={popular ? "default" : "outline"} onClick={handleBuyClick}>
          Buy Now
        </Button>
      </Card>
      
      <Dialog open={showDialog} onOpenChange={setShowDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{title} {category}</DialogTitle>
            <DialogDescription>
              Would you like to add this item to your cart or proceed directly to checkout?
            </DialogDescription>
          </DialogHeader>
          <DialogFooter className="flex flex-col sm:flex-row gap-2">
            <Button variant="outline" className="flex-1" onClick={handleAddToCart}>
              <ShoppingCart className="mr-2 h-4 w-4" />
              Add to Cart
            </Button>
            <Button variant="default" className="flex-1" onClick={handleAddToCart} asChild>
              <Link to="/checkout">
                <CreditCard className="mr-2 h-4 w-4" />
                Checkout Now
              </Link>
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
