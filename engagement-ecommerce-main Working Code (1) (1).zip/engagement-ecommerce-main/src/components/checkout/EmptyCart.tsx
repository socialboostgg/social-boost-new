
import { Button } from "@/components/ui/button";
import { ShoppingBag, ArrowLeft } from "lucide-react";
import { Link } from "react-router-dom";

export const EmptyCart = () => {
  return (
    <div className="text-center py-16">
      <div className="mb-4 flex justify-center">
        <ShoppingBag className="w-16 h-16 text-muted-foreground/30" />
      </div>
      <h2 className="text-2xl font-semibold mb-2">Your cart is empty</h2>
      <p className="text-muted-foreground mb-8">
        You need to add items to your cart before checking out.
      </p>
      <Button asChild>
        <Link to="/cart">
          <ArrowLeft className="mr-2 h-4 w-4" />
          Return to Cart
        </Link>
      </Button>
    </div>
  );
};
