
import { useCart } from "@/context/CartContext";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";

export const OrderSummary = () => {
  const { items } = useCart();
  
  return (
    <Card>
      <CardHeader>
        <CardTitle>Order Summary</CardTitle>
        <CardDescription>
          {items.length} {items.length === 1 ? 'item' : 'items'} in your cart
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {items.map((item) => (
            <div key={item.id} className="flex justify-between">
              <span className="text-sm">{item.title}</span>
              <span className="font-medium">{item.price}</span>
            </div>
          ))}
          
          <Separator />
          
          <div className="flex justify-between font-semibold">
            <span>Total</span>
            <span>${items.reduce((acc, item) => acc + item.priceNumeric, 0).toFixed(2)}</span>
          </div>
        </div>
      </CardContent>
      <CardFooter className="text-xs text-muted-foreground">
        <p>Secure payment processing. Your data is encrypted and secure.</p>
      </CardFooter>
    </Card>
  );
};
