
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { User, Mail, LinkIcon } from "lucide-react";
import { Separator } from "@/components/ui/separator";

interface BillingFormProps {
  socialLink: string;
  setSocialLink: (value: string) => void;
  formErrors: Record<string, string>;
}

export const BillingForm = ({ socialLink, setSocialLink, formErrors }: BillingFormProps) => {
  return (
    <>
      <div className="space-y-2">
        <Label htmlFor="socialLink">Social Media Link <span className="text-red-500">*</span></Label>
        <div className="relative">
          <Input 
            id="socialLink"
            name="socialLink"
            placeholder="https://instagram.com/yourusername" 
            required 
            className={`pl-10 ${formErrors.socialLink ? 'border-red-500' : ''}`}
            value={socialLink}
            onChange={(e) => setSocialLink(e.target.value)}
          />
          <LinkIcon className="absolute left-3 top-2.5 h-5 w-5 text-muted-foreground/70" />
        </div>
        {formErrors.socialLink && (
          <p className="text-red-500 text-sm mt-1">{formErrors.socialLink}</p>
        )}
        <p className="text-sm text-muted-foreground">
          Enter the link to your social media profile or post where you want the service applied
        </p>
      </div>
      
      <Separator />
      
      <h3 className="font-semibold mb-4">Billing Information</h3>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="firstName">First Name</Label>
          <div className="relative">
            <Input id="firstName" name="firstName" placeholder="John" className="pl-10" />
            <User className="absolute left-3 top-2.5 h-5 w-5 text-muted-foreground/70" />
          </div>
        </div>
        <div className="space-y-2">
          <Label htmlFor="lastName">Last Name</Label>
          <div className="relative">
            <Input id="lastName" name="lastName" placeholder="Doe" className="pl-10" />
            <User className="absolute left-3 top-2.5 h-5 w-5 text-muted-foreground/70" />
          </div>
        </div>
      </div>
      
      <div className="space-y-2">
        <Label htmlFor="email">Email</Label>
        <div className="relative">
          <Input id="email" name="email" type="email" placeholder="your@email.com" className="pl-10" />
          <Mail className="absolute left-3 top-2.5 h-5 w-5 text-muted-foreground/70" />
        </div>
      </div>
    </>
  );
};
