
import { PricingCard } from "@/components/PricingCard";

// This is a wrapper component to ensure all package cards have the necessary props
interface ServiceCardProps {
  title: string;
  price: string;
  features: string[];
  icon: React.ReactNode;
  popular?: boolean;
  service: string;
  category: string;
}

export function ServiceCard(props: ServiceCardProps) {
  return <PricingCard {...props} />;
}
