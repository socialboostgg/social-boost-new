import { 
  Instagram, 
  Youtube, 
  Facebook, 
  Twitter, 
  Twitch,
  Music,
  Send,
  Bookmark,
  AudioWaveform
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Link } from "react-router-dom";

// Define all services including the existing and new ones
const allServices = [
  {
    title: "Instagram",
    icon: <Instagram className="w-12 h-12" stroke="#D946EF" strokeWidth={3} />,
    description: "Grow your Instagram followers, likes, and views",
    link: "/instagram-packages",
    color: "bg-gradient-to-br from-primary/80 to-primary"
  },
  {
    title: "TikTok",
    icon: <svg className="w-12 h-12" viewBox="0 0 24 24" fill="none" stroke="#D946EF" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
      <path d="M9 12a4 4 0 1 0 4 4V4a5 5 0 0 0 5 5" />
    </svg>,
    description: "Boost your TikTok presence with followers, likes and views",
    link: "/tiktok-packages",
    color: "bg-gradient-to-br from-primary/80 to-primary"
  },
  {
    title: "YouTube",
    icon: <Youtube className="w-12 h-12" stroke="#D946EF" strokeWidth={3} />,
    description: "Increase your subscribers, views, and engagement",
    link: "/youtube-packages",
    color: "bg-gradient-to-br from-primary/80 to-primary"
  },
  {
    title: "X (Twitter)",
    icon: <Twitter className="w-12 h-12" stroke="#D946EF" strokeWidth={3} />,
    description: "Grow your Twitter following and engagement",
    link: "/twitter-packages",
    color: "bg-gradient-to-br from-primary/80 to-primary"
  },
  {
    title: "Facebook",
    icon: <Facebook className="w-12 h-12" stroke="#D946EF" strokeWidth={3} />,
    description: "Increase your Facebook page likes and followers",
    link: "/facebook-packages",
    color: "bg-gradient-to-br from-primary/80 to-primary"
  },
  {
    title: "Telegram",
    icon: <Send className="w-12 h-12" stroke="#D946EF" strokeWidth={3} />,
    description: "Boost your Telegram channel members and views",
    link: "/telegram-packages",
    color: "bg-gradient-to-br from-primary/80 to-primary"
  },
  {
    title: "Twitch",
    icon: <Twitch className="w-12 h-12" stroke="#D946EF" strokeWidth={3} />,
    description: "Grow your Twitch followers and live viewer count",
    link: "/twitch-packages",
    color: "bg-gradient-to-br from-primary/80 to-primary"
  },
  {
    title: "Spotify",
    icon: <Music className="w-12 h-12" stroke="#D946EF" strokeWidth={3} />,
    description: "Increase your Spotify plays, followers and monthly listeners",
    link: "/spotify-packages",
    color: "bg-gradient-to-br from-primary/80 to-primary"
  },
  {
    title: "SoundCloud",
    icon: <AudioWaveform className="w-12 h-12" stroke="#D946EF" strokeWidth={3} />,
    description: "Boost your SoundCloud plays, likes and followers",
    link: "/soundcloud-packages",
    color: "bg-gradient-to-br from-primary/80 to-primary"
  },
  {
    title: "Pinterest",
    icon: <Bookmark className="w-12 h-12" stroke="#D946EF" strokeWidth={3} />,
    description: "Increase your Pinterest followers and pin engagement",
    link: "/pinterest-packages",
    color: "bg-gradient-to-br from-primary/80 to-primary"
  },
];

export const AllServicesList = () => {
  return (
    <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8 mb-16">
      {allServices.map((service, index) => (
        <Card
          key={index}
          className="animate-fade-up overflow-hidden"
          style={{ animationDelay: `${0.1 * (index + 1)}s` }}
        >
          <div className={`${service.color} p-6 flex items-center justify-center`}>
            <div className="text-4xl">
              {service.icon}
            </div>
          </div>
          <div className="p-6">
            <h3 className="text-xl font-semibold mb-2">{service.title}</h3>
            <p className="text-muted-foreground mb-6">{service.description}</p>
            <Button 
              className="w-full"
              variant={service.link !== "#" ? "default" : "outline"}
              asChild
            >
              <Link to={service.link}>
                {service.link !== "#" ? "View Packages" : "Coming Soon"}
              </Link>
            </Button>
          </div>
        </Card>
      ))}
    </div>
  );
};
