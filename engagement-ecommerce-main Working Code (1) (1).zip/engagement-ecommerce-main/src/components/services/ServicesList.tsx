
import { Instagram, Youtube, ShoppingCart, Facebook, Send, Twitter, Twitch, Music, Bookmark, AudioWaveform } from "lucide-react";
import { 
  DropdownMenuItem, 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuTrigger
} from "@/components/ui/dropdown-menu";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { Badge } from "@/components/ui/badge";

export const services = [
  {
    title: "Instagram",
    icon: <Instagram className="w-8 h-8" />,
    link: "/instagram-packages",
    badge: { text: "20% OFF", variant: "default" }
  },
  {
    title: "TikTok",
    icon: <svg className="w-8 h-8" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M9 12a4 4 0 1 0 4 4V4a5 5 0 0 0 5 5" />
    </svg>,
    link: "/tiktok-packages",
    badge: { text: "HOT!", variant: "primary" }
  },
  {
    title: "YouTube",
    icon: <Youtube className="w-8 h-8" />,
    link: "/youtube-packages"
  },
  {
    title: "X (Twitter)",
    icon: <Twitter className="w-8 h-8" />,
    link: "/twitter-packages",
    badge: { text: "25% OFF", variant: "default" }
  },
  {
    title: "Facebook",
    icon: <Facebook className="w-8 h-8" />,
    link: "/facebook-packages"
  },
  {
    title: "Telegram",
    icon: <Send className="w-8 h-8" />,
    link: "/telegram-packages",
    badge: { text: "NEW", variant: "secondary" }
  },
  {
    title: "Twitch",
    icon: <Twitch className="w-8 h-8" />,
    link: "/twitch-packages"
  },
  {
    title: "Spotify",
    icon: <Music className="w-8 h-8" />,
    link: "/spotify-packages",
    badge: { text: "HOT!", variant: "primary" }
  },
  {
    title: "SoundCloud",
    icon: <AudioWaveform className="w-8 h-8" />,
    link: "/soundcloud-packages"
  },
  {
    title: "Pinterest",
    icon: <Bookmark className="w-8 h-8" />,
    link: "/pinterest-packages"
  },
  {
    title: "View All Services",
    icon: <ShoppingCart className="w-8 h-8" />,
    link: "/all-services"
  },
];

const mainServices = [
  "Instagram",
  "TikTok",
  "YouTube",
  "Facebook",
  "Telegram",
  "View All Services"
];

type ServicesListProps = {
  layout: "dropdown" | "grid";
}

export const ServicesList = ({ layout }: ServicesListProps) => {
  const dropdownServices = [...services];
  const viewAllIndex = dropdownServices.findIndex(service => service.title === "View All Services");
  if (viewAllIndex !== -1) {
    const viewAll = dropdownServices.splice(viewAllIndex, 1)[0];
    dropdownServices.unshift(viewAll);
  }

  if (layout === "dropdown") {
    return (
      <>
        {dropdownServices.map((service, index) => (
          <DropdownMenuItem key={index} className="cursor-pointer" asChild>
            <Link to={service.link}>
              <span className="mr-2">{service.icon}</span>
              {service.title}
              {service.badge && (
                <Badge 
                  variant={service.badge.variant as any} 
                  className="ml-2 px-1 py-0 text-xs"
                >
                  {service.badge.text}
                </Badge>
              )}
            </Link>
          </DropdownMenuItem>
        ))}
      </>
    );
  }

  const filteredServices = services.filter(service => 
    mainServices.includes(service.title)
  );

  return (
    <div className="grid md:grid-cols-3 gap-8">
      {filteredServices.map((service, index) => (
        <div
          key={index}
          className="animate-fade-up relative"
          style={{ animationDelay: `${0.1 * (index + 1)}s` }}
        >
          <div className="bg-card rounded-lg p-6 shadow-sm hover:shadow-md transition-shadow h-full flex flex-col items-center border border-border/30">
            {service.badge && (
              <div className="absolute -top-3 -right-3 z-10">
                <Badge 
                  variant={service.badge.variant as any} 
                  className="px-3 py-1 text-xs font-semibold animate-pulse"
                >
                  {service.badge.text}
                </Badge>
              </div>
            )}
            <div className="flex items-center justify-center mb-4 text-4xl text-primary">
              {service.icon}
            </div>
            <h3 className="text-xl font-semibold text-center mb-6">{service.title}</h3>
            <Button 
              className="mt-auto w-full"
              variant="default"
              asChild
            >
              <Link to={service.link}>View Services</Link>
            </Button>
          </div>
        </div>
      ))}
    </div>
  );
};
