
import React from 'react';
import { CardElement } from '@stripe/react-stripe-js';
import { Separator } from "@/components/ui/separator";
import { CreditCard } from "lucide-react";

const CARD_ELEMENT_OPTIONS = {
  style: {
    base: {
      color: '#32325d',
      fontFamily: '"Helvetica Neue", Helvetica, sans-serif',
      fontSmoothing: 'antialiased',
      fontSize: '16px',
      '::placeholder': {
        color: '#aab7c4'
      }
      // Removed the invalid padding property
    },
    invalid: {
      color: '#fa755a',
      iconColor: '#fa755a'
    }
  }
};

interface StripeCardElementProps {
  onChange?: (event: any) => void;
}

export const StripeCardElement: React.FC<StripeCardElementProps> = ({ onChange }) => {
  return (
    <div className="space-y-4">
      <div>
        <h3 className="font-semibold mb-4 flex items-center">
          <CreditCard className="mr-2 h-5 w-5" />
          Payment Details
        </h3>
      </div>
      <div className="p-4 border rounded-md">
        <CardElement options={CARD_ELEMENT_OPTIONS} onChange={onChange} />
      </div>
      <div className="text-xs text-muted-foreground">
        <p>Your payment is secure and encrypted.</p>
      </div>
    </div>
  );
};
