
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { PricingCard } from "@/components/PricingCard";
import { Instagram } from "lucide-react";

interface FollowersPackagesDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function FollowersPackagesDialog({ open, onOpenChange }: FollowersPackagesDialogProps) {
  const calculatePrice = (followers: number) => {
    const basePrice = (followers / 1000) * 9.99;
    const discount = followers > 1000 ? 0.2 : 0; // 20% discount for packages above 1000
    const finalPrice = basePrice * (1 - discount);
    return finalPrice.toFixed(2);
  };

  const packages = [
    { followers: 1000, price: "$9.99" },
    { followers: 5000, price: `$${calculatePrice(5000)}` },
    { followers: 10000, price: `$${calculatePrice(10000)}` },
    { followers: 25000, price: `$${calculatePrice(25000)}` },
    { followers: 50000, price: `$${calculatePrice(50000)}` },
    { followers: 100000, price: `$${calculatePrice(100000)}` },
  ];

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[90vh] overflow-y-auto w-[95vw] max-w-[800px] p-4 sm:p-6 bg-card border border-border/30">
        <DialogHeader>
          <DialogTitle className="text-xl sm:text-2xl font-bold text-center mb-4">Choose Your Instagram Followers Package</DialogTitle>
        </DialogHeader>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 sm:gap-4">
          {packages.map((pkg, index) => (
            <PricingCard
              key={index}
              title={`${pkg.followers.toLocaleString()} Followers`}
              price={pkg.price}
              icon={<Instagram className="w-6 h-6 sm:w-8 sm:h-8" />}
              features={[
                "Real followers",
                "Gradual delivery",
                "24/7 Support",
                "No password required",
                "Safe & Secure"
              ]}
              service="Instagram"
              category="Followers"
            />
          ))}
        </div>
      </DialogContent>
    </Dialog>
  );
}
