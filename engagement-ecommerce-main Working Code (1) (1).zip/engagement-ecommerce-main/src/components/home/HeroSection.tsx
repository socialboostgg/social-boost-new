
import { Rocket } from "lucide-react";
import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";
import { PurchaseNotification } from "./PurchaseNotification";

type HeroSectionProps = {
  scrollToServices: () => void;
  scrollToFAQ: () => void;
}

export const HeroSection = ({ scrollToServices, scrollToFAQ }: HeroSectionProps) => {
  return (
    <section className="py-12 md:py-20 px-4 bg-background relative overflow-hidden w-full">
      <div className="rocket-bg right-[-5%] top-[15%] rocket-animation">
        <Rocket size={280} className="text-primary/20" />
      </div>
      <div className="rocket-bg left-[-2%] bottom-[10%] rocket-animation" style={{ animationDelay: "2s" }}>
        <Rocket size={180} className="text-primary/15" />
      </div>
      
      <div className="container mx-auto relative z-10">
        <div className="grid md:grid-cols-2 gap-8 items-center">
          <div className="text-left">
            <span className="inline-block px-3 py-1 text-sm font-semibold bg-accent text-accent-foreground rounded-full mb-6">
              Premium Social Media Services
            </span>
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6">
              Boost Your Social Media
              <span className="text-primary"> Presence</span>
            </h1>
            <p className="text-lg text-muted-foreground mb-8 max-w-md">
              Buy quality followers, likes, views and engagement for Instagram, TikTok, YouTube, and other platforms
            </p>
            <div className="flex flex-wrap gap-4 relative pb-16">
              <Button 
                onClick={scrollToServices} 
                size="lg" 
                className="text-md px-6"
              >
                Get Started
              </Button>
              <Button 
                onClick={scrollToFAQ}
                variant="outline" 
                size="lg" 
                className="text-md px-6"
              >
                Learn More
              </Button>
              
              {/* Purchase notification component */}
              <PurchaseNotification />
            </div>
          </div>
          <div className="flex justify-center">
            <div className="relative w-full max-w-md h-auto">
              <div className="absolute w-full h-full bg-primary/20 blur-3xl rounded-full transform -translate-y-1/2"></div>
              <motion.div 
                initial={{ scale: 0.8, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                transition={{ 
                  duration: 0.8,
                  ease: "easeOut"
                }}
                className="relative z-10 w-full h-auto drop-shadow-xl flex justify-center items-center"
              >
                <motion.div
                  animate={{ 
                    y: [0, -15, 0],
                    rotate: [0, 3, 0]
                  }}
                  transition={{
                    duration: 4,
                    ease: "easeInOut",
                    repeat: Infinity,
                  }}
                >
                  <Rocket size={420} className="text-primary" strokeWidth={1.5} />
                </motion.div>
              </motion.div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
