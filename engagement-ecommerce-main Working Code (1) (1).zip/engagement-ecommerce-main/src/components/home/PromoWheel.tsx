
import { useState, useRef, useEffect } from "react";
import { useLocalStorage } from "@/hooks/use-local-storage";
import { Trophy, Gift, Sparkles, Ticket, Percent } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { motion } from "framer-motion";

// Define the prize structure
type Prize = {
  id: number;
  name: string;
  description: string;
  probability: number;
  color: string;
  icon: React.ReactNode;
};

const prizes: Prize[] = [
  { 
    id: 1, 
    name: "500 Free Followers", 
    description: "Get 500 followers on your account for free", 
    probability: 5,
    color: "#8B5CF6", 
    icon: <Trophy className="h-6 w-6" /> 
  },
  { 
    id: 2, 
    name: "50% Off Any Package", 
    description: "Get 50% off on any package", 
    probability: 10, 
    color: "#9b87f5",
    icon: <Percent className="h-6 w-6" />
  },
  { 
    id: 3, 
    name: "200 Free Likes", 
    description: "Get 200 likes on your post for free", 
    probability: 15, 
    color: "#7E69AB",
    icon: <Sparkles className="h-6 w-6" />
  },
  { 
    id: 4, 
    name: "20% Off Coupon", 
    description: "Get 20% off on your next purchase", 
    probability: 20, 
    color: "#6E59A5",
    icon: <Ticket className="h-6 w-6" />
  },
  { 
    id: 5, 
    name: "100 Free Followers", 
    description: "Get 100 followers on your account for free", 
    probability: 15, 
    color: "#8B5CF6",
    icon: <Trophy className="h-6 w-6" />
  },
  { 
    id: 6, 
    name: "10% Off Next Purchase", 
    description: "Get 10% off on your next purchase", 
    probability: 25, 
    color: "#9b87f5",
    icon: <Percent className="h-6 w-6" />
  },
  { 
    id: 7, 
    name: "50 Free Likes", 
    description: "Get 50 likes on your post for free", 
    probability: 10, 
    color: "#7E69AB",
    icon: <Sparkles className="h-6 w-6" />
  }
];

export const PromoWheel = () => {
  const [showPromo, setShowPromo] = useLocalStorage("showPromoWheel", true);
  const [isSpinning, setIsSpinning] = useState(false);
  const [rotation, setRotation] = useState(0);
  const [prizeWon, setPrizeWon] = useState<Prize | null>(null);
  const [showPrizeDialog, setShowPrizeDialog] = useState(false);
  const wheelRef = useRef<HTMLDivElement>(null);

  // Calculate total segments based on number of prizes
  const segmentAngle = 360 / prizes.length;

  // Spin the wheel with weighted probabilities
  const spinWheel = () => {
    if (isSpinning) return;
    
    setIsSpinning(true);
    
    // Create an array where each prize appears according to its probability
    const weightedPrizes: Prize[] = [];
    prizes.forEach(prize => {
      // Add the prize to the array a number of times equal to its probability
      for (let i = 0; i < prize.probability; i++) {
        weightedPrizes.push(prize);
      }
    });
    
    // Select a random prize
    const randomIndex = Math.floor(Math.random() * weightedPrizes.length);
    const selectedPrize = weightedPrizes[randomIndex];
    
    // Find the index of the selected prize in the original array
    const prizeIndex = prizes.findIndex(p => p.id === selectedPrize.id);
    
    // Calculate the rotation needed to land on the selected prize
    const targetRotation = 360 * 5 + (360 - (prizeIndex * segmentAngle) - segmentAngle / 2);
    
    // Set the final rotation
    setRotation(targetRotation);
    
    // After the spinning animation, show the prize dialog
    setTimeout(() => {
      setPrizeWon(selectedPrize);
      setIsSpinning(false);
      setShowPrizeDialog(true);
    }, 5000); // 5 seconds duration for the spin
  };

  // When a user claims their prize
  const claimPrize = () => {
    if (!prizeWon) return;
    
    // Store the prize in localStorage
    localStorage.setItem("claimedPrize", JSON.stringify(prizeWon));
    
    // Hide the promo wheel for the rest of the session
    setShowPromo(false);
    setShowPrizeDialog(false);
    
    // Show toast notification
    toast.success("Prize claimed successfully! Check your account or use your coupon at checkout.");
  };

  // Close button handler
  const handleClose = () => {
    setShowPromo(false);
  };

  return (
    <>
      <Dialog open={showPromo && !showPrizeDialog} onOpenChange={setShowPromo}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle className="text-center text-2xl font-bold">
              Spin to Win!
            </DialogTitle>
          </DialogHeader>
          
          <div className="flex flex-col items-center justify-center py-6">
            <p className="text-center text-muted-foreground mb-6">
              Try your luck and win amazing prizes - free followers, likes, or discounts!
            </p>

            <div className="relative mb-6" style={{ width: "300px", height: "300px" }}>
              {/* Pointer */}
              <div className="absolute top-0 left-1/2 transform -translate-x-1/2 -translate-y-4 z-10">
                <div className="w-0 h-0 border-l-[10px] border-l-transparent border-r-[10px] border-r-transparent border-b-[15px] border-b-primary" />
              </div>
              
              {/* Wheel */}
              <div 
                ref={wheelRef}
                className="w-full h-full rounded-full overflow-hidden border-4 border-primary shadow-[0_0_15px_rgba(139,92,246,0.5)] relative transition-transform duration-5000 ease-out"
                style={{ 
                  transform: `rotate(${rotation}deg)`,
                  transition: isSpinning ? "transform 5s cubic-bezier(0.1, 0.85, 0.25, 1)" : "none"
                }}
              >
                {prizes.map((prize, index) => {
                  const startAngle = index * segmentAngle;
                  return (
                    <div 
                      key={prize.id}
                      className="absolute top-0 left-0 w-full h-full flex items-center justify-center"
                      style={{
                        clipPath: `polygon(50% 50%, ${50 + 50 * Math.cos((startAngle - 90) * Math.PI / 180)}% ${50 + 50 * Math.sin((startAngle - 90) * Math.PI / 180)}%, ${50 + 50 * Math.cos((startAngle + segmentAngle - 90) * Math.PI / 180)}% ${50 + 50 * Math.sin((startAngle + segmentAngle - 90) * Math.PI / 180)}%)`,
                        backgroundColor: prize.color,
                        transform: `rotate(${startAngle}deg)`,
                      }}
                    >
                      <div 
                        className="absolute w-full text-white font-bold text-xs text-center flex flex-col items-center"
                        style={{
                          top: '25%',
                          transform: 'translateY(-50%) rotate(90deg)',
                          textShadow: '0px 0px 4px rgba(0,0,0,0.6), 0px 0px 2px rgba(0,0,0,0.8)'
                        }}
                      >
                        {prize.icon}
                        <span className="mt-1 px-1 py-0.5 rounded bg-black/40 backdrop-blur-sm">
                          {prize.name}
                        </span>
                      </div>
                    </div>
                  );
                })}
                
                {/* Central circle */}
                <div className="absolute top-1/2 left-1/2 w-12 h-12 bg-primary rounded-full -translate-x-1/2 -translate-y-1/2 flex items-center justify-center border-2 border-white/20 shadow-lg z-10">
                  <span className="text-white text-xs font-bold">SPIN</span>
                </div>
              </div>
            </div>

            <div className="flex flex-col gap-4 w-full">
              <Button 
                onClick={spinWheel} 
                disabled={isSpinning}
                size="lg"
                className="w-full"
              >
                {isSpinning ? "Spinning..." : "Spin the Wheel"}
              </Button>
              <Button
                variant="outline"
                onClick={handleClose}
                className="w-full"
              >
                Maybe Later
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Prize won dialog */}
      <Dialog open={showPrizeDialog} onOpenChange={setShowPrizeDialog}>
        <DialogContent className="sm:max-w-[400px]">
          <DialogHeader>
            <DialogTitle className="text-center text-2xl font-bold">
              Congratulations!
            </DialogTitle>
          </DialogHeader>
          
          <div className="flex flex-col items-center justify-center py-6">
            <motion.div
              initial={{ scale: 0.5, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ duration: 0.5 }}
              className="mb-4"
            >
              <div className="bg-primary/20 p-6 rounded-full">
                <Gift className="h-16 w-16 text-primary" />
              </div>
            </motion.div>
            
            <h3 className="text-xl font-bold text-center mb-2">
              You won: {prizeWon?.name}!
            </h3>
            <p className="text-center text-muted-foreground mb-6">
              {prizeWon?.description}
            </p>
            
            <div className="flex flex-col gap-4 w-full">
              <Button 
                onClick={claimPrize} 
                size="lg"
                className="w-full"
              >
                Claim Your Prize
              </Button>
              <Button
                variant="outline"
                onClick={() => setShowPrizeDialog(false)}
                className="w-full"
              >
                Close
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
};
