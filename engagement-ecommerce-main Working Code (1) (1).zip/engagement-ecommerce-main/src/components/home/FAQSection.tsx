
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { forwardRef } from "react";

export const FAQSection = forwardRef<HTMLElement>((props, ref) => {
  const faqs = [
    {
      question: "How quickly will I see results?",
      answer: "You'll start to see results within 24-48 hours after placing your order. Larger packages may take a bit longer to complete, but you'll see consistent progress throughout."
    },
    {
      question: "Is my account information safe?",
      answer: "Absolutely. We only require your public username, never your password or private information. Your account security is our top priority."
    },
    {
      question: "What payment methods do you accept?",
      answer: "We accept all major credit cards, PayPal, and cryptocurrency payments for your convenience and security."
    },
    {
      question: "Do you offer refunds?",
      answer: "Yes, we offer a money-back guarantee if we cannot deliver your order within the promised timeframe. Please check our refund policy for details."
    }
  ];

  return (
    <section ref={ref} className="py-16 md:py-20 px-4 bg-background w-full">
      <div className="container mx-auto">
        <div className="mb-12 text-center">
          <span className="inline-block px-3 py-1 text-sm font-semibold bg-primary/10 text-primary rounded-full mb-4">
            FAQ
          </span>
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Frequently Asked Questions</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Find answers to common questions about our services
          </p>
        </div>

        <div className="max-w-3xl mx-auto">
          <Accordion type="single" collapsible className="w-full">
            {faqs.map((faq, index) => (
              <AccordionItem key={index} value={`item-${index}`}>
                <AccordionTrigger className="text-left font-medium">
                  {faq.question}
                </AccordionTrigger>
                <AccordionContent className="text-muted-foreground">
                  {faq.answer}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </div>
      </div>
    </section>
  );
});

FAQSection.displayName = "FAQSection";
