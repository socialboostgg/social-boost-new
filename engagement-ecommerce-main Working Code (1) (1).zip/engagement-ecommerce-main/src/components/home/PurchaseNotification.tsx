
import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ShoppingBag, Clock } from "lucide-react";
import { Badge } from "@/components/ui/badge";

type TimeFrame = {
  value: number;
  unit: string;
};

type Purchase = {
  service: string;
  amount: number;
  timeAgo: TimeFrame;
};

export const PurchaseNotification = () => {
  const [currentPurchase, setCurrentPurchase] = useState<Purchase | null>(null);
  const [showNotification, setShowNotification] = useState(true);
  
  const generateRandomTimeFrame = (): TimeFrame => {
    const timeFrames: TimeFrame[] = [
      { value: 1, unit: 'minute' },
      { value: 5, unit: 'minute' },
      { value: 15, unit: 'minute' },
      { value: 30, unit: 'minute' },
      { value: 1, unit: 'hour' },
      { value: 2, unit: 'hour' },
      { value: 5, unit: 'hour' },
      { value: 1, unit: 'day' },
      { value: 2, unit: 'day' },
      { value: 3, unit: 'day' },
      { value: 1, unit: 'week' },
      { value: 2, unit: 'week' },
      { value: 1, unit: 'month' },
    ];
    
    return timeFrames[Math.floor(Math.random() * timeFrames.length)];
  };
  
  const generateRandomPurchase = (): Purchase => {
    const services = ["Followers", "Likes", "Views", "Comments", "Shares"];
    const amounts = [100, 250, 500, 1000, 2500, 5000, 10000];
    
    return {
      service: services[Math.floor(Math.random() * services.length)],
      amount: amounts[Math.floor(Math.random() * amounts.length)],
      timeAgo: generateRandomTimeFrame(),
    };
  };
  
  useEffect(() => {
    // Initial purchase
    setCurrentPurchase(generateRandomPurchase());
    
    // Rotate purchases every 3 seconds (keep the slightly faster speed)
    const interval = setInterval(() => {
      setCurrentPurchase(null);
      
      // Small delay before showing new purchase for better animation
      setTimeout(() => {
        setCurrentPurchase(generateRandomPurchase());
      }, 300);
    }, 3000);
    
    return () => clearInterval(interval);
  }, []);
  
  if (!currentPurchase || !showNotification) return null;
  
  const getTimeDisplay = (timeFrame: TimeFrame) => {
    const { value, unit } = timeFrame;
    return `${value} ${value === 1 ? unit : unit + 's'} ago`;
  };
  
  return (
    <div className="absolute left-0 -bottom-10 w-full max-w-[300px]">
      <AnimatePresence>
        <motion.div
          key={`${currentPurchase.service}-${currentPurchase.amount}-${currentPurchase.timeAgo.value}-${currentPurchase.timeAgo.unit}`}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -20 }}
          transition={{ duration: 0.3 }}
          className="bg-black/80 backdrop-blur-sm px-4 py-2 rounded-lg border border-primary/30 shadow-lg flex items-center gap-3 w-full h-[74px]"
        >
          <div className="rounded-full bg-primary/20 p-2 flex-shrink-0">
            <ShoppingBag size={16} className="text-primary" />
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-sm text-white font-medium truncate">
              <Badge variant="primary" className="mr-1">{currentPurchase.service} Delivered</Badge>
              {currentPurchase.amount} {currentPurchase.service}
            </p>
            <p className="text-xs text-gray-300 flex items-center mt-1">
              <Clock size={12} className="mr-1" />
              {getTimeDisplay(currentPurchase.timeAgo)}
            </p>
          </div>
        </motion.div>
      </AnimatePresence>
    </div>
  );
};
