
import { useState } from "react";
import { Star, ChevronLeft, ChevronRight, User } from "lucide-react";
import { Button } from "@/components/ui/button";

export const TestimonialsSection = () => {
  const testimonials = [
    {
      name: "Sarah Johnson",
      title: "Influencer",
      rating: 5,
      text: "My Instagram following grew significantly after using their services. The delivery was fast and the followers are actually engaging with my content!"
    },
    {
      name: "Michael Chen",
      title: "Content Creator",
      rating: 5,
      text: "I was skeptical at first, but the results speak for themselves. My TikTok videos are getting more views and my follower count has increased substantially."
    },
    {
      name: "Emma Wilson",
      title: "YouTube Creator",
      rating: 5,
      text: "The subscriber boost to my YouTube channel helped me reach the monetization threshold. The support team was incredibly helpful throughout the process."
    },
    {
      name: "David Rodriguez",
      title: "Brand Manager",
      rating: 4,
      text: "We needed to quickly grow our social presence for a product launch, and these services delivered exactly what we needed when we needed it."
    },
  ];

  const [currentIndex, setCurrentIndex] = useState(0);

  const nextTestimonial = () => {
    setCurrentIndex((prevIndex) => (prevIndex + 1) % testimonials.length);
  };

  const prevTestimonial = () => {
    setCurrentIndex((prevIndex) => (prevIndex - 1 + testimonials.length) % testimonials.length);
  };

  const visibleTestimonials = testimonials.slice(currentIndex, currentIndex + (testimonials.length >= 3 ? 3 : testimonials.length));
  if (visibleTestimonials.length < 3 && testimonials.length >= 3) {
    visibleTestimonials.push(...testimonials.slice(0, 3 - visibleTestimonials.length));
  }

  return (
    <section className="py-16 md:py-20 px-4 bg-accent w-full">
      <div className="container mx-auto">
        <div className="mb-12 text-center">
          <span className="inline-block px-3 py-1 text-sm font-semibold bg-primary/10 text-primary rounded-full mb-4">
            Testimonials
          </span>
          <h2 className="text-3xl md:text-4xl font-bold mb-4">What Our Customers Say</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Hear from our satisfied customers about their experience with our services
          </p>
        </div>

        <div className="relative">
          <div className="grid md:grid-cols-3 gap-6">
            {visibleTestimonials.map((testimonial, index) => (
              <div
                key={index}
                className="bg-card rounded-xl p-6 border border-border/30 shadow-sm"
              >
                <div className="flex items-center gap-2 mb-4">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      className={`h-4 w-4 ${i < testimonial.rating ? 'text-yellow-500 fill-yellow-500' : 'text-gray-300'}`}
                    />
                  ))}
                </div>
                <p className="text-muted-foreground mb-6">"{testimonial.text}"</p>
                <div className="flex items-center">
                  <div className="w-10 h-10 rounded-full bg-gray-200 flex items-center justify-center mr-3">
                    <User className="h-6 w-6 text-gray-600" />
                  </div>
                  <div>
                    <p className="font-semibold">{testimonial.name}</p>
                    <p className="text-sm text-muted-foreground">{testimonial.title}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="mt-10 flex justify-center gap-4">
            <Button 
              onClick={prevTestimonial} 
              variant="outline" 
              size="icon" 
              className="rounded-full"
            >
              <ChevronLeft className="h-5 w-5" />
            </Button>
            <Button 
              onClick={nextTestimonial} 
              variant="outline" 
              size="icon" 
              className="rounded-full"
            >
              <ChevronRight className="h-5 w-5" />
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
};
