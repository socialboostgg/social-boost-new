
import { ServicesList } from "@/components/services/ServicesList";
import { ForwardedRef, forwardRef } from "react";
import { Badge } from "@/components/ui/badge";

type ServicesSectionProps = {}

export const ServicesSection = forwardRef<HTMLElement, ServicesSectionProps>((props, ref) => {
  return (
    <>
      <div className="gradient-top-to-middle h-32 w-full"></div>

      <section ref={ref} className="py-16 md:py-20 px-4 bg-accent w-full">
        <div className="container mx-auto">
          <div className="mb-12 text-center">
            <span className="inline-block px-3 py-1 text-sm font-semibold bg-primary/10 text-primary rounded-full mb-4">
              Our Services
            </span>
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Grow Your Social Media</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Choose from our range of high-quality services to enhance your social media presence
            </p>
            <Badge variant="primary" className="mt-4">Limited Time Offers!</Badge>
          </div>
          
          <ServicesList layout="grid" />
        </div>
      </section>
    </>
  );
});

ServicesSection.displayName = "ServicesSection";
