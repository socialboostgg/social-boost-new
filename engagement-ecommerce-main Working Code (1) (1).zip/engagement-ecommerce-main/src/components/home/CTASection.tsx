
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";

export const CTASection = () => {
  return (
    <section className="py-16 md:py-20 px-4 bg-accent w-full">
      <div className="container mx-auto">
        <div className="bg-primary/10 rounded-2xl p-8 md:p-12 text-center max-w-4xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">Ready to Boost Your Social Media?</h2>
          <p className="text-lg text-muted-foreground mb-8 max-w-2xl mx-auto">
            Get started today and watch your social media presence grow with our premium services
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <Button size="lg" className="px-8" asChild>
              <Link to="/instagram-packages">Instagram Services</Link>
            </Button>
            <Button size="lg" variant="outline" className="px-8" asChild>
              <Link to="/tiktok-packages">TikTok Services</Link>
            </Button>
            <Button size="lg" variant="outline" className="px-8" asChild>
              <Link to="/youtube-packages">YouTube Services</Link>
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
};
