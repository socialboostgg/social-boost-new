
import { Gift, ChevronRight, Instagram, Twitter } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { TikTok } from "@/components/icons/TikTok";

export const FreeFollowersPromo = () => {
  return (
    <div className="bg-gradient-to-r from-primary/90 to-primary px-4 py-3 text-primary-foreground">
      <div className="container mx-auto flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center">
          <Gift className="h-5 w-5 mr-2 animate-pulse" />
          <span className="font-medium">
            <span className="font-bold">NEW USERS:</span> Sign up and get 50 FREE followers for TikTok, Instagram, or Twitter!
          </span>
        </div>
        <Button 
          variant="secondary" 
          size="sm" 
          className="whitespace-nowrap"
          asChild
        >
          <Link to="/free-followers" className="flex items-center">
            Claim Now
            <ChevronRight className="h-4 w-4 ml-1" />
          </Link>
        </Button>
      </div>
    </div>
  );
};
