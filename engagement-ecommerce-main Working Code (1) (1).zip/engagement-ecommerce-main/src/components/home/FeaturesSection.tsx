
import { Shield, Zap, Users, Clock, Star, BadgeCheck, Sparkles } from "lucide-react";

export const FeaturesSection = () => {
  const features = [
    {
      icon: <Shield className="h-10 w-10" />,
      title: "Safe & Secure",
      description: "Your account safety is our top priority with secure payment methods",
    },
    {
      icon: <Zap className="h-10 w-10" />,
      title: "Fast Delivery",
      description: "Quick delivery times to boost your social presence without delay",
    },
    {
      icon: <Sparkles className="h-10 w-10" />,
      title: "Premium Quality",
      description: "All our services are provided with exceptional quality standards",
    },
    {
      icon: <Clock className="h-10 w-10" />,
      title: "24/7 Support",
      description: "Expert support team available around the clock",
    },
    {
      icon: <Star className="h-10 w-10" />,
      title: "High Quality",
      description: "Premium quality services that make a real difference",
    },
    {
      icon: <BadgeCheck className="h-10 w-10" />,
      title: "Guaranteed Results",
      description: "We guarantee satisfaction with our proven results",
    },
  ];

  return (
    <>
      <div className="gradient-middle-to-bottom h-32 w-full"></div>

      <section className="py-16 md:py-20 px-4 bg-background w-full">
        <div className="container mx-auto">
          <div className="mb-12 text-center">
            <span className="inline-block px-3 py-1 text-sm font-semibold bg-primary/10 text-primary rounded-full mb-4">
              Why Choose Us
            </span>
            <h2 className="text-3xl md:text-4xl font-bold mb-4">What Makes Us Different</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              We provide high-quality social media services with guaranteed results
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
            {features.map((feature, index) => (
              <div
                key={index}
                className="p-6 rounded-xl bg-card shadow-sm hover:shadow-md transition-all duration-300 border border-border/30 animate-fade-up"
                style={{ animationDelay: `${0.1 * (index + 1)}s` }}
              >
                <div className="text-primary mb-4">{feature.icon}</div>
                <h3 className="text-xl font-semibold mb-3">{feature.title}</h3>
                <p className="text-muted-foreground">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </>
  );
};
