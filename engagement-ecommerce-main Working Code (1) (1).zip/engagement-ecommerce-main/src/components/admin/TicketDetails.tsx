import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { TicketResponseForm } from './TicketResponseForm';
import { updateTicketStatus, type Ticket } from '@/utils/ticketService';
import { toast } from "sonner";

interface TicketResponse {
  id: string;
  message: string;
  created_at: string;
  admin_id: string;
}

interface TicketDetailsProps {
  ticket: Ticket;
  onUpdate: () => void;
}

export const TicketDetails = ({ ticket, onUpdate }: TicketDetailsProps) => {
  const handleStatusChange = async (status: string) => {
    try {
      const result = await updateTicketStatus(ticket.id, status);
      
      if (result.success) {
        toast.success(`Ticket status updated to ${status}`);
        onUpdate();
      } else {
        toast.error(`Failed to update status: ${result.error}`);
      }
    } catch (error) {
      console.error('Error updating ticket status:', error);
      toast.error('An unexpected error occurred');
    }
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    }).format(date);
  };

  const getStatusColor = (status: string) => {
    switch (status.toLowerCase()) {
      case 'open': return 'bg-blue-500';
      case 'in progress': return 'bg-yellow-500';
      case 'closed': return 'bg-green-500';
      default: return 'bg-gray-500';
    }
  };

  return (
    <Card className="shadow-md">
      <CardHeader>
        <div className="flex justify-between items-start">
          <div>
            <CardTitle>{ticket.subject}</CardTitle>
            <CardDescription>
              From: {ticket.name} ({ticket.email})
            </CardDescription>
            <p className="text-sm text-muted-foreground mt-1">
              Submitted on {formatDate(ticket.created_at)}
            </p>
          </div>
          <Badge className={getStatusColor(ticket.status)}>
            {ticket.status}
          </Badge>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-6">
          <div>
            <h3 className="text-sm font-medium mb-2">Message:</h3>
            <p className="whitespace-pre-line bg-muted p-3 rounded-md">{ticket.message}</p>
          </div>
          
          {ticket.ticket_responses && ticket.ticket_responses.length > 0 && (
            <div>
              <h3 className="text-sm font-medium mb-2">Responses:</h3>
              <div className="space-y-3">
                {ticket.ticket_responses.map((response) => (
                  <div key={response.id} className="bg-primary/10 p-3 rounded-md">
                    <p className="whitespace-pre-line">{response.message}</p>
                    <p className="text-xs text-muted-foreground mt-1">
                      Responded on {formatDate(response.created_at)}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          )}
          
          <div className="space-y-3">
            <h3 className="text-sm font-medium">Update Status:</h3>
            <div className="flex flex-wrap gap-2">
              <Button 
                size="sm" 
                variant={ticket.status === 'open' ? 'default' : 'outline'}
                onClick={() => handleStatusChange('open')}
              >
                Open
              </Button>
              <Button 
                size="sm" 
                variant={ticket.status === 'in progress' ? 'default' : 'outline'}
                onClick={() => handleStatusChange('in progress')}
              >
                In Progress
              </Button>
              <Button 
                size="sm" 
                variant={ticket.status === 'closed' ? 'default' : 'outline'}
                onClick={() => handleStatusChange('closed')}
              >
                Closed
              </Button>
            </div>
          </div>
          
          <div>
            <h3 className="text-sm font-medium mb-2">Add Response:</h3>
            <TicketResponseForm ticketId={ticket.id} onResponseAdded={onUpdate} />
          </div>
        </div>
      </CardContent>
    </Card>
  );
};
