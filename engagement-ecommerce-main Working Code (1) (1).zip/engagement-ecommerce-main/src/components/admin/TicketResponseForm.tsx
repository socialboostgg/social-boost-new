
import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import { addTicketResponse } from '@/utils/ticketService';

interface TicketResponseFormProps {
  ticketId: string;
  onResponseAdded: () => void;
}

export const TicketResponseForm = ({ ticketId, onResponseAdded }: TicketResponseFormProps) => {
  const [message, setMessage] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!message.trim()) {
      toast.error('Please enter a response message');
      return;
    }
    
    setIsSubmitting(true);
    
    try {
      const result = await addTicketResponse(ticketId, message);
      
      if (result.success) {
        toast.success('Response added successfully');
        setMessage('');
        onResponseAdded();
      } else {
        toast.error(`Failed to add response: ${result.error}`);
      }
    } catch (error) {
      console.error('Error adding response:', error);
      toast.error('An unexpected error occurred');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4 mt-4">
      <Textarea
        value={message}
        onChange={(e) => setMessage(e.target.value)}
        placeholder="Type your response here..."
        className="min-h-[100px]"
      />
      <Button type="submit" disabled={isSubmitting}>
        {isSubmitting ? 'Sending...' : 'Send Response'}
      </Button>
    </form>
  );
};
