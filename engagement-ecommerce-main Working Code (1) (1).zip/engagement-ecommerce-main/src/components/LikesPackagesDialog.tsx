
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { PricingCard } from "@/components/PricingCard";
import { Heart } from "lucide-react";
import { INSTAGRAM_LIKES_PRICES } from "@/utils/serviceController";

interface LikesPackagesDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function LikesPackagesDialog({ open, onOpenChange }: LikesPackagesDialogProps) {
  const packages = [
    { likes: 100, price: INSTAGRAM_LIKES_PRICES["100"] },
    { likes: 250, price: INSTAGRAM_LIKES_PRICES["250"] },
    { likes: 500, price: INSTAGRAM_LIKES_PRICES["500"] },
    { likes: 1000, price: INSTAGRAM_LIKES_PRICES["1,000"] },
    { likes: 2500, price: INSTAGRAM_LIKES_PRICES["2,500"] },
    { likes: 5000, price: INSTAGRAM_LIKES_PRICES["5,000"] },
    { likes: 10000, price: INSTAGRAM_LIKES_PRICES["10,000"] },
    { likes: 20000, price: INSTAGRAM_LIKES_PRICES["20,000"] },
    { likes: 50000, price: INSTAGRAM_LIKES_PRICES["50,000"] },
    { likes: 100000, price: INSTAGRAM_LIKES_PRICES["100,000"] },
    { likes: 200000, price: INSTAGRAM_LIKES_PRICES["200,000"] },
    { likes: 500000, price: INSTAGRAM_LIKES_PRICES["500,000"] },
  ];

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[90vh] overflow-y-auto w-[95vw] max-w-[800px] p-4 sm:p-6 bg-card border border-border/30">
        <DialogHeader>
          <DialogTitle className="text-xl sm:text-2xl font-bold text-center mb-4">Choose Your Instagram Likes Package</DialogTitle>
        </DialogHeader>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 sm:gap-4">
          {packages.map((pkg, index) => (
            <PricingCard
              key={index}
              title={`${pkg.likes.toLocaleString()} Likes`}
              price={pkg.price}
              icon={<Heart className="w-6 h-6 sm:w-8 sm:h-8" />}
              features={[
                "High quality likes",
                "Fast delivery",
                "24/7 Support",
                "No password required",
                "Safe & Secure"
              ]}
              service="Instagram"
              category="Likes"
              popular={pkg.likes === 5000}
            />
          ))}
        </div>
      </DialogContent>
    </Dialog>
  );
}
