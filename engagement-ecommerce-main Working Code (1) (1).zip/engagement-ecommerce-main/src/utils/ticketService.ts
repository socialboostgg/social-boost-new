import { supabase } from '@/lib/supabase';

// Define the Ticket type
export interface Ticket {
  id: string;
  name: string;
  email: string;
  subject: string;
  message: string;
  status: string;
  created_at: string;
  user_id: string;
  ticket_responses?: TicketResponse[];
}

// Define the TicketResponse type
export interface TicketResponse {
  id: string;
  message: string;
  created_at: string;
  admin_id: string;
  ticket_id: string;
}

// Submit a new support ticket (renamed from submitTicket to createTicket for consistency)
export const createTicket = async ({ name, email, subject, message }: {
  name: string;
  email: string;
  subject: string;
  message: string;
}) => {
  try {
    const { data: userData, error: userError } = await supabase.auth.getUser();
    
    if (userError) {
      console.error('Error getting user:', userError);
      return { success: false, error: 'User not authenticated' };
    }
    
    const { data, error } = await supabase
      .from('support_tickets')
      .insert([
        {
          user_id: userData.user.id,
          name,
          email,
          subject,
          message,
          status: 'open'
        }
      ])
      .select();
    
    if (error) {
      console.error('Error submitting ticket:', error);
      return { success: false, error: error.message };
    }
    
    return { success: true, data };
  } catch (error) {
    console.error('Unexpected error:', error);
    return { success: false, error: 'An unexpected error occurred' };
  }
};

// Get all tickets for the current user (renamed from getUserTickets to getTickets for consistency)
export const getTickets = async () => {
  try {
    const { data: userData, error: userError } = await supabase.auth.getUser();
    
    if (userError) {
      console.error('Error getting user:', userError);
      return { error: 'User not authenticated' };
    }
    
    const { data, error } = await supabase
      .from('support_tickets')
      .select('*')
      .eq('user_id', userData.user.id)
      .order('created_at', { ascending: false });
    
    if (error) {
      console.error('Error fetching tickets:', error);
      return { error: error.message };
    }
    
    return { tickets: data };
  } catch (error) {
    console.error('Unexpected error:', error);
    return { error: 'An unexpected error occurred' };
  }
};

// Check if the current user is an admin
export const checkIsAdmin = async () => {
  try {
    const { data: userData, error: userError } = await supabase.auth.getUser();
    
    if (userError) {
      console.error('Error getting user:', userError);
      return { isAdmin: false };
    }
    
    const { data, error } = await supabase
      .from('user_roles')
      .select('*')
      .eq('user_id', userData.user.id)
      .eq('role', 'admin')
      .single();
    
    if (error) {
      console.error('Error checking admin status:', error);
      return { isAdmin: false };
    }
    
    return { isAdmin: true };
  } catch (error) {
    console.error('Unexpected error:', error);
    return { isAdmin: false };
  }
};

// Get all tickets for admin
export const getAllTickets = async () => {
  try {
    const { data, error } = await supabase
      .from('support_tickets')
      .select(`
        *,
        ticket_responses(*)
      `)
      .order('created_at', { ascending: false });
    
    if (error) {
      console.error('Error fetching all tickets:', error);
      return { success: false, error: error.message };
    }
    
    return { success: true, data };
  } catch (error) {
    console.error('Unexpected error:', error);
    return { success: false, error: 'An unexpected error occurred' };
  }
};

// Update ticket status
export const updateTicketStatus = async (ticketId: string, status: string) => {
  try {
    const { data, error } = await supabase
      .from('support_tickets')
      .update({ status })
      .eq('id', ticketId)
      .select();
    
    if (error) {
      console.error('Error updating ticket status:', error);
      return { success: false, error: error.message };
    }
    
    return { success: true, data };
  } catch (error) {
    console.error('Unexpected error:', error);
    return { success: false, error: 'An unexpected error occurred' };
  }
};

// Add a response to a ticket
export const addTicketResponse = async (ticketId: string, message: string) => {
  try {
    const { data: userData, error: userError } = await supabase.auth.getUser();
    
    if (userError) {
      console.error('Error getting user:', userError);
      return { success: false, error: 'User not authenticated' };
    }
    
    const { data, error } = await supabase
      .from('ticket_responses')
      .insert([
        {
          ticket_id: ticketId,
          admin_id: userData.user.id,
          message
        }
      ])
      .select();
    
    if (error) {
      console.error('Error adding response:', error);
      return { success: false, error: error.message };
    }
    
    return { success: true, data };
  } catch (error) {
    console.error('Unexpected error:', error);
    return { success: false, error: 'An unexpected error occurred' };
  }
};

// Keep submitTicket for backward compatibility
export const submitTicket = createTicket;
export const getUserTickets = getTickets;
