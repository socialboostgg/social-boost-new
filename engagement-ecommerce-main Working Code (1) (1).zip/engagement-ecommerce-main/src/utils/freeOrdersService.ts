
import { supabase } from "@/lib/supabase";
import { orderSocialMediaService } from "./serviceController";
import { toast } from "sonner";

// Interface for free follower order record
interface FreeFollowerOrder {
  user_id: string;
  platform: string;
  profile_url: string;
  order_id?: number;
  created_at?: string;
}

// Function to record a free follower order in localStorage
export const recordFreeFollowerOrder = async (
  userId: string, 
  platform: string,
  profileUrl: string,
  orderId?: number
): Promise<void> => {
  try {
    // First try to record in Supabase if tables exist
    try {
      console.log(`Recording order in Supabase: ${platform}, ${profileUrl}, ${orderId}`);
      const { error } = await supabase
        .from('free_follower_orders')
        .insert({
          user_id: userId,
          platform: platform,
          profile_url: profileUrl,
          order_id: orderId,
        });
      
      if (!error) {
        console.log("Free follower order recorded in database");
        return;
      } else {
        console.log("Error recording in database:", error);
      }
    } catch (e) {
      console.log("Database table not available, using localStorage fallback:", e);
    }
    
    // Fallback to localStorage if database isn't available
    console.log("Using localStorage fallback for order recording");
    const existingOrdersString = localStorage.getItem('freeFollowerOrders');
    const existingOrders: FreeFollowerOrder[] = existingOrdersString 
      ? JSON.parse(existingOrdersString) 
      : [];
    
    // Check if this user already has a free order for this platform
    const hasExistingOrder = existingOrders.some(
      order => order.user_id === userId && order.platform === platform
    );
    
    if (hasExistingOrder) {
      console.log("User already has a free order for this platform");
      return;
    }
    
    // Add new order
    const newOrder: FreeFollowerOrder = {
      user_id: userId,
      platform,
      profile_url: profileUrl,
      order_id: orderId,
      created_at: new Date().toISOString()
    };
    
    existingOrders.push(newOrder);
    localStorage.setItem('freeFollowerOrders', JSON.stringify(existingOrders));
    console.log("Free follower order recorded in localStorage");
  } catch (error) {
    console.error("Error recording free follower order:", error);
  }
};

// Function to check if a user has already claimed their free followers
export const hasClaimedFreeFollowers = async (
  userId: string, 
  platform: string
): Promise<boolean> => {
  try {
    console.log(`Checking if user ${userId} has claimed ${platform} followers`);
    // First try to check in Supabase if tables exist
    try {
      const { data, error } = await supabase
        .from('free_follower_orders')
        .select('*')
        .eq('user_id', userId)
        .eq('platform', platform);
      
      if (!error && data) {
        console.log(`Database check result: ${data.length} orders found`);
        return data.length > 0;
      } else {
        console.log("Error checking database:", error);
      }
    } catch (e) {
      console.log("Database table not available, using localStorage fallback:", e);
    }
    
    // Fallback to localStorage if database isn't available
    console.log("Using localStorage fallback for claim checking");
    const existingOrdersString = localStorage.getItem('freeFollowerOrders');
    if (!existingOrdersString) {
      console.log("No orders found in localStorage");
      return false;
    }
    
    const existingOrders: FreeFollowerOrder[] = JSON.parse(existingOrdersString);
    const hasClaimed = existingOrders.some(
      order => order.user_id === userId && order.platform === platform
    );
    console.log(`LocalStorage check result: ${hasClaimed}`);
    return hasClaimed;
  } catch (error) {
    console.error("Error checking free follower claims:", error);
    return false;
  }
};

// Mock successful order for testing/development when API is unavailable
const createMockSuccessOrder = (): { success: boolean; orderId: number } => {
  const mockOrderId = Math.floor(Math.random() * 1000000);
  console.log(`Created mock order ID: ${mockOrderId}`);
  return { success: true, orderId: mockOrderId };
};

// Process a free follower order through the API
export const processFreeFollowerOrder = async (
  userId: string,
  platformName: string, // "Instagram", "TikTok", or "Twitter"
  profileUrl: string,
  forceMockMode: boolean = false // Set to true only for testing
): Promise<{ success: boolean; orderId?: number; error?: string }> => {
  try {
    console.log(`Starting processFreeFollowerOrder for ${platformName} - ${profileUrl}`);
    console.log(`Force mock mode: ${forceMockMode}`);
    
    // Check if user has already claimed for this platform
    const alreadyClaimed = await hasClaimedFreeFollowers(userId, platformName.toLowerCase());
    
    if (alreadyClaimed) {
      console.log(`User ${userId} has already claimed free ${platformName} followers`);
      return { 
        success: false, 
        error: `You've already claimed your free ${platformName} followers.`
      };
    }
    
    // Basic URL validation
    if (!profileUrl || profileUrl.trim() === "") {
      console.error("Empty profile URL provided");
      return {
        success: false,
        error: `Please enter a valid ${platformName} profile URL.`
      };
    }
    
    // Fix URL if needed - ensure it has https:// prefix
    let processedUrl = profileUrl.trim();
    if (!processedUrl.startsWith('http://') && !processedUrl.startsWith('https://')) {
      processedUrl = 'https://' + processedUrl;
      console.log(`Added https:// prefix to URL: ${processedUrl}`);
    }
    
    console.log(`Processing free ${platformName} followers order for ${processedUrl}`);
    
    // Use mock response if forced (for development or testing)
    if (forceMockMode) {
      console.log("Using mock response as requested");
      const mockResult = createMockSuccessOrder();
      
      // Record the mock order
      await recordFreeFollowerOrder(
        userId,
        platformName.toLowerCase(),
        processedUrl, 
        mockResult.orderId
      );
      
      return { 
        success: true, 
        orderId: mockResult.orderId 
      };
    }
    
    // Place the order with the API
    try {
      console.log(`Calling API to order followers for ${platformName}`);
      const response = await orderSocialMediaService(
        platformName,
        "Followers", 
        50, // 50 free followers
        processedUrl
      );
      
      console.log("API response:", response);
      
      if (!response) {
        console.error("No response from API");
        return { success: false, error: "No response from service provider" };
      }
      
      if (response.error) {
        console.error("API Error:", response.error);
        return { success: false, error: response.error };
      }
      
      if (!response.order && response.order !== 0) {
        console.error("No order ID returned from API");
        return { 
          success: false, 
          error: "Order could not be processed. Please try again later."
        };
      }
      
      console.log(`Order successful, ID: ${response.order}`);
      
      // Record the order
      await recordFreeFollowerOrder(
        userId,
        platformName.toLowerCase(),
        processedUrl, 
        response.order
      );
      
      return { 
        success: true, 
        orderId: response.order 
      };
    } catch (apiError) {
      console.error("API call failed:", apiError);
      return { 
        success: false, 
        error: apiError instanceof Error 
          ? `API error: ${apiError.message}` 
          : "Failed to connect to service provider. Please try again later."
      };
    }
  } catch (error) {
    console.error("Error processing free follower order:", error);
    return { 
      success: false, 
      error: error instanceof Error ? error.message : "Unknown error"
    };
  }
};

// For testing only - enable mock mode to bypass actual API calls
export const enableMockMode = (enable: boolean = false): void => {
  console.log(`Mock mode ${enable ? 'enabled' : 'disabled'} for testing`);
  localStorage.setItem('useMockMode', enable ? 'true' : 'false');
};

// Check if mock mode is enabled
export const isMockModeEnabled = (): boolean => {
  return localStorage.getItem('useMockMode') === 'true';
};

// Reset to disable mock mode (used on app initialization)
export const resetMockMode = (): void => {
  localStorage.removeItem('useMockMode');
  console.log("Mock mode reset to default (disabled)");
};
