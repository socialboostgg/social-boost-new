import { loadStripe } from '@stripe/stripe-js';

// Use the publishable key for frontend code
// The restricted key will be used only on the server side
export const STRIPE_PUBLISHABLE_KEY = 'pk_live_51Qyl6mHJMnLaGFPxQpGuE9KGcm8KGaLiKKvVZZiUKDILDjyTyRFDXkUhE1G8IuoGLuEMbmBqbXUQxUVZPP4SxxNY00iORXP1xJ';

// Note: The key above has been changed from pk_test to pk_live
export const stripePromise = loadStripe(STRIPE_PUBLISHABLE_KEY);

// For price calculation to match Stripe's expected format (in cents)
export const formatPriceForStripe = (price: number): number => {
  return Math.round(price * 100);
};

// API endpoints for our deployed Supabase functions
export const API_ENDPOINTS = {
  createPaymentIntent: 'https://qcypykfhygfzijffxlej.supabase.co/functions/v1/create-payment-intent',
  confirmPayment: 'https://qcypykfhygfzijffxlej.supabase.co/functions/v1/confirm-payment',
  webhooks: 'https://qcypykfhygfzijffxlej.supabase.co/functions/v1/stripe-webhooks',
};
