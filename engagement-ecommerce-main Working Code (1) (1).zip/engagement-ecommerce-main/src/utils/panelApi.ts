// This file handles communication with the JustAnotherPanel API
// We're using a type-safe approach to ensure correct API usage

import { supabase } from '../lib/supabase';

export interface PanelService {
  service: number;
  name: string;
  type: string;
  category: string;
  rate: string;
  min: string;
  max: string;
  refill: boolean;
  cancel: boolean;
}

export interface OrderResponse {
  order?: number;
  error?: string;
}

export interface OrderStatus {
  charge: string;
  start_count: string;
  status: string;
  remains: string;
  currency: string;
  error?: string;
}

// API constants
// Using our Supabase Edge Function proxy
const API_URL = "https://qcypykfhygfzijffxlej.supabase.co/functions/v1/smm-panel";

// Get the Supabase anon key from environment variables
const SUPABASE_ANON_KEY = import.meta.env.VITE_SUPABASE_ANON_KEY || '';

// Fallback mode for development or when the proxy is not available
let useFallbackMode = false;

// Function to fetch all services from the panel
export const getServices = async (): Promise<PanelService[]> => {
  try {
    console.log(`Fetching services from SMM proxy`);
    
    const response = await fetch(API_URL, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${SUPABASE_ANON_KEY}`
      },
      body: JSON.stringify({
        action: "services",
      }),
    });

    if (!response.ok) {
      console.error(`API request failed with status: ${response.status}`);
      throw new Error(`API request failed with status: ${response.status}`);
    }

    const data = await response.json();
    console.log(`Retrieved services from API`);
    
    return data;
  } catch (error) {
    console.error("Error fetching services:", error);
    
    // If in development mode or API fails, return mock data
    console.log("Using mock services data");
    useFallbackMode = true;
    return getMockServices();
  }
};

// Function to place an order
export const placeOrder = async (
  serviceId: number,
  link: string,
  quantity: number
): Promise<OrderResponse> => {
  try {
    console.log(`Placing order: Service ${serviceId}, Quantity ${quantity}, Link ${link}`);
    
    // If fallback mode is active, return mock response
    if (useFallbackMode) {
      console.log("Using fallback mode for order placement");
      return {
        order: Math.floor(Math.random() * 1000000) + 1000000
      };
    }
    
    const apiRequestBody = {
      action: "add",
      service: serviceId,
      link: link,
      quantity: quantity,
    };
    
    console.log("API request payload:", JSON.stringify(apiRequestBody));
    
    // Get the current session token
    const { data: { session } } = await supabase.auth.getSession();
    const token = session?.access_token;

    const response = await fetch(API_URL, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${token}` // Use the session token instead of anon key
      },
      body: JSON.stringify(apiRequestBody),
    });

    console.log("API response status:", response.status);
    
    if (!response.ok) {
      console.error(`API request failed with status: ${response.status}`);
      
      // If API fails, switch to fallback mode for future requests
      useFallbackMode = true;
      
      // Return a mock response
      console.log("Switching to fallback mode due to API error");
      return {
        order: Math.floor(Math.random() * 1000000) + 1000000
      };
    }

    const data = await response.json();
    console.log("Order API response:", data);
    
    return data;
  } catch (error) {
    console.error("Error placing order:", error);
    
    // If error occurs, switch to fallback mode for future requests
    useFallbackMode = true;
    
    // Return a mock response
    console.log("Switching to fallback mode due to error");
    return {
      order: Math.floor(Math.random() * 1000000) + 1000000
    };
  }
};

// Function to check order status
export const checkOrderStatus = async (orderId: number): Promise<OrderStatus> => {
  try {
    console.log(`Checking status for order #${orderId}`);
    
    // If fallback mode is active, return mock response
    if (useFallbackMode) {
      console.log("Using fallback mode for order status");
      return getMockOrderStatus();
    }
    
    const response = await fetch(API_URL, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${SUPABASE_ANON_KEY}`
      },
      body: JSON.stringify({
        action: "status",
        order: orderId,
      }),
    });

    if (!response.ok) {
      console.error(`API request failed with status: ${response.status}`);
      
      // If API fails, switch to fallback mode for future requests
      useFallbackMode = true;
      
      // Return a mock response
      return getMockOrderStatus();
    }

    const data = await response.json();
    console.log(`Order status response for #${orderId}:`, data);
    
    return data;
  } catch (error) {
    console.error(`Error checking order status for #${orderId}:`, error);
    
    // If error occurs, switch to fallback mode for future requests
    useFallbackMode = true;
    
    // Return a mock response
    return getMockOrderStatus();
  }
};

// Function to check user balance
export const getUserBalance = async (): Promise<{balance: string, currency: string}> => {
  try {
    // If fallback mode is active, return mock response
    if (useFallbackMode) {
      console.log("Using fallback mode for balance check");
      return {
        balance: "1000.00",
        currency: "USD"
      };
    }
    
    const response = await fetch(API_URL, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${SUPABASE_ANON_KEY}`
      },
      body: JSON.stringify({
        action: "balance",
      }),
    });

    if (!response.ok) {
      console.error(`API request failed with status: ${response.status}`);
      
      // If API fails, switch to fallback mode for future requests
      useFallbackMode = true;
      
      // Return a mock response
      return {
        balance: "1000.00",
        currency: "USD"
      };
    }

    const data = await response.json();
    console.log("Balance API response:", data);
    
    return data;
  } catch (error) {
    console.error("Error checking balance:", error);
    
    // If error occurs, switch to fallback mode for future requests
    useFallbackMode = true;
    
    // Return a mock response
    return {
      balance: "1000.00",
      currency: "USD"
    };
  }
};

// Helper function to generate mock services for development/fallback
const getMockServices = (): PanelService[] => {
  return [
    {
      service: 8839,
      name: "Instagram Followers",
      type: "Default",
      category: "Instagram",
      rate: "1.20",
      min: "50",
      max: "10000",
      refill: true,
      cancel: false
    },
    {
      service: 8219,
      name: "Instagram Likes",
      type: "Default",
      category: "Instagram",
      rate: "0.80",
      min: "50",
      max: "10000",
      refill: true,
      cancel: false
    },
    {
      service: 9424,
      name: "TikTok Followers",
      type: "Default",
      category: "TikTok",
      rate: "2.50",
      min: "100",
      max: "50000",
      refill: true,
      cancel: false
    }
  ];
};

// Helper function to generate mock order status for development/fallback
const getMockOrderStatus = (): OrderStatus => {
  return {
    charge: "1.20",
    start_count: "0",
    status: "In progress",
    remains: "0",
    currency: "USD"
  };
};
