
import { toast } from "sonner";
import { formatPriceForStripe, API_ENDPOINTS } from "./stripeConfig";
import { CartItem } from "@/context/CartContext";

interface PaymentIntentResponse {
  clientSecret: string;
  success: boolean;
  error?: string;
}

// Create a payment intent by calling our Supabase function
export const createPaymentIntent = async (
  items: CartItem[],
  total: number
): Promise<PaymentIntentResponse> => {
  try {
    // Get the user's session token if they're logged in
    // This is optional but recommended for authentication
    const token = localStorage.getItem('supabase.auth.token') || '';
    
    console.log("Calling createPaymentIntent with total:", total);
    console.log("URL being called:", API_ENDPOINTS.createPaymentIntent);
    
    // Add better error handling and logging for network issues
    try {
      const response = await fetch(API_ENDPOINTS.createPaymentIntent, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json',
          // Include authorization if the user is logged in and you want to associate orders with them
          ...(token ? { 'Authorization': `Bearer ${token}` } : {}),
          // Add this to help with debugging
          'X-Client-Info': 'lovable-app'
        },
        body: JSON.stringify({
          items,
          amount: formatPriceForStripe(total)
        }),
        // Use cors mode
        mode: 'cors',
        // Don't send credentials since we're using token-based auth
        credentials: 'omit',
      });

      console.log("Response status:", response.status);
      
      if (!response.ok) {
        let errorMessage = `HTTP error! Status: ${response.status}`;
        try {
          const errorData = await response.json();
          console.error('Payment intent creation failed:', errorData);
          errorMessage = errorData.error || errorMessage;
        } catch (e) {
          console.error('Could not parse error response:', e);
        }
        
        toast.error("Payment processing failed", {
          description: errorMessage
        });
        
        return {
          clientSecret: '',
          success: false,
          error: errorMessage
        };
      }

      const data = await response.json();
      console.log("Payment intent created successfully");
      return {
        clientSecret: data.clientSecret,
        success: true
      };
    } catch (fetchError) {
      console.error('Network or CORS error:', fetchError);
      
      // Display a more user-friendly message
      toast.error("Payment service is currently unavailable", {
        description: "Please try again later. If the issue persists, contact support."
      });
      
      // Try to use a fallback or mock implementation for development
      if (process.env.NODE_ENV === 'development') {
        console.log('Using mock payment in development mode');
        // Return a fake client secret for development testing
        return {
          clientSecret: 'mock_client_secret_for_development',
          success: true
        };
      }
      
      return {
        clientSecret: '',
        success: false,
        error: fetchError instanceof Error 
          ? `Network error: ${fetchError.message}` 
          : 'Failed to connect to payment server'
      };
    }
  } catch (error) {
    console.error('Error creating payment intent:', error);
    return {
      clientSecret: '',
      success: false,
      error: error instanceof Error ? error.message : 'An unknown error occurred'
    };
  }
};

// Process a real Stripe payment
export const processStripePayment = async (
  items: CartItem[],
  total: number,
  stripe: any,
  elements: any
): Promise<{ success: boolean; error?: string; paymentIntentId?: string }> => {
  try {
    if (!stripe || !elements) {
      throw new Error("Stripe has not been initialized");
    }
    
    const cardElement = elements.getElement('card');
    
    if (!cardElement) {
      throw new Error("Card element not found");
    }
    
    // Create a payment intent by calling our Supabase function
    const { clientSecret, success, error } = await createPaymentIntent(items, total);
    
    if (!success) {
      toast.error(`Payment initialization failed: ${error}`);
      return { success: false, error };
    }
    
    // Get billing details from the form safely
    const getElementValue = (id: string): string => {
      const element = document.getElementById(id) as HTMLInputElement | null;
      return element?.value || '';
    };
    
    const firstName = getElementValue('firstName');
    const lastName = getElementValue('lastName');
    const email = getElementValue('email');
    
    // If we're in development mode and using the mock client secret, return success
    if (process.env.NODE_ENV === 'development' && clientSecret === 'mock_client_secret_for_development') {
      console.log('Using mock payment confirmation in development');
      toast.success("Payment successful! (Development Mode)");
      return { success: true, paymentIntentId: 'mock_payment_intent_id' };
    }
    
    // Confirm the payment with Stripe.js
    const { error: stripeError, paymentIntent } = await stripe.confirmCardPayment(clientSecret, {
      payment_method: {
        card: cardElement,
        billing_details: {
          name: `${firstName} ${lastName}`.trim() || 'Customer',
          email: email || 'customer@example.com',
        },
      }
    });
    
    if (stripeError) {
      toast.error(`Payment failed: ${stripeError.message}`);
      return { success: false, error: stripeError.message };
    }
    
    if (paymentIntent.status === 'succeeded') {
      toast.success("Payment successful!");
      return { success: true, paymentIntentId: paymentIntent.id };
    } else {
      toast.warning(`Payment status: ${paymentIntent.status}. Please check your payment dashboard.`);
      return { success: false, error: `Payment status: ${paymentIntent.status}` };
    }
    
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : "An unknown error occurred";
    toast.error(`Payment processing error: ${errorMessage}`);
    console.error("Error processing payment:", error);
    return { success: false, error: errorMessage };
  }
};

// In case we need to mock payments during development
export const mockStripePayment = async (
  items: CartItem[],
  total: number
): Promise<{ success: boolean; error?: string }> => {
  // Simulate processing delay
  await new Promise(resolve => setTimeout(resolve, 1500));
  
  // 90% success rate for demo
  const isSuccessful = Math.random() < 0.9;
  
  if (isSuccessful) {
    toast.success(`Payment of $${total.toFixed(2)} successful!`);
    return { success: true };
  } else {
    const error = "Card declined. Please try another payment method.";
    toast.error(`Payment failed: ${error}`);
    return { success: false, error };
  }
};
